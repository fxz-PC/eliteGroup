#设置客户端语言
SET NAMES UTF8;
#放弃数据库(如果存在)tedu
DROP DATABASE IF EXISTS douban;
#创建数据库tedu
CREATE DATABASE douban CHARSET=UTF8;
#进入数据库
USE douban;

/**用户信息**/
CREATE TABLE douban_user(
  id INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32)
);
INSERT INTO douban_user VALUES(null,'facker',md5('123456'));
#理解:用户输入123对用户输入内容加密
#加密后与数据密码比较
#SELECT id FROM xz_login
#WHERE uname = ? AND upwd = md5(?)

CREATE TABLE douban_list(
  id INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(255),
  book_name VARCHAR(64),
  price DECIMAL(15,2),
  pid INT 
);
INSERT INTO douban_list VALUES(null,'http://127.0.0.1:3000/img/2.png','人鼠之间',88.99,1);
INSERT INTO douban_list VALUES(null,'http://127.0.0.1:3000/img/3.png','鱼王',45.34,2);
INSERT INTO douban_list VALUES(null,'http://127.0.0.1:3000/img/4.png','邻之人妻',99,3);
INSERT INTO douban_list VALUES(null,'http://127.0.0.1:3000/img/5.png','短篇小说全集',10,4);
INSERT INTO douban_list VALUES(null,'http://127.0.0.1:3000/img/6.png','当下的启蒙',15,5);

#创建购物车表
CREATE TABLE douban_cart(
  id INT PRIMARY KEY AUTO_INCREMENT,
  book_name VARCHAR(64),
  price DECIMAL(15,2),
  count INT,
  uid INT,
  pid INT
);
INSERT INTO douban_cart VALUES(null,'123',89,1,1,1);
INSERT INTO douban_cart VALUES(null,'123',77,1,1,2);
INSERT INTO douban_cart VALUES(null,'123',66,1,1,3);
INSERT INTO douban_cart VALUES(null,'123',55,1,1,4);
INSERT INTO douban_cart VALUES(null,'123',144,2,1,5);