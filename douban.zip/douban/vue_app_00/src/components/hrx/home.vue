<template>
  <div id="wrapper">
    <div id="content">
      <div class="grid-16-8 clearfix">
        <div class="article">
          <div class="section popular-books">
            <div class="hd">
              <h2>
                <span>最受关注图书榜</span>
                <span class="link-more">
                  <a href="javascript:;">虚构类»</a>
                </span>
                <span class="link-more">
                  <a href="javascript:;">非虚构类»</a>
                </span>
              </h2>
            </div>
            <div class="bd">
              <ul
                class="list-col list-col2 list-summary s"
                data-dstat-areaid="61"
                data-dstat-mode="click,expose"
              >
                <li class>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/s29920407.jpg" alt="全能侦探社" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a class>全能侦探社</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">8.6</span>
                    </p>
                    <p class="author">作者：[英] 道格拉斯·亚当斯</p>
                    <p class="book-list-classification">科幻&nbsp;/&nbsp;英国</p>
                    <p class="extra-info">
                      <span class="meta-label">有电子书</span>
                    </p>

                    <p class="reviews">“别那么严肃，一切都是个天马行空的故事罢了</p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/s29923715.jpg" alt="世界观（原书第2版）" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a>世界观（原书第2版）</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">9.0</span>
                    </p>
                    <p class="author">作者：[美]理查德·德威特</p>
                    <p class="book-list-classification">认知体系&nbsp;/&nbsp;科普</p>
                    <p class="extra-info"></p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/s29952694.jpg" alt="小偷家族" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="javascript:;" class>小偷家族</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">8.7</span>
                    </p>
                    <p class="author">作者：[日] 是枝裕和</p>
                    <p class="book-list-classification">电影原著&nbsp;/&nbsp;日本小说</p>
                    <p class="extra-info">
                      <span class="meta-label">有电子书</span>
                    </p>

                    <p class="reviews">
                      维系整个家族的东西，或许还真的不是血缘。
                      (
                      <a href="javascript:;">atangtang评论</a>)
                    </p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/s29953545.jpg" alt="642件可写的事" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="javascript:;" class>642件可写的事</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar40 star-img"></span>
                      <span class="average-rating">8.1</span>
                    </p>
                    <p class="author">作者：美国旧金山写作社&nbsp;/&nbsp;San Francisco Writers'Grotto</p>
                    <p class="book-list-classification">写作&nbsp;/&nbsp;创意</p>
                    <p class="extra-info"></p>

                    <p class="reviews">
                      这是一本等待你来创造的书。
                      (
                      <a href="javascript:;">栖逸评论</a>)
                    </p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="JavaScript:;">
                      <img src="../../img/s29967206.jpg" alt="夏摩山谷" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="JavaScript:;" class>夏摩山谷</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar40 star-img"></span>
                      <span class="average-rating">7.4</span>
                    </p>
                    <p class="author">作者：庆山</p>
                    <p class="book-list-classification">小说&nbsp;/&nbsp;中国</p>
                    <p class="extra-info"></p>

                    <p class="reviews">
                      如何从繁复的生命中解脱？如何定义爱？如何才能追寻到真实的自我？
                      (
                      <a
                        href="JavaScript:;"
                      >岁月静好评论</a>)
                    </p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="JavaScript:;">
                      <img src="../../img/s29935004.jpg" alt="一起连环绑架案的新闻" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="JavaScript:;" class>一起连环绑架案的新闻</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">8.7</span>
                    </p>
                    <p class="author">作者：[哥伦比亚] 加西亚·马尔克斯</p>
                    <p class="book-list-classification">拉美文学&nbsp;/&nbsp;纪实文学</p>
                    <p class="extra-info"></p>

                    <p class="reviews">
                      今天的新闻，有哪一桩能担得起三年漫漫的写作历程呢？
                      (
                      <a href="JavaScript:;">yezI评论</a>)
                    </p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="JavaScript:;">
                      <img src="../../img/s29927081.jpg" alt="度外" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="JavaScript:;" class>度外</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">8.4</span>
                    </p>
                    <p class="author">作者：黄国峻</p>
                    <p class="book-list-classification">短篇小说&nbsp;/&nbsp;华语文学</p>
                    <p class="extra-info"></p>

                    <p class="reviews">
                      黄国峻将仍然是“未来的小说家”。
                      (
                      <a href="JavaScript:;">朱岳评论</a>)
                    </p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="JavaScript:;">
                      <img src="../../img/s29909471.jpg" alt="清单" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="JavaScript:;" class>清单</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar40 star-img"></span>
                      <span class="average-rating">8.0</span>
                    </p>
                    <p class="author">作者：[英] 肖恩•厄舍</p>
                    <p class="book-list-classification"></p>
                    <p class="extra-info"></p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="JavaScript:;">
                      <img src="../../img/s29930566.jpg" alt="4321" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="JavaScript:;" class>4321</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">8.8</span>
                    </p>
                    <p class="author">作者：[美] 保罗·奥斯特</p>
                    <p class="book-list-classification">小说&nbsp;/&nbsp;美国文学</p>
                    <p class="extra-info"></p>

                    <p class="reviews">
                      有没有哪个瞬间，我们发现了自己另外四分之三的人生？
                      (
                      <a
                        href="JavaScript:;"
                      >理想国外文馆评论</a>)
                    </p>
                  </div>
                </li>

                <li class>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/s29960161.jpg" alt="显微镜下的大明" class>
                    </a>
                  </div>
                  <div class="info">
                    <h4 class="title">
                      <a href="javascript:;" class>显微镜下的大明</a>
                    </h4>
                    <p class="entry-star-small">
                      <span class="allstar45 star-img"></span>
                      <span class="average-rating">8.6</span>
                    </p>
                    <p class="author">作者：马伯庸</p>
                    <p class="book-list-classification"></p>
                    <p class="extra-info"></p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div id="dale_book_home_left_middle" class="ad-placeholder" style="margin:-50px 0 30px;"></div>
          <div class="section market-books">
            <div class="hd">
              <h2>
                <span>豆瓣书店</span>
                <span class="link-more">
                  <a href="javascript:;" class>查看全部»</a>
                </span>
              </h2>
            </div>
            <div class="bd">
              <div class="top">
                <div class="cover">
                  <a href="javascript:;" class>
                    <div
                      class="pic"
                      style="background-image: url(https://img3.doubanio.com/view/freyr_page_photo/raw/public/3472.jpg)"
                    ></div>
                  </a>
                </div>
                <div id="market_books_header_info" class="info">
                  <p class="title">
                    帕佩撒旦阿莱佩
                    <span class="price">￥60.00</span>
                    <span class="free_delivery">／包邮</span>
                  </p>
                  <p class="desc indent-paragraph" data-row="4">翁贝托•埃科最后的作品，看思想界顽童戏谑现代社会</p>
                </div>
              </div>
              <ul class="list-col list-col5">
                <li>
                  <div class="cover">
                    <a href="javascript:;" class>
                      <img src="../../img/3389.jpg" alt="中国民间崇拜文化丛书" width="106" height="140">
                    </a>
                  </div>
                  <div class="info">
                    <div class="title">
                      <a href="javascript:;" class>中国民间崇拜文化丛书</a>
                    </div>
                    <div class="price">￥166.00</div>
                  </div>
                </li>

                <li>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/3370.jpg" alt="吉本芭娜娜作品系列" width="106" height="140">
                    </a>
                  </div>
                  <div class="info">
                    <div class="title">
                      <a href="javascript:;">吉本芭娜娜作品系列</a>
                    </div>
                    <div class="price">￥295.00</div>
                  </div>
                </li>

                <li>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/3196.jpg" alt="4 3 2 1" width="106" height="140">
                    </a>
                  </div>
                  <div class="info">
                    <div class="title">
                      <a href="javascript:;">4 3 2 1</a>
                    </div>
                    <div class="price">￥115.00</div>
                  </div>
                </li>

                <li>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/3336.jpg" alt="行动派手帐指南" width="106" height="140">
                    </a>
                  </div>
                  <div class="info">
                    <div class="title">
                      <a href="javascript:;">行动派手帐指南</a>
                    </div>
                    <div class="price">￥55.00</div>
                  </div>
                </li>

                <li>
                  <div class="cover">
                    <a href="javascript:;">
                      <img src="../../img/3298.jpg" alt="“朦胧城市”系列图像小说精选套装" width="106" height="140">
                    </a>
                  </div>
                  <div class="info">
                    <div class="title">
                      <a href="javascript:;">“朦胧城市”系列图像小说精选套装</a>
                    </div>
                    <div class="price">￥150.00</div>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div class="section ebook-area">
            <div class="hd">
              <h2 class>
                <span class>电子图书</span>
                <span class="link-more">
                  <a href="javascript:;">查看全部»</a>
                </span>
              </h2>
            </div>
            <div class="bd">
              <div class>
                <div class="sub-section">
                  <div class="sub-hd">
                    <h3>
                      热门电子图书
                      <span class="more-info">
                        <a href="javascript:;">更多»</a>
                      </span>
                    </h3>
                  </div>
                  <div class="sub-bd">
                    <ul class="list-col list-col5">
                      <li class>
                        <div class="cover">
                          <a href="javascript:;" title="流浪地球">
                            <img
                              src="../../img/19532065.jpg"
                              alt="流浪地球"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="javascript:;" title="流浪地球">流浪地球</a>
                          </div>
                          <div class="price">6.99元</div>
                          <div class="more-meta">
                            <h4 class="title">流浪地球</h4>
                            <p>
                              <span class="author">刘慈欣</span> /
                              <span class="year">2008-11</span> /
                              <span class="publisher">湖北长江出版集团，长江文艺出版社</span> /
                              <span class="price">6.99元</span>
                            </p>
                            <p class="abstract">
                              50亿年的壮丽生涯已成为飘逝的梦幻，太阳死了。幸运的是，还有人活着。地球航出了冥王星轨道，航出了太阳系，在寒冷广漠的外太空继续着它孤独的航程。地球在航行2400年后到达比邻星，再过100年时间，它将泊入这颗恒星的轨道，成为它的一颗卫星。
                              刘慈欣短篇科幻小说。
                              刘慈欣，大陆新生代科幻的主要代表作家，中国科普作协会员，山西省作家协会会员，自上世纪九十年...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="变量：看见中国社会小趋势">
                            <img
                              src="../../img/107111925.jpg"
                              alt="变量：看见中国社会小趋势"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;" title="变量：看见中国社会小趋势">变量：看见中国社会小趋势</a>
                          </div>
                          <div class="price">39.00元</div>
                          <div class="more-meta">
                            <h4 class="title">变量：看见中国社会小趋势</h4>
                            <p>
                              <span class="author">何帆</span> /
                              <span class="year">2019-1</span> /
                              <span class="publisher">中信出版社</span> /
                              <span class="price">39.00元</span>
                            </p>
                            <p class="abstract">
                              我们要像观察一棵树一样细致观察中国的变化：
                              贸易摩擦只是一根树枝，国际关系才是大树，
                              民粹主义是谁也无法忽略的力量，
                              互联网不可能对所有传统行业发起“降维打击”，
                              城市也悄然进行着革命，
                              自下而上的力量浮出水面，
                              大山深处的留守儿童学校出乎意料地成为素质教育的革命场，
                              重建社群正在消除人性中的自私、偏见和戾气。
                              像观察一颗树一样，
                              剥离迅疾而无关紧要的变化...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="帕佩撒旦阿莱佩">
                            <img
                              src="../../img/107290496.jpg"
                              alt="帕佩撒旦阿莱佩"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;" title="帕佩撒旦阿莱佩">帕佩撒旦阿莱佩</a>
                          </div>
                          <div class="price">44.99元</div>
                          <div class="more-meta">
                            <h4 class="title">帕佩撒旦阿莱佩</h4>
                            <p>
                              <span class="author">[意] 翁贝托·埃科</span> /
                              <span class="year">2019-1</span> /
                              <span class="publisher">上海译文出版社</span> /
                              <span class="price">44.99元</span>
                            </p>
                            <p class="abstract">
                              当社会失去牢固的支撑，像液体般流动，
                              身处其中的我们，该何去何从？
                              翁贝托·埃科生前最后一部作品，于埃科去世一周后在意大利出版，是埃科生命中最后15年对现代社会的观察与思索，天马行空，妙趣横生，除却睿智的思考、犀利的评判，亦有“老顽童”式的奇思妙想。
                              “帕佩撒旦阿莱佩”出自但丁《神曲·地狱篇》第七歌冥神普鲁托，没有确切的含义，却令人联想起各种稀...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="垂死的肉身">
                            <img
                              src="../../img/107106201.jpg"
                              alt="垂死的肉身"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;" title="垂死的肉身">垂死的肉身</a>
                          </div>
                          <div class="price">27.99元</div>
                          <div class="more-meta">
                            <h4 class="title">垂死的肉身</h4>
                            <p>
                              <span class="author">[美] 菲利普·罗斯</span> /
                              <span class="year">2019-1-31</span> /
                              <span class="publisher">上海译文出版社</span> /
                              <span class="price">27.99元</span>
                            </p>
                            <p class="abstract">
                              《垂死的肉身》讲述了年过六旬的美国教授大卫·凯普什与他的学生——二十四岁的古巴女孩康秀拉——发生的一段不寻常的爱欲关系。凯普什迷恋于康秀拉的身体
                              无法自拔，而对康秀拉而言，他的年龄和地位则合情合理地赋予了她屈服的权利。然而渐渐地，对年龄差距的恐惧、对青春的嫉妒抽走了凯普什的自信，使他挣扎在
                              性爱和垂死之间，这段关系的完结更使他长时间地备受折磨...
                            </p>
                          </div>
                        </div>
                      </li>
                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="克苏鲁神话Ⅲ">
                            <img
                              src="../../img/107224347.jpg"
                              alt="克苏鲁神话Ⅲ"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;" title="克苏鲁神话Ⅲ">克苏鲁神话Ⅲ</a>
                          </div>
                          <div class="price">36.00元</div>
                          <div class="more-meta">
                            <h4 class="title">克苏鲁神话Ⅲ</h4>
                            <p>
                              <span class="author">[美] H.P.洛夫克拉夫特</span> /
                              <span class="year">2019-1</span> /
                              <span class="publisher">浙江文艺出版社</span> /
                              <span class="price">36.00元</span>
                            </p>
                            <p class="abstract">
                              《克苏鲁神话》被誉为20世纪最伟大、最具影响力的恐怖小说体系，作者是H.P·洛夫克拉夫特——或者“爱手艺”。
                              假设你的脚边有一只蚂蚁在爬，你不会在意有没有踩死它，因为它太渺小了，是死还是活，对你来说没有分毫影响。在“克苏鲁神话”中描述的远古邪神的眼中，人类就是那只蚂蚁。
                              洛夫克拉夫特所倡导的“宇宙主义”，即人类远非世界的主宰者，在尚未探索的未知宇...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="不伦与南美">
                            <img
                              src="../../img/106724318.jpg"
                              alt="不伦与南美"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;" title="不伦与南美">不伦与南美</a>
                          </div>
                          <div class="price">22.99元</div>
                          <div class="more-meta">
                            <h4 class="title">不伦与南美</h4>
                            <p>
                              <span class="author">(日) 吉本芭娜娜</span> /
                              <span class="year">2019-2</span> /
                              <span class="publisher">上海译文出版社</span> /
                              <span class="price">22.99元</span>
                            </p>
                            <p class="abstract">
                              治愈，从这里开始。
                              吉本芭娜娜阿根廷之旅归来！
                              第十届Bunkamura双偶文学奖作品
                              布宜诺斯艾利斯的异色空气里
                              情与欲与那令人心痛的羁绊
                              在暗暗氤氲……
                              吉本芭娜娜的写作简介、真诚，充满了疗愈的魔力。它抓住了读者的心并拒绝再放开。
                              ——《纽约时报》
                              吉本芭娜娜是一位讲故事大师。故事的感官性被隐晦地隐藏起来，却强烈无比。语言简洁得令人不可置信。——《芝加哥论...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="非对称风险">
                            <img
                              src="../../img/106820952.jpg"
                              alt="非对称风险"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;">非对称风险</a>
                          </div>
                          <div class="price">36.99元</div>
                          <div class="more-meta">
                            <h4 class="title">非对称风险</h4>
                            <p>
                              <span class="author">【美】纳西姆▪尼古拉斯▪塔勒布（Nassim Nicholas Taleb）</span> /
                              <span class="year">2019-1-1</span> /
                              <span class="publisher">中信出版集团</span> /
                              <span class="price">36.99元</span>
                            </p>
                            <p class="abstract">
                              约3800年前，《汉谟拉比法典》就向我们传达出一条人类进化的法则——在人与人的交往中建立对称关系，以防止有人转嫁隐藏的“尾部风险”。古往今来，人
                              类的任何一条法律、任何一项教谕，也都是基于“对称性”原则的，但实际上，非对称风险也一直存在于人类历史之中。塔勒布提出，人们在面对非对称风险和外部
                              压力时，只有践行“风险共担”的原则，才能做出正确的决策...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="时间的礼物">
                            <img
                              src="../../img/107064760.jpg"
                              alt="时间的礼物"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;">时间的礼物</a>
                          </div>
                          <div class="price">18.00元</div>
                          <div class="more-meta">
                            <h4 class="title">时间的礼物</h4>
                            <p>
                              <span class="author">[瑞典] 弗雷德里克·巴克曼</span> /
                              <span class="year">2019-1-1</span> /
                              <span class="publisher">天津人民出版社</span> /
                              <span class="price">18.00元</span>
                            </p>
                            <p class="abstract">
                              世间的一切都有标价，除了时间，一秒就是一秒，谁都无法讨价还价。
                              于是我总在出差，把生命中的每分每秒都贡献给工作，因为我坚信创造财富才是时间的正经归宿。45岁时，我成为一个有事业和资本的成功人士，但妻子和儿子离开了我。
                              癌症将我送进医院，一周前，我认识了隔壁病房的五岁女孩。她用蜡笔给椅子涂颜色，用牛奶盒做恐龙、给兔子玩偶讲故事，都是为了安慰妈妈...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="我们都是奥黛特">
                            <img
                              src="../../img/106976366.jpg"
                              alt="我们都是奥黛特"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;">我们都是奥黛特</a>
                          </div>
                          <div class="price">20.00元</div>
                          <div class="more-meta">
                            <h4 class="title">我们都是奥黛特</h4>
                            <p>
                              <span class="author">[法]埃里克-艾玛纽埃尔·施密特</span> /
                              <span class="year">2019-1</span> /
                              <span class="publisher">中信出版集团</span> /
                              <span class="price">20.00元</span>
                            </p>
                            <p class="abstract">
                              八个怀揣不同过往的女人，八段关于爱与救赎的故事
                              她们的故事，就是我们的人生
                              一个喜欢啃书本却在做售货员的平凡女人，以热情感染了颓丧的畅销书作家；
                              一位已患阿兹海默的老妇人，却始终幻想自己还是年轻时的模样；
                              一名曾嫁入豪门的拜金女，在旅途中遇见往日的画家情人，追慕自己的过去与成长；
                              一群身陷囹圄的母亲，用冒死保留的铅笔和纸，留给孩子传世的智慧。
                              埃里克...
                            </p>
                          </div>
                        </div>
                      </li>

                      <li class>
                        <div class="cover">
                          <a href="JavaScript:;" title="危险的维纳斯">
                            <img
                              src="../../img/106603631.jpg"
                              alt="危险的维纳斯"
                              width="106px"
                              height="158px"
                            >
                          </a>
                        </div>
                        <div class="info">
                          <div class="title">
                            <a href="JavaScript:;">危险的维纳斯</a>
                          </div>
                          <div class="price">11.99元</div>
                          <div class="more-meta">
                            <h4 class="title">危险的维纳斯</h4>
                            <p>
                              <span class="author">[日] 东野圭吾</span> /
                              <span class="year">2019-1</span> /
                              <span class="publisher">北京联合出版公司</span> /
                              <span class="price">11.99元</span>
                            </p>
                            <p class="abstract">
                              一个陌生女人的电话，一起失踪事件，动物医生手岛伯朗卷入一场正在进行的犯罪事件。没有任何线索，甚至连同伴也不能完全信任。那个隐藏在家人中的凶手到底是谁？
                              “维纳斯”不是某个人，而是存在于我们每个人心中令人疯狂的东西。恶不是一开始就存在，东野圭吾在这本书里诠释了好人是如何变成恶魔的。复杂的情节，反转再反转，但反转的是故事，还是人心？
                              东野圭吾，日...
                            </p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div id="reviews" class="section">
            <div class="reviews-hd">
              <h2>
                最受欢迎的书评
                <span>
                  <a href="JavaScript:;">更多热门书评»</a>
                </span>
                <span>
                  <a href="JavaScript:;">最新书评»</a>
                </span>
              </h2>
            </div>
            <div class="reviews-bd">
              <div class="review">
                <div class="review-hd">
                  <a href="JavaScript:;">
                    <img src="../../img/s28705474.jpg" alt="信息洪流中，我们该如何培养独立思考的能力？">
                  </a>
                </div>
                <div class="review-bd">
                  <h3>
                    <a href="JavaScript:;">信息洪流中，我们该如何培养独立思考的能力？</a>
                  </h3>
                  <div class="review-meta">
                    <a href="JavaScript:;">南玉书</a> 评论
                    <a href="JavaScript:;">《如何有效阅读一本书》</a>
                    
                    <span class="allstar50"></span>
                  </div>
                  <div class="review-content">
                    大家也许都听说过“王戎识李”的故事。
                    这个故事是说古代有个聪明的小孩叫王戎，在他七岁的时候，跟小伙伴们一起出去玩，碰巧看到路旁有一棵李树结满了果子。于是，大家纷纷跑过去抢着摘李子，唯独王戎站在一旁，...
                    <a
                      href="JavaScript:;"
                    >(全文)</a>
                  </div>
                </div>
              </div>

              <div class="review">
                <div class="review-hd">
                  <a href="JavaScript:;">
                    <img src="../../img/s29752394.jpg" alt="你还在做月光族？别人已经在探讨赚钱的多重目的了">
                  </a>
                </div>
                <div class="review-bd">
                  <h3>
                    <a href="JavaScript:;">你还在做月光族？别人已经在探讨赚钱的多重目的了</a>
                  </h3>
                  <div class="review-meta">
                    <a href="JavaScript:;">小鱼乖乖</a> 评论
                    <a href="JavaScript:;">《会赚钱的妈妈》</a>
                    
                    <span class="allstar40"></span>
                  </div>
                  <div class="review-content">
                    在一线大城市工作，拿着一份吃不饱饿不死的死工资，除去吃喝拉撒，真的所剩无几啊！这也是我们很大一部分人的痛点，所以我们是被迫成为月光族的。既然这样，那有没有什么办法可以改变这种状况呢？
                    有的！《会赚钱...
                    <a
                      href="JavaScript:;"
                    >(全文)</a>
                  </div>
                </div>
              </div>

              <div class="review">
                <div class="review-hd">
                  <a href="JavaScript:;">
                    <img src="../../img/s29211179.jpg" alt="英语单词大书打开的方式有几种">
                  </a>
                </div>
                <div class="review-bd">
                  <h3>
                    <a href="javascript:;">英语单词大书打开的方式有几种</a>
                  </h3>
                  <div class="review-meta">
                    <a href="JavaScript:;">密斯陈</a> 评论
                    <a href="JavaScript:;">《英语单词大书》</a>
                    
                    <span class="allstar50"></span>
                  </div>
                  <div class="review-content">
                    最近看到如果你觉得“书抄不抄无所谓，便宜就好”，就太天真了这篇文章的时候，我都快气晕了。现在的人盗版就算了，竟然偷都能偷到错误连篇。浪费家长的钱都是小事，现在的家长本身陪孩子的时间不是很多，仅有的...
                    <a
                      href="JavaScript:;"
                    >(全文)</a>
                  </div>
                </div>
              </div>

              <div class="review last">
                <div class="review-hd">
                  <a href="JavaScript:;">
                    <img src="../../img/s29522327.jpg" alt="一年读300本书？这是我见过的最高效的方法">
                  </a>
                </div>
                <div class="review-bd">
                  <h3>
                    <a href="javascript:;">一年读300本书？这是我见过的最高效的方法</a>
                  </h3>
                  <div class="review-meta">
                    <a href="JavaScript:;">糖果读书会</a> 评论
                    <a href="JavaScript:;">《实用性阅读指南》</a>
                    
                    <span class="allstar50"></span>
                  </div>
                  <div class="review-content">
                    时常会看到有网友问“为什么读了这么多书，我们却依旧过不好这一生？”
                    初看这个问题，我们多数人下意识都会把关注点都放在读的书的数量上，认为自己付出了很多努力，却没有得到想要的结果。很少人会直接去关注对...
                    <a
                      href="JavaScript:;"
                    >(全文)</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="aside">
          <h2 class>
            <span class>热门标签</span>
            <span class="link-more">
              <a class href="JavaScript:;">所有热门标签»</a>
            </span>
          </h2>

          <ul class="hot-tags-col5 s" data-dstat-areaid="54" data-dstat-mode="click,expose">
            <li>
              <ul class="clearfix">
                <li class="tag_title">文学</li>
                <li>
                  <a href="JavaScript:;" class="tag">小说</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">随笔</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">日本文学</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag">散文</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">诗歌</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">童话</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">名著</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag">港台</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag more_tag">更多»</a>
                </li>
              </ul>
            </li>

            <li>
              <ul class="clearfix">
                <li class="tag_title">流行</li>
                <li>
                  <a href="JavaScript:;" class="tag">漫画</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">推理</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">绘本</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag">青春</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">科幻</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">言情</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">奇幻</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag">武侠</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag more_tag">更多»</a>
                </li>
              </ul>
            </li>

            <li>
              <ul class="clearfix">
                <li class="tag_title">文化</li>
                <li>
                  <a href="JavaScript:;" class="tag">历史</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">哲学</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">传记</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag">设计</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">建筑</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">电影</a>
                </li>
                <li>
                  <a href="JavaScript:;" class="tag">回忆录</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag">音乐</a>
                </li>
                <li class="last">
                  <a href="JavaScript:;" class="tag more_tag">更多»</a>
                </li>
              </ul>
            </li>

            <li>
              <ul class="clearfix">
                <li class="tag_title">生活</li>
                <li>
                  <a href="javacsript:;" class="tag">旅行</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">励志</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">教育</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag">职场</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">美食</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">灵修</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">健康</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag">家居</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag more_tag">更多»</a>
                </li>
              </ul>
            </li>

            <li>
              <ul class="clearfix">
                <li class="tag_title">经管</li>
                <li>
                  <a href="javacsript:;" class="tag">经济学</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">管理</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">商业</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag">金融</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">营销</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">理财</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">股票</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag">企业史</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag more_tag">更多»</a>
                </li>
              </ul>
            </li>

            <li>
              <ul class="clearfix">
                <li class="tag_title">科技</li>
                <li>
                  <a href="javacsript:;" class="tag">科普</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">互联网</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">编程</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag">交互设计</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">算法</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">通信</a>
                </li>
                <li>
                  <a href="javacsript:;" class="tag">神经网络</a>
                </li>
                <li class="last">
                  <a href="javacsript:;" class="tag more_tag">更多»</a>
                </li>
              </ul>
            </li>
          </ul>

          <div id="dale_book_homepage_right_bottom" class="ad-placeholder"></div>

          <div class="section weekly-top">
            <div class="hd">
              <h2>畅销图书榜</h2>
            </div>
            <div class="bd">
              <ul class="nav-vendor">
                <li class="book-chart-hd" id="dangdang-book-chart-hd">
                  <img src="../../img/dangdang_chart.png" width="20" height="18">
                  <span>当当</span>
                </li>
              </ul>

              <ul class="list list-ranking">
                <li class="item">
                  <span class="rank-num">1.</span>
                  <div class="book-info">
                    <a href="JavaScript:;" class="name">流浪地球</a>
                    <div class="author">刘慈欣</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">2.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">菊与刀</a>
                    <div class="author">本尼迪克特</div>
                  </div>
                  <a href>
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">3.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">浮生六记</a>
                    <div class="author">沈复</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">4.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">人间失格</a>
                    <div class="author">太宰治</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">5.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">月亮与六便士</a>
                    <div class="author">毛姆</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">6.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">人间失格</a>
                    <div class="author">[日] 太宰治</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">7.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">活着</a>
                    <div class="author">余华</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">8.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">面纱</a>
                    <div class="author">毛姆</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">9.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">原则</a>
                    <div class="author">[美] 瑞·达利欧</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">10.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">薛兆丰经济学讲义</a>
                    <div class="author">薛兆丰</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
              </ul>
              <ul class="list list-ranking" style="display: none;">
                <li class="item">
                  <span class="rank-num">1.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">人间失格</a>
                    <div class="author">太宰治</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">2.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">流浪地球</a>
                    <div class="author">刘慈欣</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">3.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">流浪的地球</a>
                    <div class="author">刘慈欣</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">4.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">活着</a>
                    <div class="author">余华</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">5.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">我喜欢生命本来的样子</a>
                    <div class="author">周国平</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">6.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">浮生六记</a>
                    <div class="author">沈复</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">7.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">三体</a>
                    <div class="author">刘慈欣</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">8.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">皮囊</a>
                    <div class="author">蔡崇达</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">9.</span>
                  <div class="book-info">
                    <a href="javascript:;" class="name">好的孤独</a>
                    <div class="author">陈果</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
                <li class="item">
                  <span class="rank-num">10.</span>
                  <div class="book-info">
                    <a href="javascript:;javascript:;" class="name">三体Ⅱ</a>
                    <div class="author">刘慈欣</div>
                  </div>
                  <a href="javascript:;">
                    <span class="buy-button">去购买</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div class="block5">
            <h2 class>
              <span class>豆瓣图书</span>
              <span class="link-more">
                <a class href="javascript:;">更多»</a>
              </span>
            </h2>
            <div
              class="content clearfix s"
              id="book_rec"
              data-dstat-areaid="58"
              data-dstat-mode="click,expose"
            >
              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s1988674.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">红与黑</a>
                  <p class="extra-info"></p>
                </dd>
              </dl>

              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s29237651.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">相约星期二</a>
                  <p class="extra-info">
                    <span class="meta-label">有电子书</span>
                  </p>
                </dd>
              </dl>

              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s1990480.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">哈利·波特与魔法石</a>
                  <p class="extra-info">
                    <span class="meta-label">有电子书</span>
                  </p>
                </dd>
              </dl>
              <div class="clearfix rr" style="width:100%"></div>
              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s1072746.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">哈利·波特与火焰杯</a>
                  <p class="extra-info">
                    <span class="meta-label">有电子书</span>
                  </p>
                </dd>
              </dl>

              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s7019913.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">江城</a>
                  <p class="extra-info">
                    <span class="meta-label">有电子书</span>
                  </p>
                </dd>
              </dl>
              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s6384944.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">百年孤独</a>
                  <p class="extra-info"></p>
                </dd>
              </dl>
              <div class="clearfix rr" style="width:100%"></div>
              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s1127135.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">情书</a>
                  <p class="extra-info"></p>
                </dd>
              </dl>

              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s1127135.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">匆匆那年（上下）</a>
                  <p class="extra-info"></p>
                </dd>
              </dl>
              <dl>
                <dt>
                  <a href="javascript:;">
                    <img src="../../img/s1127135.jpg" class="m_sub_img">
                  </a>
                </dt>
                <dd>
                  <a href="javascript:;">狂人日记</a>
                  <p class="extra-info"></p>
                </dd>
              </dl>
              <div class="clearfix rr" style="width:100%"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {},
  created() {}
};
</script>
<style>
@import "../../lib/font/border/master.css";
@import "../../lib/font/border/body.css";
@import "../../lib/font/border/footer&header.css";
/* 
	body,div,dl,dt,dd,ul,li,h1,h2,h3,h4,h5,h6,pre,code,form,fieldset,legend,input,button,textarea,blockquote {
		margin:0;
		padding:0
	}
	table {
		border-collapse:collapse;
		border-spacing:0
	}
	fieldset,img {
		border:0
	}
	address,caption,cite,code,dfn,em,i,strong,th,var,optgroup {
		font-style:normal;
		font-weight:normal
	}
	ul,ol {
		list-style:none
	}
	caption,th {
		text-align:left
	}
	h1,h2,h3,h4,h5,h6 {
		font-size:100%;
		font-weight:normal
	}
	q:before,q:after {
		content:""
	}
	abbr,acronym {
		border:0;
		font-variant:normal
	}
	sup {
		vertical-align:baseline
	}
	sub {
		vertical-align:baseline
	}
	legend {
		color:#000
	}
	input,button,textarea,select,optgroup,option {
		font-family:inherit;
		font-size:inherit;
		font-style:inherit;
		font-weight:inherit
	}
	input,button,textarea,select {
		*font-size:100%
	}
	pre {
		white-space:pre-wrap;
		word-wrap:break-word
	}
	a {
		cursor:pointer
	}
	a:link {
		color:#37a;
		text-decoration:none
	}
	a:visited {
		color:#669;
		text-decoration:none
	}
	a:hover {
		color:#fff;
		text-decoration:none;
		background:#37a
	}
	a:active {
		color:#fff;
		text-decoration:none;
		background:#f93
	}
	a img {
		border-width:0;
		vertical-align:middle
	}
	body,td,th {
		font:12px Helvetica,Arial,sans-serif;
		line-height:1.62
	}
	table {
		border-collapse:collapse;
		border:none;
		padding:0;
		margin:0
	}
	wbr:after {
		content:"\00200B"
	}
	textarea {
		resize:none
	}
	input[type=text]:focus,input[type=password]:focus,textarea:focus {
		outline:none
	}
	.clearfix:after {
		content:".";
		display:block;
		height:0;
		clear:both;
		visibility:hidden
	}
	.clearfix {
		zoom:1;
		display:inline-block;
		_height:1px
	}
	* html .clearfix {
		height:1%
	}
	*+html .clearfix {
		height:1%
	}
	.clearfix {
		display:block
	}
	.clearfloat {
		display:inline-block;
		*display:inline;
		*zoom:1
	}
	#wrapper {
		width:950px;
		margin:0 auto
	}
	#content {
		min-height:420px
	}
	#footer {
		color:#999;
		padding:6px 0;
		margin-top:40px;
		overflow:hidden;
		zoom:1;
		border-top:1px dashed #ddd
	}
	.grid-16-8 .article {
		float:left;
		width:590px;
		padding-right:40px
	}
	.grid-16-8 .article .switch-to-shuo {
		float:right;
		margin-top:-45px
	}
	.grid-16-8 .article .switch-to-shuo a {
		display:block;
		width:134px;
		height:38px;
		background:url(/f/book/6822457a2fc71115d0774dfaf5c9d245577d5992/pics/switch_to_shuo.png) no-repeat left top
	}
	.grid-16-8 .article .switch-to-shuo a:hover {
		background-position:left -38px
	}
	.grid-16-8 .article .switch-to-shuo a:active {
		background-position:left -76px
	}
	.grid-16-8 .aside {
		float:right;
		width:310px
	}
	.grid-4-14-6 .nav {
		float:left;
		width:150px;
		margin-right:10px
	}
	.grid-4-14-6 .article {
		float:left;
		width:540px;
		padding-right:10px
	}
	.grid-4-14-6 .aside {
		float:right;
		width:230px
	}
	fieldset {
		border:1px solid #ddd;
		padding:0 10px;
		margin-bottom:15px
	}
	fieldset legend {
		color:#666;
		padding:0 5px
	}
	input {
		margin-right:3px;
		vertical-align:middle
	}
	label {
		font-family:Tahoma;
		vertical-align:middle
	}
	#footer .gray-link a:link,#footer .gray-link a:visited,#footer .gray-link a:active {
		color:#999;
		background:none
	}
	#footer .gray-link a:hover {
		color:#fff;
		background:#999
	}
	#footer .blue-link a:link,#footer .blue-link a:visited,#footer .blue-link a:active {
		color:#37a;
		background:none
	}
	#footer .blue-link a:hover {
		color:#fff;
		background:#37a
	}
	a.processing:link,a.processing:visited {
		color:#666
	}
	a.processing:hover,a.processing:active {
		background-color:#666;
		color:#fff
	}
	.col-3 {
		clear:both;
		margin-bottom:15px
	}
	.col-3 li {
		float:left;
		width:330px;
		margin-bottom:5px
	}
	.col-3 li.first {
		width:290px
	}
	.col-3 li.last {
		width:320px
	}
	.col-3 li a:link,.col-4 li a:link,.col-3 li a:visited,.col-4 li a:visited,.col-3 li a:active,.col-4 li a:active {
		color:#999;
		background:none
	}
	.col-3 li a:hover,.col-4 li a:hover {
		color:#fff;
		background:#999
	}
	.col-4 {
		clear:both;
		margin-bottom:15px;
	}
	.col-4 li {
		float:left;
		display:inline;
		margin:0 44px 5px 0;
	}
	.extra {
		clear:both;
		text-align:right
	}
	#maxw {
		margin:0 auto;
		padding:8px 15px;
		background:#FFF;
		width:964px;
		overflow:hidden
	}
	.ellipsis {
		-o-text-overflow:ellipsis;
		text-overflow:ellipsis;
		overflow:hidden
	}
	form {
		margin:0;
		padding:0;
		border:0px
	}
	fieldset.site {
		border:none;
		padding:0;
		margin:0
	}
	fieldset.site legend {
		display:none
	}
	fieldset.site label {
		width:120px;
		font-size:14px;
		float:left;
		overflow:hidden
	}
	.fsct {
		margin-bottom:5px
	}
	.fsctm {
		margin-left:130px
	}
	input.other,.detail input.other {
		border:none;
		padding:0
	}
	ol {
		padding:0 0 0 20px
	}
	textarea {
		font-family:Arial;
		overflow:auto
	}
	input {
		font-size:12px
	}
	a {
		cursor:pointer
	}
	a:link {
		color:#37a;
		text-decoration:none
	}
	a:visited {
		color:#666699;
		text-decoration:none
	}
	a:hover {
		color:#FFFFFF;
		text-decoration:none;
		background:#37a
	}
	a:active {
		color:#FFFFFF;
		text-decoration:none;
		background:#FF9933
	}
	a img {
		border-width:0;
		vertical-align:middle
	}
	table {
		border-collapse:collapse;
		border:none;
		padding:0;
		margin:0
	}
	h1 {
		word-wrap:break-word;
		display:block;
		font-size:25px;
		font-weight:bold;
		color:#494949;
		margin:0;
		padding:0 0 15px 0;
		line-height:1.1
	}
	h1 .year {
		color:#888
	}
	h3 {
		margin-left:4px;
		font:14px Arial,Helvetica,sans-serif;
		color:#666666;
		margin-bottom:1px;
		line-height:1.8;
		background-color:#f2fbf2
	}
	h3 img {
		margin-top:-2px
	}
	ul {
		list-style-type:none;
		margin:0;
		padding:0
	}
	h4 {
		height:26px;
		margin:0 0 10px 4px;
		overflow:hidden;
		font:12px Arial,Helvetica,sans-serif;
		color:#666;
		line-height:1.62;
		background-color:#f2fbf2
	}
	h2 {
		font:15px Arial,Helvetica,sans-serif;
		color:#072;
		margin:0 0 12px 0;
		line-height:150%
	}
	.wrap {
		background-color:#f2fbf2;
		display:block
	}
	.wrap h3 {
		margin-top:20px
	}
	.obssin {
		width:100%
	}
	.sline {
		border-bottom:1px solid #a8a8a8
	}
	#header {
		background:url(/f/book/007a753500d3779e629c87f4d13b3103451f6dfd/pics/headnavbot.gif) no-repeat scroll left 33px;
		margin:7px 0
	}
	#header img.logo {
		float:left;
		margin-top:-3px
	}
	#page_focus {
		border:1px solid #ccc;
		margin:0 10px 0 0;
		height:16px;
		width:171px;
		padding:2px 0 0 2px
	}
	#page_focus:focus {
		border:1px solid #686868
	}
	#nav {
		padding-top:3px
	}
	#nav a {
		float:left;
		display:block;
		text-decoration:none;
		color:#368332;
		font-size:14px;
		margin:2px 5px 0 5px;
		padding:8px 4px 7px 4px;
		line-height:14px
	}
	#nav a:hover {
		background-color:transparent;
		text-decoration:underline
	}
	#nav a.now {
		font-size:14px;
		margin:2px 5px 0 5px;
		float:left;
		display:block;
		background:url(/f/book/e02eb97fd22309868c6cea1f9914151685377942/pics/headnavback.gif) no-repeat scroll right top #eef9eb;
		padding:0 10px 0 0;
		color:black
	}
	#nav a.now span {
		background:transparent url(/f/book/e02eb97fd22309868c6cea1f9914151685377942/pics/headnavback.gif) no-repeat;
		display:block;
		padding:8px 1px 7px 11px
	}
	#nav .nine_nav:hover,#nav .nine_nav {
		color:#F92D09;
		margin-left:25px
	}
	#db-nav-movie .site-nav-items li.site-nav-bt {
		padding-top:8px
	}
	#db-nav-movie .site-nav-items li.site-nav-bt a:link,#db-nav-movie .site-nav-items li.site-nav-bt a:visited,#db-nav-movie .site-nav-items li.site-nav-bt a:hover,#db-nav-movie .site-nav-items li.site-nav-bt a:active {
		font-size:12px;
		display:block;
		word-break:keep-all;
		white-space:nowrap;
		width:60px;
		text-align:center;
		border-radius:2px;
		padding:4px 0;
		-webkit-border-radius:2px;
		-moz-border-radius:2px;
		background:#F4F4F4;
		line-height:12px;
		color:#0090B3;
		overflow:hidden
	}
	#searbar {
		margin-top:5px;
		*margin-bottom:-5px
	}
	#searbar span {
		margin:0;
		height:14.8px;
		display:block;
		line-height:14.8px;
		float:right;
		position:relative
	}
	#searbar span.submit {
		width:44px;
		height:20px;
		background:url(/f/book/e6efbcb5e43ed4924f68589bc1d72849b410f55e/pics/search.gif) no-repeat;
		padding:2px 7px 0 0;
		*padding-top:3px;
		text-align:right
	}
	#searbar span.submit a {
		letter-spacing:4px
	}
	#searbar a.arrow:hover {
		background:none
	}
	#dsearch,#tongcheng_tab_block {
		padding:5px 0;
		display:none;
		position:absolute;
		text-align:center;
		width:69px;
		background:#fff;
		border:1px solid #c0c0c0;
		top:19px;
		left:-51px;
		z-index:100
	}
	#tongcheng_tab_block {
		left:5px;
		top:18px
	}
	#dsearch a {
		display:block;
		padding:3px;
		text-decoration:none
	}
	#dsearch a:hover,#tongcheng_tab_block a:hover {
		color:white;
		background:#37a;
		text-decoration:underline
	}
	#tongcheng_tab_block a {
		margin:0;
		float:none;
		display:block;
		padding:5px
	}
	#searbar .up {
		display:none;
		vertical-align:top
	}
	#searbar .down {
		display:inline;
		vertical-align:top
	}
	#status {
		background:url(/f/book/007a753500d3779e629c87f4d13b3103451f6dfd/pics/headnavbot.gif) no-repeat scroll left bottom #eef9eb;
		text-align:right;
		padding:5px 10px 4px 10px
	}
	#status a {
		text-decoration:none;
		margin:2px 1px 3px 7px;
		letter-spacing:0.3px;
		color:#37a
	}
	#status a:hover {
		color:white
	}
	#status {
		*padding:2px 10px 4px 10px
	}
	#subnav {
		float:left;
		padding:0 5px 3px 2px;
		width:65%;
		text-align:center
	}
	#subnav a {
		text-decoration:none;
		letter-spacing:1px;
		margin:0 8px;
		color:#37a
	}
	#subnav a:hover {
		color:white
	}
	.cc {
		text-align:center
	}
	.ll {
		float:left
	}
	.rr {
		float:right
	}
	.trr {
		text-align:right
	}
	a.graybutt {
		overflow:hidden;
		background:transparent url(/f/book/b3cf1cc4be8314e372bf1340e487cb218908cbe2/pics/graybutt.gif) no-repeat scroll right top;
		color:#666666;
		display:block;
		height:24px;
		padding-right:7px;
		font:normal 12px sans-serif;
		margin-right:5px;
		text-decoration:none;
		cursor:pointer
	}
	a.graybutt input {
		*margin-top:-1px;
		padding:0;
		line-height:18px;
		background:none;
		color:#666;
		border:0;
		cursor:pointer;
		*width:auto;
		_width:0;
		*overflow:visible
	}
	a.graybutt span {
		background:transparent url(/f/book/b3cf1cc4be8314e372bf1340e487cb218908cbe2/pics/graybutt.gif) no-repeat;
		display:block;
		padding:4px 1px 3px 8px;
		line-height:18px;
		*padding-top:5px
	}
	a.graybutt:visited {
		color:#ff7676;
		text-decoration:none
	}
	a.graybutt:hover {
		background:transparent url(/f/book/b3cf1cc4be8314e372bf1340e487cb218908cbe2/pics/graybutt.gif) no-repeat right -24px;
		color:white
	}
	a.graybutt:hover span,a.graybutt:hover input {
		background-position:left -24px;
		color:white
	}
	a.redbutt {
		overflow:hidden;
		background:transparent url(/f/book/29afd5838a10209ae1972fb7ab08da6864f38d15/pics/redbutt.gif) no-repeat scroll right top;
		color:#ff7676;
		height:24px;
		padding-right:7px;
		font:normal 12px sans-serif;
		margin:0 5px 0 0;
		text-decoration:none;
		display:inline-block;
		*display:inline;
		zoom:1;
		cursor:pointer
	}
	a.redbutt span {
		background:transparent url(/f/book/29afd5838a10209ae1972fb7ab08da6864f38d15/pics/redbutt.gif) no-repeat;
		display:block;
		padding:4px 1px 4px 8px;
		line-height:18px;
		color:#ff7676
	}
	html * a.redbutt span {
		padding-top:4px
	}
	a.redbutt input {
		*margin-top:-1px;
		padding:0;
		line-height:18px;
		background:none;
		color:#ff7676;
		border:0;
		cursor:pointer;
		*width:auto;
		_width:0;
		*overflow:visible
	}
	a.redbutt:visited {
		color:#ff7676;
		text-decoration:none
	}
	a.redbutt:hover {
		background:transparent url(/f/book/29afd5838a10209ae1972fb7ab08da6864f38d15/pics/redbutt.gif) no-repeat right -24px;
		color:white
	}
	a.redbutt:hover span,a.redbutt:hover input {
		background-position:left -24px;
		color:white
	}
	a.colbutt {
		letter-spacing:3px;
		overflow:hidden;
		background:transparent url(/f/book/18e38327efbf8ae659e972e34ece128a73f469f3/pics/collect_back2.png) no-repeat scroll right top !important;
		color:#000;
		display:block;
		height:24px;
		padding-right:7px;
		font:normal 12px sans-serif;
		margin-right:10px;
		text-decoration:none
	}
	a.colbutt:hover {
		color:#000
	}
	a.colbutt span {
		background:transparent url(/f/book/18e38327efbf8ae659e972e34ece128a73f469f3/pics/collect_back2.png) no-repeat;
		display:block;
		padding:1px 1px 3px 11px;
		line-height:22px
	}
	a.colbutt span em {
		font-style:normal;
		color:#111
	}
	a.colbutt:visited {
		color:#777;
		text-decoration:none
	}
	textarea {
		border:1px solid #ccc;
		padding:3px;
		font-size:14px
	}
	.area_miniblog {
		width:304px;
		height:86px;
		padding:3px;
		border:1px solid #ccc;
		margin-bottom:5px
	}
	#rec_url_text {
		width:240px;
		border:1px solid #ccc
	}
	.input_search {
		padding:2px;
		border:1px solid #ccc;
		margin-bottom:5px
	}
	#tabler .input_search {
		width:290px
	}
	.input_basic {
		border:1px solid #ccc;
		padding:2px;
		font-size:12px
	}
	.input_basic2 {
		border:1px solid #ccc;
		padding:3px;
		font-size:14px
	}
	#vote_btn input.vote_btn {
		background:url(/f/book/51c6e1c1fa6f9c2e887881d4e38e1cc15fea9ce7/pics/icon/vote_48_18px.gif) no-repeat right top;
		border:0;
		width:48px;
		height:18px;
		cursor:pointer;
		margin-left:12px
	}
	#vote_btn_small input.vote_btn {
		background:url(/f/book/77610f59391376ab9b94d4aa156e7ad9642a1e23/pics/icon/vote_30_15px.gif) no-repeat right top;
		border:0;
		width:30px;
		height:15px;
		cursor:pointer;
		margin-left:5px
	}
	.tc {
		text-align:center
	}
	.lst {
		width:100%;
		padding:5px 0px 5px 0px
	}
	.tlst {
		padding:5px 0 15px 0;
		margin:0
	}
	.clst {
		padding:0 0 0 105px;
		float:none;
		overflow:hidden;
		word-wrap:break-word
	}
	.ilst {
		width:105px;
		display:block;
		float:left;
		text-align:center;
		margin:-27px -105px 0 0
	}
	#review .ilst,.block1 .ilst {
		margin-top:-17px
	}
	.nlst {
		background:#f2fbf2;
		margin:0 0 0 102px
	}
	.ctsh .nlst {
		padding:0 0 0 5px;
		margin:0 0 0 71px
	}
	.ctsh .clst {
		padding:0 0 0 80px;
		width:85%;
		float:left !important;
		_float:none;
		overflow:hidden;
		word-wrap:break-word
	}
	.ctsh .ilst {
		width:85px;
		display:block;
		float:left;
		text-align:center;
		margin:-26px -85px 0 -6px
	}
	.xbar {
		float:right;
		background:url(/f/book/8ddf79d5c3cc04548e58009788aa96dac5ba0982/pics/zbar.gif) no-repeat;
		width:100%;
		margin-bottom:21px;
		overflow:hidden
	}
	.xbar div {
		float:right;
		background:url(/f/book/8ddf79d5c3cc04548e58009788aa96dac5ba0982/pics/zbar.gif) no-repeat right top;
		margin-left:5px;
		padding-right:35px;
		width:100%\9
	}
	.xbar a {
		float:right;
		display:block;
		text-decoration:none;
		margin:5px 5px 1px 5px;
		padding:3px 5px 2px 5px;
		line-height:14px
	}
	.xbar a:hover {
		color:white
	}
	.xbar span.now {
		margin:0 5px 0 5px;
		float:right;
		display:block;
		background:url(/f/book/79729f7ed4018d6c7545c866789c658aa85314c5/pics/wztab.gif) no-repeat scroll right top;
		padding:0 10px 0 0
	}
	.xbar span.now span {
		background:transparent url(/f/book/79729f7ed4018d6c7545c866789c658aa85314c5/pics/wztab.gif) no-repeat;
		display:block;
		padding:6px 1px 5px 11px
	}
	.zbar {
		background:url(/f/book/8ddf79d5c3cc04548e58009788aa96dac5ba0982/pics/zbar.gif) no-repeat;
		margin-bottom:21px
	}
	.zbar div {
		float:left;
		background:url(/f/book/8ddf79d5c3cc04548e58009788aa96dac5ba0982/pics/zbar.gif) no-repeat right top;
		margin-left:5px;
		padding-left:2px
	}
	.zbar a {
		float:left;
		display:block;
		text-decoration:none;
		margin:5px 5px 1px 5px;
		padding:3px 5px 2px 5px;
		line-height:14px
	}
	.zbar a:hover {
		color:white
	}
	.zbar span.now {
		margin:0 5px 0 5px;
		float:left;
		display:block;
		background:url(/f/book/79729f7ed4018d6c7545c866789c658aa85314c5/pics/wztab.gif) no-repeat scroll right top;
		padding:0 10px 0 0
	}
	.zbar span.now span {
		background:transparent url(/f/book/79729f7ed4018d6c7545c866789c658aa85314c5/pics/wztab.gif) no-repeat;
		display:block;
		padding:6px 1px 5px 11px
	}
	#sspform {
		text-align:center;
		padding:0 0 18px 0;
		vertical-align:middle;
		margin:0
	}
	*+html #ssform {
		padding-top:0
	}
	#sspform .text {
		width:400px;
		border:1px solid #ddd
	}
	.infobox {
		width:100%;
		table-layout:fixed;
		margin-bottom:20px
	}
	.infobox h2 {
		margin-top:0
	}
	.infobox form {
		margin:0
	}
	.tablelt {
		background:url(/f/book/b643020218d4176d6b9ecc30d1eba30418ded183/pics/ibox.gif);
		height:3px;
		width:3px
	}
	.tablect {
		background:url(/f/book/6e017106b8fca7e6123a102c77ef8846dc7a5d39/pics/tablev.gif);
		height:3px
	}
	.tablert {
		background:url(/f/book/b643020218d4176d6b9ecc30d1eba30418ded183/pics/ibox.gif) right top;
		height:3px;
		width:3px
	}
	.tablelc {
		background:url(/f/book/b554b424a2f07aa9c0e1d77457ecc0bf1c255629/pics/tableh.gif);
		width:3px
	}
	.tablecc {
		background:#fff6ee;
		padding:6px;
		margin-bottom:20px
	}
	.tablerc {
		background:url(/f/book/b554b424a2f07aa9c0e1d77457ecc0bf1c255629/pics/tableh.gif) right;
		width:3px
	}
	.tablelb {
		background:url(/f/book/b643020218d4176d6b9ecc30d1eba30418ded183/pics/ibox.gif) 0px bottom;
		height:3px;
		width:3px
	}
	.tablecb {
		background:url(/f/book/6e017106b8fca7e6123a102c77ef8846dc7a5d39/pics/tablev.gif) left bottom;
		height:3px
	}
	.tablerb {
		background:url(/f/book/b643020218d4176d6b9ecc30d1eba30418ded183/pics/ibox.gif) right bottom;
		height:3px;
		width:3px
	}
	.detail input {
		padding:3px
	}
	.detail a.redbutt {
		padding-right:4px;
		margin-right:2px
	}
	.gtleft {
		padding:4px 4px 0 0;
		float:left
	}
	.gtleft .pl2 {
		line-height:1em
	}
	.gtright {
		padding:4px;
		float:right
	}
	#user h1 {
		padding:8px 0 7px 0
	}
	#user img {
		float:left;
		padding:12px 12px 30px 0px
	}
	.usernav {
		margin:0 0 20px -8px
	}
	.usernav a {
		letter-spacing:1px;
		padding:4px 8px 0 0;
		margin:4px 3px 4px 1px;
		border-top:1px dashed #ccc
	}
	.collect {
		padding:5px 0 15px 0;
		margin:0;
		float:left;
		width:100%
	}
	.collect h3 {
		padding-top:3px;
		font:14px Arial,Helvetica,sans-serif;
		line-height:120%;
		background-color:#f2fbf2;
		margin:0 0 0 4px
	}
	.collect h3 a {
		color:#072
	}
	.collect h3 a:hover {
		color:#fff;
		background:#072
	}
	.rnotes pre {
		font:12px/162% Arial,Helvetica,sans-serif;
		white-space:pre-wrap;
		word-wrap:break-word
	}
	pre.source {
		font:12px/162% Arial,Helvetica,sans-serif;
		white-space:pre-wrap;
		word-wrap:break-word
	}
	pre.content {
		font:12px/162% Arial,Helvetica,sans-serif;
		white-space:pre-wrap;
		word-wrap:break-word
	}
	blockquote {
		padding-left:2em;
		color:#404040;
		background:url(/f/book/070c48da6028490b9ca087a2a2eec5e6346e65d8/pics/big_quotel.png) no-repeat 0 0;
		margin:15px
	}
	.broadsmr {
		padding:5px 24px;
		color:#999
	}
	.quote {
		overflow:hidden;
		padding:0 24px 5px 15px;
		margin:8px 0 0 26px;
		background:url(/f/book/bea926c649298e9bd59b7e8897f0c34b252a57b9/pics/quotel.png) no-repeat left 4px;
		width:auto;
		*zoom:1;
		word-wrap:break-word
	}
	.quote span.inq {
		display:inline;
		background:url(/f/book/61a8c24be622b61a59a8c3445dec15f2ce590e9b/pics/quoter.png) no-repeat right bottom;
		color:#333;
		padding-right:15px;
		display:inline-block;
		word-break:break-all
	}
	.broadimg {
		border:1px solid #ddd;
		float:right;
		margin-left:14px
	}
	.blst {
		padding:0;
		margin:0
	}
	.blst li {
		border-top:1px solid #ddd;
		padding:6px 0
	}
	.hiddenlogin {
		margin:5px;
		display:none;
		clear:both;
		padding:5px
	}
	.hiddenlogin input {
		margin-right:20px
	}
	.hiddenlogin input.text {
		width:130px;
		margin-right:10px
	}
	.m {
		font-size:14px;
		line-height:120%;
		color:#072
	}
	.m a,.m a:visited,a.m,a.m:visited {
		font-size:14px;
		line-height:120%;
		color:#072;
		text-decoration:none
	}
	.m a:hover,a.m:hover {
		font-size:14px;
		line-height:120%;
		color:#fff;
		text-decoration:none;
		background:#072
	}
	.m a:active,a.m:active {
		color:#fff;
		text-decoration:none;
		background:#FFAAFF
	}
	.pt {
		width:100%;
		padding:0;
		margin:0
	}
	.pl {
		font:12px Arial,Helvetica,sans-serif;
		line-height:150%;
		color:#666666
	}
	.pl2 {
		font:14px Arial,Helvetica,sans-serif;
		line-height:150%;
		color:#666666
	}
	.l2 {
		font:14px Arial,Helvetica,sans-serif;
		line-height:150%
	}
	.hiddenerr {
		display:none;
		background-color:#FFF6EE;
		color:#ff1111;
		margin:0 2px
	}
	.alert {
		background-color:#FFF6EE;
		border:1px solid #CCCCCC
	}
	.attn {
		color:#FF3300
	}
	.hidden {
		display:none
	}
	.clear {
		clear:both;
		line-height:0;
		font-size:0
	}
	.greyinput {
		color:#ccc
	}
	.errnotnull {
		color:#ff0000
	}
	.indent {
		word-break:break-all
	}
	#table {
		float:left;
		margin:0 -310px 0 0;
		width:100%
	}
	#in_table {
		margin:0 310px 0 0;
		padding:0 40px 0 0;
		min-height:500px
	}
	#tabler {
		float:right;
		width:310px;
		overflow:hidden;
		word-break:break-all
	}
	#tablem {
		float:left;
		margin:0 -270px 0 0;
		width:100%
	}
	#in_tablem {
		margin:0 270px 50px 0;
		padding:0 40px 0 0
	}
	#tablerm {
		float:right;
		width:270px;
		overflow:hidden;
		word-break:break-all
	}
	#tables {
		float:left;
		margin:0 -240px 0 0;
		width:100%
	}
	#in_tables {
		margin:0 240px 0 0;
		padding:0 40px 0 0;
		min-height:500px
	}
	#tablers {
		float:right;
		width:240px;
		overflow:hidden;
		word-break:break-all
	}
	#tablerb .indent,#tabler .indent,#tablerm .indent {
		margin-bottom:40px;
		overflow:hidden
	}
	.aside .indent {
		margin-bottom:40px
	}
	.notify input {
		margin-top:9px
	}
	.mbt {
		padding:0;
		margin:0;
		clear:both;
		word-wrap:break-word
	}
	.mbt tr {
		vertical-align:top
	}
	.mbtl {
		float:left;
		width:55px;
		margin:8px 7px 0 0;
		padding:0
	}
	.mbtr {
		border-bottom:1px solid #eee;
		padding:5px 0;
		min-height:55px;
		overflow:hidden;
		margin:5px 0 5px 0
	}
	.mbtr2 {
		margin-bottom:20px;
		overflow:hidden
	}
	ul .mbtr2 {
		border-bottom:1px solid #ddd
	}
	.mbtrdot {
		padding:4px 0;
		min-height:55px;
		overflow:hidden
	}
	.mbtrmini {
		border-bottom:1px dashed #ddd;
		padding:4px 0 4px 12px;
		background:url(/f/book/f401be4d392b6e745a52fa51664a5da4a38ebb59/pics/listdot.gif) 0 8px no-repeat
	}
	* html .mbtr {
		word-break:break-all;
		height:55px;
		overflow:visible
	}
	* html .mbtrdot {
		word-wrap:break-word;
		word-break:break-all;
		height:55px;
		overflow:visible
	}
	* html .mbtrmini {
		word-break:break-all;
		overflow:visible
	}
	.mbdiv {
		padding-top:10px 0 6px 0;
		border-top:1px dashed #DDDDDD
	}
	.fdiv {
		text-align:right;
		padding-top:5px;
		margin-top:40px;
		clear:both;
		color:#999
	}
	.fdiv .ul {
		margin-bottom:5px;
		padding-top:5px
	}
	.fspl {
		float:left
	}
	.indentb {
		padding:0 18px
	}
	.fil {
		float:left;
		display:inline;
		padding-right:15px;
		padding-bottom:15px
	}
	.obmor {
		text-align:right
	}
	.obmo {
		line-height:180%
	}
	.act {
		color:#FF5555;
		text-decoration:none;
		font-size:12px;
		text-align:center;
		border-right:1px solid #FFAAAA;
		border-bottom:1px solid #FFAAAA;
		background-color:#FFDDDD;
		padding:3px 3px 2px 3px;
		cursor:pointer
	}
	.act:hover {
		color:#FFFFFF;
		font-size:12px;
		background-color:#FF5555;
		border-right:1px solid #FF3333;
		border-bottom:1px solid #FF3333;
		padding:3px 3px 2px 3px;
		cursor:pointer
	}
	.act a:link {
		text-decoration:none;
		color:#FF5555;
		font-size:12px;
		text-align:center;
		padding:3px 3px 2px 3px
	}
	.act a:visited {
		text-decoration:none;
		color:#FF5555;
		font-size:12px;
		text-align:center;
		padding:3px 3px 2px 3px
	}
	.act a:hover {
		color:#FFFFFF;
		font-size:12px;
		background-color:#FF5555;
		border-style:none;
		padding:3px 3px 2px 3px
	}
	.ract {
		border:2px solid #FFFFFF;
		padding:0px;
		cursor:pointer;
		float:left
	}
	.ract a:link {
		border:2px solid #FFFFFF;
		padding:0px;
		cursor:pointer;
		float:left
	}
	.ract a:visited {
		border:2px solid #FFFFFF;
		padding:0px;
		cursor:pointer;
		float:left
	}
	.ract a:hover {
		text-decoration:none;
		font-size:12px;
		text-align:center;
		border-right:1px solid #FF7777;
		border-bottom:1px solid #FF7777;
		background-color:#FFCCCC;
		border-top:1px solid #FFCCCC;
		border-left:1px solid #FFCCCC;
		padding:1px;
		cursor:pointer;
		float:left
	}
	.gact {
		color:#BBBBBB;
		font-size:12px;
		text-align:center;
		cursor:pointer
	}
	.gact a:link,a.gact:link {
		color:#BBBBBB;
		font-size:12px;
		text-decoration:none;
		text-align:center
	}
	.gact a:visited,a.gact:visited {
		color:#BBBBBB;
		font-size:12px;
		text-decoration:none;
		text-align:center
	}
	.gact a:hover,a.gact:hover {
		color:#FFFFFF;
		font-size:12px;
		border-left:1px solid #FF9999;
		border-top:1px solid #FF9999;
		border-right:1px solid #FF3333;
		border-bottom:1px solid #FF3333;
		background-color:#773333;
		text-align:center
	}
	.infobox a.gact:link,.infobox a.gact:visited,.infobox .gact a:link,.infobox .gact a:visited {
		border-color:#fff6ee
	}
	.infobox a.gact:hover,.infobox .gact a:hover {
		border-color:#f99 #f33 #f33 #f99
	}
	.ul {
		border-bottom:1px dashed #DDDDDD;
		line-height:100%;
		clear:both
	}
	#tablerm .indent p.ul {
		margin:0;
		padding:5px 0
	}
	.st {
		width:100%
	}
	.rbar {
		color:#DDDDDD;
		font:11px Arial,Helvetica,sans-serif
	}
	.bs {
		margin:0px;
		padding:0px
	}
	.bs li {
		border-bottom:1px dashed #ddd;
		margin:0;
		padding:4px 0;
		overflow:hidden
	}
	.bs.noline li {
		border:none
	}
	.bs.more-after {
		margin-bottom:15px
	}
	.bs .buylink-price {
		_vertical-align:2px
	}
	.obs {
		margin:0 0 10px 0;
		float:left;
		text-align:center;
		overflow:hidden;
		width:103px
	}
	.obs_oneline {
		margin:0
	}
	.obs dt {
		height:114px;
		width:103px;
		overflow:hidden
	}
	.obs dd {
		margin:0;
		height:60px;
		overflow:hidden
	}
	.obs_oneline dt {
		height:100px
	}
	.related_info h2 {
		margin-top:24px;
		margin-bottom:3px
	}
	.after_h1 {
		margin-top:-24px
	}
	.obu {
		margin:0 0 10px 0;
		width:76px;
		float:left;
		display:inline;
	}
	.obu dt {
		margin:0;
		height:50px;
		overflow:hidden;
		text-align:center;
		line-height:16px
	}
	.obu dd {
		margin:0px;
		height:55px;
		text-align:center;
		overflow:hidden
	}
	.ob {
		margin:0 0 10px 0;
		float:left;
		width:76px;
		text-align:center
	}
	.ob dt {
		margin:0;
		overflow:hidden;
		text-align:center;
		height:50px
	}
	.ob dd {
		margin:0;
		height:55px;
		text-align:center;
		overflow:hidden
	}
	.ob span {
		white-space:nowrap
	}
	.cloud1 a {
		font:12px Arial,Helvetica,sans-serif;
		line-height:24px
	}
	.cloud2 a {
		font:14px bold Arial,Helvetica,sans-serif;
		line-height:24px
	}
	.cloud3 a {
		font:18px Arial,Helvetica,sans-serif;
		line-height:24px
	}
	.cloud4 a {
		font:21px bold Arial,Helvetica,sans-serif;
		line-height:24px
	}
	input.readonly,textarea.readonly {
		background:#F8F8F8;
		color:#888888
	}
	.aob {
		float:left;
		width:105px;
		height:105px;
		display:block;
		text-align:center;
		overflow:hidden;
		margin:3px 0
	}
	.aob2 {
		float:left;
		margin-right:25px;
		display:block;
		text-align:left;
		overflow:hidden;
		margin:0 25px 30px 0
	}
	.plr {
		font:12px Arial,Helvetica,sans-serif;
		line-height:150%;
		color:#666666;
		float:right
	}
	.pllb {
		font:12px Arial,Helvetica,sans-serif;
		line-height:150%;
		color:#666666;
		float:left;
		display:block
	}
	.paginator {
		font:14px Arial,Helvetica,sans-serif;
		color:#aaa;
		margin:20px 0;
		line-height:150%;
		text-align:center
	}
	.paginator a,.thispage,.break {
		padding:0px 4px;
		margin:2px
	}
	.paginator .prev {
		margin-right:20px
	}
	.paginator .next {
		margin-left:20px
	}
	.paginator .next a,.paginator .prev a {
		padding:0;
		margin:0
	}
	.paginator .count {
		margin-left:20px;
		font-size:14px
	}
	.paginator .thispage {
		color:#fff;
		background:#83BF73
	}
	.paginator .break {
		color:#999
	}
	.paginator .thispage {
		color:#fff;
		background:#83BF73
	}
	.paginator .break {
		color:#999
	}
	.olt {
		width:100%;
		padding:0;
		margin-bottom:3px
	}
	.olt td {
		border-bottom:1px dashed #DDDDDD;
		padding:3px 3px 3px 0;
		word-wrap:break-word;
		word-break:break-word
	}
	.olt td.date {
		width:75px;
		text-align:center;
		color:#999;
		padding-right:0
	}
	.olt .tb-author {
		min-width:6em
	}
	.wr {
		table-layout:fixed;
		word-wrap:break-word;
		width:100%;
		overflow:hidden
	}
	.wrtd {
		width:48px;
		vertical-align:top
	}
	.txd textarea {
		width:98%
	}
	.olts {
		padding:0;
		border-collapse:collapse;
		width:100%
	}
	.olts td {
		padding-top:3px;
		border-bottom:1px dashed #ddd
	}
	.olts td a img {
		display:block
	}
	.pil {
		height:48px;
		width:48px
	}
	.piil {
		float:left;
		margin:0 -65px 0 0
	}
	.piir {
		float:right;
		margin:0 0 0 65px;
		overflow:hidden;
		width:88.5%
	}
	.review-short .ll {
		margin:0 1em 0 0
	}
	.tlst .obss {
		width:100%;
		display:block;
		margin:7px 0;
		color:#666
	}
	.tlst .obss a:link {
		color:#666
	}
	.tlst .obss a:hover {
		color:#fff;
		background:#666
	}
	.pltr {
		font:12px Arial,Helvetica,sans-serif;
		line-height:150%;
		color:#666666;
		text-align:right
	}
	.mn {
		font:14px Arial,Helvetica,sans-serif;
		line-height:150%;
		color:#072
	}
	.wrc {
		word-wrap:break-word;
		overflow:hidden;
		margin-top:0
	}
	.namel dd {
		width:60px
	}
	.namel .obu dt input {
		vertical-align:text-top
	}
	.groupicon {
		padding-right:10px
	}
	wbr:after {
		content:"\00200B"
	}
	.fil15 {
		float:left
	}
	.fil15 img {
		padding-right:15px;
		padding-bottom:15px
	}
	.dir {
		padding:12px 0pt 0pt 12px;
		vertical-align:top
	}
	.dirsp {
		margin-bottom:10px
	}
	.dirsp span {
		font-size:14px
	}
	.imgg {
		float:left;
		margin-left:5px
	}
	.namel .imgnoga {
		float:left;
		margin-left:5px
	}
	.substatus {
		height:100px;
		line-height:100px;
		width:25px;
		float:left;
		display:block;
		font-size:12px;
		color:#acacac
	}
	#comments {
		width:100%;
		word-wrap:break-word;
		overflow:hidden;
		padding:20px 0 0
	}
	#divac {
		clear:both
	}
	.actbtns a {
		margin:0 12px 0 0
	}
	.actbtns a:hover {
		background:none
	}
	.subject {
		float:left;
		width:415px
	}
	#mainpic {
		margin:3px 0 0 0;
		float:left;
		text-align:center;
		margin:3px 12px 0 0;
		max-width:155px;
		overflow:hidden
	}
	#mainpic a img {
		margin-bottom:10px
	}
	* html #mainpic {
		left:-7px
	}
	#info {
		float:left;
		max-width:248px;
		word-wrap:break-word
	}
	.sub_ins .starstop {
		float:none;
		width:50px;
		display:inline;
		position:absolute
	}
	.marks {
		margin:10px 0 0 -7px;
		line-height:18px;
		font-size:10px
	}
	.clearbox {
		clear:both;
		width:100%
	}
	.clearbox:after {
		content:".";
		display:block;
		height:0;
		clear:both;
		visibility:hidden
	}
	.subjectwrap {
		position:relative;
		float:left;
		width:100%;
		margin-bottom:15px
	}
	#dialog {
		position:fixed;
		z-index:103;
		top:50%;
		left:50%;
		width:550px;
		margin-top:-140px;
		background-color:#FFFFFF;
		padding:0;
		border:1px solid #bbb;
		-moz-border-radius:4px;
		-webkit-border-radius:4px;
		border-radius:4px
	}
	#overlay {
		opacity:.2;
		filter:alpha(opacity=20);
		position:fixed;
		z-index:102;
		top:50%;
		left:50%;
		width:588px;
		margin-top:-148px;
		margin-left:-13px;
		background-color:#333;
		padding-top:20px\9;
		-moz-border-radius:6px;
		-webkit-border-radius:6px;
		border-radius:6px
	}
	.bgi {
		position:fixed;
		z-index:101;
		top:50%;
		left:50%;
		width:550px;
		margin-top:-140px;
		margin-left:-250px;
		border:none
	}
	* html #dialog {
		position:absolute;
		margin-top:expression(exp_dialog(this))
	}
	* html #overlay {
		margin-top:-140px;
		position:absolute;
		margin-top:expression(exp_overlay(this))
	}
	#dialog td {
		padding:7px
	}
	#dialog td.ul {
		padding:0
	}
	#dialog p {
		margin:0
	}
	#populartags {
		margin:3px 0 10px 0
	}
	#submits td {
		padding:15px 0 5px 0
	}
	* html #submits td {
		padding-bottom:0
	}
	.loadpop {
		padding:30px;
		text-align:center
	}
	#hiddendialog {
		display:none
	}
	#actchoice {
		float:right;
		display:inline;
		width:100px;
		border-left:1px dashed #ddd;
		padding:0 0 0 5px
	}
	#actchoice .m {
		margin-bottom:40px
	}
	#actchoice .rec-btn {
		margin:0
	}
	.pl_l {
		font:14px Arial,Helvetica,sans-serif;
		line-height:150%;
		width:80px;
		vertical-align:top;
		padding-top:4px
	}
	.pl_r {
		padding-top:4px;
		width:550px;
		vertical-align:top;
		vertical-align:top
	}
	.pl_r .w {
		width:390px
	}
	.location {
		line-height:180%;
		font-size:14px;
		margin-left:15px
	}
	.evtlstimg {
		float:left;
		text-align:center;
		width:85px;
		padding-top:3px
	}
	.actionbtns {
		float:right;
		text-align:right;
		width:120px;
		height:100px
	}
	.actbtn {
		display:block;
		text-align:center;
		border-bottom:1px dotted #ddd
	}
	.actcat {
		float:left;
		width:89px;
		margin-bottom:140px
	}
	.actlist {
		float:right;
		width:490px;
		*width:490px
	}
	.actlist h2 {
		margin-bottom:8px
	}
	.actlist-left {
		width:600px;
		*width:600px
	}
	.nof {
		*zoom:1;
		margin-bottom:20px
	}
	.nof:after {
		content:".";
		display:block;
		height:0;
		clear:both;
		visibility:hidden
	}
	.nof h2,.nof .intro {
		margin-left:120px
	}
	.actcatlst li {
		text-decoration:none;
		display:block;
		padding:4px 0;
		border-bottom:1px solid #ddd
	}
	.actcatlst li a {
		display:block
	}
	.actcatlst .now {
		background:url(/f/book/84cacc4100d94517bc93b776494c3ed5184a233e/pics/arrowright.gif) no-repeat right 10px;
		color:#77c5ee
	}
	.citysmr {
		width:45%;
		float:left;
		margin:10px 0 15px 0;
		padding:0 15px
	}
	.evt_short {
		float:left;
		margin-bottom:10px;
		width:100%
	}
	.citytitle {
		font-size:14px;
		color:#072;
		border-bottom:1px solid #ccc;
		margin:0 0 15px 0
	}
	.citysmr li {
		padding:10px 0 10px 0px;
		line-height:1.6em
	}
	.citysmr li .title {
		display:block
	}
	.evt_short li {
		line-height:1.6em
	}
	.citysmr li a {
		font-size:12px
	}
	.citysmr li .title a {
		font-size:14px
	}
	.actimgs {
		float:left;
		margin:9px 0 0 0;
		padding:3px;
		border:1px solid #ddd
	}
	.evtdesc {
		margin:5px 0 0 65px;
		color:#666
	}
	.evtdesc .gact {
		margin-left:10px
	}
	.actfromfri {
		line-height:1.6em;
		padding:.6em 0
	}
	.actfromfri .event_long {
		float:left;
		padding-bottom:1.7em;
		margin-top:-6px;
		_margin-top:auto
	}
	.actfromfri .title {
		padding:2px 0;
		margin-bottom:8px;
		border-bottom:1px solid #ddd
	}
	.actfromfri img {
		padding-right:15px;
		background:#fff
	}
	.recevent {
		background:#F4F4EC;
		padding:10px;
		margin-bottom:20px
	}
	.recevent .img {
		float:left;
		text-align:center;
		width:110px
	}
	.recevent .img:hover {
		background:none
	}
	.recevent .pl2 {
		margin-bottom:10px
	}
	.recevent .text {
		padding-left:116px;
		color:#999
	}
	.fstars {
		float:left;
		margin-left:200px
	}
	* html .fstars {
		margin-left:100px
	}
	.recevent {
		background:#F4F4EC;
		padding:6px 6px 6px 2px
	}
	.recevent .img {
		float:left;
		text-align:center;
		width:110px
	}
	.recevent .img:hover {
		background:none
	}
	.recevent .text {
		padding-left:116px;
		color:#999
	}
	.rectitle {
		padding:10px 19px;
		margin-bottom:10px;
		overflow:hidden;
		word-break:break-all
	}
	#dialog .rectitle {
		background-color:#EBF5EB
	}
	#dialog .rectitle .m {
		color:#333;
		line-height:1.6em;
		display:block
	}
	#dialog .rectitle .m i {
		font-style:normal;
		color:#072;
		margin-left:.5ex
	}
	.recsmr {
		line-height:1.6em;
		color:#777;
		padding:0 19px;
		margin-bottom:10px;
		display:block;
		color:#666
	}
	#dialog .rectitle .gact a:link,#dialog .rectitle .gact a:visited,#dialog .rectitle .gact a:hover,#dialog .rectitle .gact a:active {
		font-size:14px;
		padding:0 4px
	}
	.reccomment {
		padding:0 19px
	}
	.reccomment .text {
		width:94%;
		border:1px solid #bbb;
		margin-bottom:4px
	}
	.reccomment .text:focus {
		border:1px solid #666
	}
	.reccomment .recsubmit {
		padding:10px 0;
		text-align:center
	}
	.reccomment label {
		position:absolute;
		color:#999;
		margin:2px 0 0 6px;
		cursor:text
	}
	.recsubmit .bn-flat {
		margin:0 10px
	}
	.reclstwrap {
		background:url(/f/book/a45189e245cd59dbf354c0356681899384e8a1a2/pics/topicgrey.gif) no-repeat;
		display:block;
		margin-top:20px
	}
	.reclstwrap .reclst {
		width:100%;
		height:26px;
		margin-left:4px;
		font:14px Arial,Helvetica,sans-serif;
		color:#666666;
		margin-bottom:1px;
		line-height:150%;
		background:url(/f/book/a45189e245cd59dbf354c0356681899384e8a1a2/pics/topicgrey.gif) no-repeat right top;
		display:block
	}
	.reclstwrap .reclst img {
		margin:2px 2px 0 0
	}
	.reclstwrap .reclst a.rr:hover {
		background:none;
		color:#ff0000
	}
	.recreplylst .ilst {
		margin-top:-39px
	}
	.recreplylst .clst {
		margin-top:-11px;
		color:#555
	}
	.recreplylst form {
		margin-left:68px
	}
	.recreplylst textarea {
		width:389px
	}
	.recreplylst input {
		margin-top:3px
	}
	.recreplylst span.pl {
		vertical-align:top
	}
	.norquote {
		color:#333
	}
	.recreplylst .simplelst {
		border-bottom:1px dashed #ddd;
		margin-top:4px;
		margin-bottom:4px;
		margin-left:53px
	}
	.blank_rec {
		margin:2px 2px 2px 24px;
		line-height:1.7em
	}
	#dialog td {
		padding:7px
	}
	#dialog td.ul {
		padding:0
	}
	#submits td {
		padding:15px 0 5px 0
	}
	* html #submits td {
		padding-bottom:0
	}
	#saving.m {
		text-align:right;
		padding:15px
	}
	.rec-sec {
		text-align:right;
		color:#999
	}
	.rec-sec span {
		*zoom:1
	}
	a.a_rec_btn {
		display:inline-block;
		*display:inline;
		*zoom:1;
		padding-left:26px;
		width:46px;
		height:20px;
		line-height:20px;
		*line-height:22px;
		overflow:hidden;
		text-align:left;
		letter-spacing:4px;
		vertical-align:bottom
	}
	a.a_rec_btn:link,a.a_rec_btn:visited,a.a_rec_btn:hover,a.a_rec_btn:active {
		background:transparent url(/f/book/4d946d3daaadf1e6cadb5110ae0c4a419d259137/pics/bg_rec_btn.png) no-repeat 0 0;
		color:#4f946e
	}
	a.a_rec_btn:hover,a.a_rec_btn:active {
		background-position:0 -20px
	}
	.aside .rec-comments {
		background:whiteSmoke;
		text-align:left;
		padding:10px;
		margin-bottom:10px
	}
	.aside .rec-sec {
		margin-bottom:20px
	}
	.rec-num {
		margin:0 0 0 2px
	}
	.lnk-sharing {
		display:inline-block;
		*display:inline;
		zoom:1;
		padding:0 8px;
		vertical-align:middle;
		*vertical-align:baseline;
		height:19px;
		line-height:19px;
		line-height:21px\9;
		overflow:hidden;
		border:1px solid #b9dcd0;
		-moz-border-radius:3px;
		-webkit-border-radius:3px;
		border-radius:3px
	}
	a.lnk-sharing:link,a.lnk-sharing:visited {
		border-color:#e3f1ed;
		background-color:#f2f8f2;
		color:#4f946e
	}
	a.lnk-sharing:hover,a.lnk-sharing:active {
		border-color:#c4e2d8;
		background-color:#eff5ef
	}
	.entry-image img {
		padding:0 15px 15px 0;
		float:left
	}
	.entry-summary,.entry-full {
		word-wrap:break-word;
		overflow:hidden;
		clear:right;
		margin:6px 0 20px 0
	}
	.entry-summary-mini {
		margin-top:6px
	}
	.entry-status-line {
		clear:left;
		margin:2px 0 6px 0;
		width:100%
	}
	.entry .entry-vote-btns {
		float:right;
		margin-top:-3px;
		_padding:4px
	}
	.loadtip {
		padding:0 5px;
		background:#e7ffbc;
		color:#777;
		float:right
	}
	.video_overlay {
		width:130px;
		height:97px;
		top:0;
		left:0;
		position:absolute;
		background:url(/f/book/7225a635202dc7b623e16a8dd83e0c28e76bc0a4/pics/video_overlay.png);
		cursor:pointer;
		*top:0px
	}
	.video_overlay:hover {
		background-position:0 -97px
	}
	* html .video_overlay {
		background:none;
		filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='/pics/video_overlay_ie6.png')
	}
	.videothumb {
		margin-left:24px
	}
	.vthumbwrap {
		width:130px;
		height:97px;
		text-align:center;
		position:relative
	}
	.vthumbwrap img {
		width:130px;
		height:97px
	}
	.hlst li {
		list-style-type:disc;
		float:left;
		margin:10px;
		width:45%
	}
	.hlst {
		margin-left:20px
	}
	.indentrec {
		margin-left:24px;
		line-height:1.6em;
		color:#333
	}
	.mainphoto:hover {
		background:none
	}
	#album_up {
		float:left;
		margin-left:20px;
		width:380px
	}
	#type_tip {
		display:block;
		width:150px;
		float:left;
		_width:125px
	}
	#album_up {
		float:left;
		width:300px;
		margin-left:20px;
		_margin-left:10px
	}
	#album_up input {
		margin:4px 0
	}
	.albumlst {
		margin:9px 0 10px 0;
		padding:0 0 10px 0;
		line-height:1.65em;
		float:left;
		width:49%
	}
	.albumlst_r {
		overflow:hidden;
		word-wrap:break-word;
		color:#777;
		float:left;
		width:240px;
		padding-top:4px
	}
	.albumlst_descri {
		color:#333;
		margin-bottom:10px
	}
	.photo_wrap {
		float:left;
		display:inline;
		width:170px;
		overflow:hidden;
		margin:10px 13px 25px;
		word-wrap:break-word
	}
	.photo_wrap .pl {
		margin:6px 0 3px 0
	}
	.photolst_photo {
		width:180px;
		height:180px;
		margin:0
	}
	.photolst_photo:hover {
		background:#fcfcfc
	}
	.photo_infobox {
		height:130px;
		margin:4px 0;
		padding:5px 5px 5px 26px
	}
	.photo_infobox textarea {
		width:431px;
		height:70px;
		float:left
	}
	.photo_infobox .photo_infor {
		float:right;
		width:140px;
		text-align:center;
		margin-top:8px
	}
	.pb_wrap {
		float:left;
		margin:3px 12px 3px 0pt
	}
	.pb_wrap img {
		vertical-align:middle
	}
	.pb_photo {
		display:table-cell;
		vertical-align:middle;
		width:75px;
		height:75px;
		margin:0;
		text-align:center;
		*display:block;
		*font-size:65px;
		float:none
	}
	.pb_photo:hover {
		background:#fff
	}
	.album {
		background:url(/f/book/283921263c43e490777b39d1a4e03bdedfc4d871/pics/albumback.gif) 1px 1px no-repeat;
		padding:4px 7px 7px 4px
	}
	.album_s {
		background:url(/f/book/2845e06e4eea41dc937dc5fd8cc37fbc77046a4b/pics/albumback_s.gif) 1px 1px no-repeat;
		padding:5px 8px 8px 5px
	}
	.album_photo {
		display:block;
		overflow:hidden;
		width:181px;
		height:181px
	}
	.album_photo:link {
		display:block;
		color:#777;
		font-style:italic
	}
	.album_photo:visited {
		color:#777;
		font-style:italic
	}
	.album_photo:hover {
		background:none;
		color:#777
	}
	.sign-text:link {
		color:#777;
		font-style:italic
	}
	.sign-text:visited {
		color:#777;
		font-style:italic
	}
	.sign-text:hover {
		background:none;
		color:#777
	}
	.photo_descri {
		padding:0 0 0 14px;
		word-wrap:break-word;
		overflow:hidden
	}
	.photo-ft {
		color:#666
	}
	.edtext form {
		margin:0;
		padding:0
	}
	.edtext {
		width:100%;
		margin:7px 0 15px 0
	}
	.edtext textarea {
		font-size:12px;
		height:50px;
		width:282px;
		background:#f9f9f9;
		border:1px solid #ddd
	}
	#up_tip {
		color:#666
	}
	.photitle {
		border-bottom:1px solid #ddd;
		margin-bottom:5px;
		padding-bottom:5px;
		text-align:right
	}
	#discover {
		background:url(/f/book/3e62d4f315ac35f9d28f535aca9945f16707e604/pics/discover.jpg) no-repeat;
		width:400px;
		height:185px;
		font-size:14px;
		color:#aaa;
		padding:7px 0 0 115px;
		line-height:1.5em;
		margin:45px 0 10px 40px;
		*margin:30px 0 0px 0px
	}
	#discover_s {
		text-align:center;
		margin:0 0 28px 0;
		padding-right:30px
	}
	#discover_s .text {
		width:380px;
		margin:8px;
		border:1px solid #bcd3e3
	}
	.fastreg .m {
		margin-top:.3em;
		font-size:12px;
		width:3.3em;
		float:left
	}
	.fastreg .text {
		width:180px;
		margin:2px 5px;
		border:1px solid #ccc
	}
	.fastreg .submit {
		margin:4px 0 2px 4px
	}
	.login_end {
		margin-left:3.3em;
		margin-top:.5em
	}
	.login_input {
		margin-top:.3em
	}
	#search_evt {
		float:left;
		display:block;
		margin-right:65px;
		font-size:12px;
		margin:4px 0 0 0;
		position:relative
	}
	#search_evt .text {
		top:1px;
		width:153px;
		margin:0 5px 0 0;
		height:16px;
		border:1px solid #ddd;
		position:absolute
	}
	#search_evt .submit {
		margin:0 60px 0 160px
	}
	.alignleft {
		background:url(/f/book/b3b1a7e1c6008e0f6cec97d810b1f17bb0fcbb17/pics/align_left.png) no-repeat;
		padding:0 6px 0 25px
	}
	.aligncenter {
		background:url(/f/book/184ecd1c22b129cb2b4f52eb4e449355ddbe49d1/pics/align_center.png) no-repeat;
		padding:0 6px 0 25px
	}
	.alignright {
		background:url(/f/book/f641815a5e5ab50fdc9155a469d10ec43db1234b/pics/align_right.png) no-repeat;
		padding:0 6px 0 25px
	}
	.feed {
		background:url(/f/book/4bace6d78006ece72f0e4a2b714fcfe3b54dd4e2/pics/feed1.png) no-repeat;
		font-size:14px;
		padding:0 0 30px 20px
	}
	.miniform {
		display:inline
	}
	.minisubmit {
		padding:0;
		margin:0;
		color:#37a;
		background:none;
		cursor:pointer;
		border:none
	}
	.minisubmit:hover,.minisubmit.hover {
		background:#003399;
		color:#fff
	}
	.gsubmit {
		cursor:pointer;
		padding:0;
		margin:0;
		height:1.6em;
		line-height:1.6em;
		color:#BBB;
		background:none;
		border:none
	}
	.gsubmit:hover,.gsubmit.hover {
		height:1.6em;
		line-height:1.6em;
		cursor:pointer;
		color:#FFF;
		border-left:1px solid #F99;
		border-top:1px solid #F99;
		border-right:1px solid #F33;
		border-bottom:1px solid #F33;
		background-color:#733
	}
	.note-header h3 {
		color:#072;
		background:none;
		margin-left:0;
		margin-bottom:0;
		height:auto;
		line-height:1.4
	}
	.note {
		font-size:13px;
		line-height:1.62;
		font-family:Arial,Helvetica,sans-serif;
		word-wrap:break-word;
		white-space:pre-wrap;
		width:100%;
		overflow:hidden;
		margin-top:10px
	}
	#note .note {
		font-size:12px;
		line-height:1.62
	}
	#form_note textarea {
		font-size:13px;
		line-height:1.62
	}
	.note a img {
		vertical-align:bottom
	}
	body .note {
		white-space:pre-wrap
	}
	.note .cc {
		padding:0pt 0pt 15px;
		display:block;
		clear:both;
		text-align:center
	}
	.note .ll {
		padding:0 16px 16px 0
	}
	.note .cc table {
		margin:0 auto
	}
	.note .rr {
		padding:0 0 16px 16px
	}
	.note-ft .rec-sec {
		clear:both
	}
	.thumblst {
		min-height:140px;
		min-width:600px;
		border:1px solid #d3d3d3;
		background:#f0f0f0;
		padding:10px 12px;
		margin:3px 0 7px
	}
	.thumblst .thumb {
		float:left;
		width:140px;
		overflow:hidden
	}
	.thumblst .thumb img {
		max-width:130px;
		_width:130px
	}
	.thumblst .thumb .pl {
		padding:2px;
		border:1px solid #ddd;
		margin-bottom:6px;
		background:#fff
	}
	.thumblst .details {
		float:right;
		width:419px
	}
	.thumblst .details textarea {
		width:410px;
		height:66px;
		border:1px solid #ccc
	}
	.message {
		border:1px solid #FAF3CA;
		padding:10px;
		background:#fffadc;
		margin-bottom:10px
	}
	.placeholder {
		border:2px dashed #ccc
	}
	.sort h2 {
		cursor:move;
		width:100%;
		_ie6_hack:expression(onmouseover=exp_sort_h2_over,onmouseout=exp_sort_h2_out)
	}
	.ui-draggable-dragging {
		border:1px solid #cFc
	}
	.sort h2:hover {
		background:#f2fbf2
	}
	.sort_helper {
		border:2px dashed #cdc
	}
	.sort div h2:hover {
		background:none
	}
	#event {
		margin-bottom:10px
	}
	#photo,#artist,#minisite {
		margin-bottom:35px;
		width:100%;
		overflow:hidden
	}
	.photoin {
		float:left;
		width:147px;
		height:160px;
		overflow:hidden
	}
	#hosts .photoin {
		height:177px;
		width:160px
	}
	#hosts .last {
		width:100px
	}
	#artist,#group,#recs,#like,#movie,#music,#blog,#book,#mb,#friend,#board,#profile,#note,#doulist,#live,#commodity,#experience,#game {
		margin-bottom:35px
	}
	#group {
		width:100%
	}
	#offer {
		margin-bottom:12px
	}
	#review {
		margin-bottom:27px
	}
	#review .ilst {
		margin:-17px -105px 0 0
	}
	#review .tlst {
		padding:0 0 15px 0
	}
	#confirm_delete {
		display:none
	}
	#like .time {
		float:right;
		color:#999;
		margin-left:50px
	}
	#like h2 img {
		vertical-align:middle
	}
	.aside #like .time {
		display:none
	}
	.reply_notify a {
		margin-left:.5em
	}
	.reply_notify .reply_notify_delete {
		color:#999
	}
	.reply_notify {
		text-align:left;
		border-collapse:collapse;
		width:100%;
		color:#676767;
		margin-bottom:20px
	}
	.reply_notify td {
		border-bottom:1px dashed #ddd
	}
	.reply_notify th {
		font-weight:normal;
		border-bottom:1px solid #ccc
	}
	.reply_notify td {
		padding:.4em 0
	}
	.date {
		width:8em
	}
	.dater {
		width:6em;
		text-align:right
	}
	.ac_results,.addr_results,.city_results,.rc_results {
		border:1px solid gray;
		background-color:#fff;
		padding:0;
		margin:0;
		list-style:none;
		position:absolute;
		z-index:10000;
		display:none;
		width:173px;
		overflow:hidden
	}
	.rc_results {
		width:356px
	}
	.addr_results {
		width:186px
	}
	.city_results {
		width:87px
	}
	.ac_results li,.addr_results li,.city_results li,.rc_results li {
		padding:2px 5px;
		white-space:nowrap;
		color:#aaaaaa;
		text-align:left
	}
	.ac_over {
		cursor:pointer;
		background-color:#3366cc
	}
	.ac_match {
		color:black
	}
	.black {
		color:#000
	}
	.greylink:link {
		color:#b4b4b4;
		font-size:12px
	}
	.greylink:hover {
		color:#b4b4b4;
		background:none;
		font-size:12px
	}
	.greylink:visited {
		color:#b4b4b4;
		font-size:12px
	}
	.dotli li {
		list-style-type:disc;
		margin-left:10px
	}
	.title2 {
		border-bottom:3px double #EEEEEE;
		margin-top:25px;
		padding:0 0 2px 2px
	}
	#campus_header {
		padding:10px 0 5px 0;
		background:#fff
	}
	#campus_header #logo {
		float:left;
		display:block;
		width:165px;
		height:34px;
		text-indent:-9999px;
		background:url(/f/book/406e43611dc775e6d91457c30e067b2617d02238/pics/logo2010.gif) no-repeat
	}
	#campus_header a:hover {
		background:none
	}
	#campus_header #year {
		float:left;
		display:block;
		width:100px;
		height:34px;
		text-indent:-9999px;
		background:url(/f/book/d3e2effd67ae4b5b9080da5b1c391cec792ea9cf/pics/campus_2010.gif) no-repeat
	}
	#campus_header h1 {
		float:left;
		font-size:18px;
		padding:10px 0 5px;
		color:#2a9a44
	}
	#campus_tab {
		height:24px;
		overflow:hidden;
		background:#eef9eb;
		-webkit-border-radius:3px;
		-moz-border-radius:3px
	}
	#campus_tab li {
		float:right;
		display:inline;
		line-height:24px;
		height:24px;
		padding:0 15px;
		color:#37a;
		padding-right:25px
	}
	#campus_tab li a {
		color:#37a
	}
	#campus_tab li a:hover {
		color:#fff;
		background:#37a
	}
	#campus_indent {
		width:680px;
		margin-left:20px
	}
	#campus_indent h1 {
		margin:20px 0 10px 0
	}
	#campus_indent h2 {
		padding:0 0 2px 2px;
		border-bottom:3px double #eee;
		margin-top:40px
	}
	#campus_tab a.on {
		color:#37a;
		text-decoration:none
	}
	#campus_tab a.no_tag_line {
		background:none
	}
	#max_campus {
		width:700px;
		margin:0 auto;
		background:#fff
	}
	.group_say {
		width:229px;
		left:0;
		top:21px;
		padding:4px 15px 12px
	}
	.group_say_content {
		padding-top:.3em
	}
	.blocktip {
		color:#333;
		text-align:left;
		padding:5px;
		border:1px solid #E3E3E3;
		border-width:1px 2px 2px 1px;
		background:#fff;
		position:absolute;
		z-index:100;
		display:none
	}
	.blocktip .artist_tip input {
		margin-top:0
	}
	.tipwrap {
		position:relative
	}
	.blocktip_close,.blocktip_close:visited,.blocktip_close:active {
		padding:0 4px;
		background:transparent;
		position:absolute;
		right:15px;
		color:#999;
		font-family:"Comic Sans MS"
	}
	.blocktip_content {
		margin:3px 0;
		float:left;
		width:100%;
		color:#072;
		clear:both;
		font-size:12px
	}
	.artist_tip {
		width:230px;
		padding:4px 8px
	}
	.artist_tip input {
		margin-top:7px
	}
	.artist_s {
		padding:0 0 8px 0
	}
	.artist_photo {
		width:181px;
		height:181px;
		dislay:block
	}
	.artist_photo:link {
		color:#777;
		font-style:italic
	}
	.artist_photo:visited {
		color:#777;
		font-style:italic
	}
	.artist_photo:hover {
		background:none;
		color:#777
	}
	.artist_list {
		float:left;
		width:138px;
		height:120px;
		text-align:center
	}
	.artist_list dd {
		margin:0
	}
	#songlist a:hover {
		background:none;
		color:#37a
	}
	.songlst td {
		border-bottom:1px dashed #ccc;
		height:23px;
		color:#999
	}
	.songlst .full {
		background:url(/f/book/b8d0a75490599fb542136854b874918446ef98c1/pics/playicon.png) 0 -31px no-repeat;
		color:#777
	}
	.songlst .selsong .full {
		background:url(/f/book/b8d0a75490599fb542136854b874918446ef98c1/pics/playicon.png) -20px -5px no-repeat #eaf9e6;
		color:#777
	}
	.songlst .full a {
		padding-left:21px
	}
	.selsong {
		background:#EAF9E6
	}
	#mainplayer {
		width:290px;
		height:40px
	}
	#song,#video,#miniblog,#discussions,#contact,#subject,#album,#fans_album,#vote {
		margin-bottom:35px
	}
	.hiddenmod {
		color:#999;
		background:#f2f2f2
	}
	.hiddenmod h2 {
		color:#777;
		margin-bottom:5px
	}
	.indent2 {
		text-indent:2em
	}
	.artist_doumail {
		background:url(/f/book/8b3368b18115283f4e3ba1b22d27628ed058c2fd/pics/icon/musician_9px.gif) no-repeat 0 center;
		padding-left:12px
	}
	.artist_doumail_big {
		background:url(/f/book/2e25c7ae9dd45d7c79641c8e6a3ab3f80e9d1c61/pics/icon/musician_16px.gif) no-repeat 0 center;
		padding:20px
	}
	.minisite_doumail {
		background:url(/f/book/be1eb118d1daeaa70aff9c6b0356c514309e9910/pics/icon/minisite_9px.gif) no-repeat 0 center;
		padding-left:12px
	}
	.minisite_doumail_big {
		background:url(/f/book/aa2739ed72327955fc19a43880e6dc421d8ed7fc/pics/icon/minisite_16px.gif) no-repeat 0 18px;
		padding:20px
	}
	.site_doumail {
		background:url(/f/book/be1eb118d1daeaa70aff9c6b0356c514309e9910/pics/icon/site_9px.gif) no-repeat 0 center;
		padding-left:12px
	}
	.site_doumail_big {
		background:url(/f/book/aa2739ed72327955fc19a43880e6dc421d8ed7fc/pics/icon/site_16px.gif) no-repeat 0 18px;
		padding:20px
	}
	.host_doumail {
		background:url(/f/book/0b7f6c623eb6fddb737acb9a7704b4f456f047a2/pics/icon/host_small.gif) no-repeat 0 center;
		padding-left:12px
	}
	.host_doumail_big {
		background:url(/f/book/7694770948bddd9bb2f765c2d236bd58f77e7745/pics/icon/host_big.gif) no-repeat 0 18px;
		padding:20px
	}
	#minisite_bg a:hover {
		background:none;
		color:#fff
	}
	#songlist .a_rec_btn {
		width:14px;
		height:12px;
		padding:0;
		margin-bottom:4px;
		line-height:10em
	}
	#songlist a.a_rec_btn:link,#songlist a.a_rec_btn:visited,#songlist a.a_rec_btn:hover,#songlist a.a_rec_btn:active {
		background:transparent url(/f/book/4d946d3daaadf1e6cadb5110ae0c4a419d259137/pics/bg_rec_btn.png) no-repeat 0 -48px
	}
	.sys_doumail {
		background:url(/f/book/8a9f860a76383cfb31f93fb7d57b9afb212a6b10/pics/icon/system_9px.gif) no-repeat 0 center;
		padding-left:12px
	}
	.sys_doumail_big {
		background:url(/f/book/69cc25e1940d6a79ee1054be2a707608235eaade/pics/icon/system_16px.gif) no-repeat 0 center;
		padding:20px
	}
	.doumail_from {
		padding-left:12px
	}
	.gray_ad {
		background:#F4F4EC;
		padding:10px;
		margin-bottom:20px;
		word-wrap:break-word
	}
	.pop_win_bg {
		opacity:0.3;
		filter:alpha(opacity=30);
		position:fixed;
		background:#000;
		border-radius:6px;
		-webkit-border-radius:6px;
		-moz-border-radius:6px;
		_position:absolute;
	}
	.pop_win form {
		padding:0;
		margin:0;
		border:1px solid #fff
	}
	aa.pop_win_close,.pop_win_close:visited,.pop_win_close:link {
		position:absolute;
		right:0;
		top:0;
		font:11px "Comic Sans MS";
		margin:9px 10px 0 0;
		padding:0 0.3em;
		color:#b4b4b4;
		z-index:99
	}
	a.pop_win_close:hover {
		color:#fab0b6;
		background:none
	}
	.pop_win {
		background:#fff;
		padding:17px 14px 16px 12px;
		_padding-right:0;
		visibility:hidden;
		position:fixed;
		border-radius:6px;
		-webkit-border-radius:6px;
		-moz-border-radius:6px;
		_position:absolute;
	}
	.login_input {
		font-size:12px;
		color:#016502;
		text-align:left
	}
	.login_input input {
		width:200px
	}
	.login_input span {
		width:3.5em;
		float:left
	}
	.pop_reg {
		float:left;
		margin-top:2em;
		display:block
	}
	.pop_sub {
		text-align:left;
		margin-left:3.4em;
		margin-top:.3em
	}
	.pop_sub input {
		width:5em;
		padding-top:2px
	}
	.pop_rem {
		margin-top:.5em;
		padding-bottom:5px;
		text-align:left;
		margin-left:3.2em
	}
	.block1,.block5 {
		margin-bottom:20px
	}
	.blank20,.block1,.block5 {
		margin-bottom:20px
	}
	.block2,.block3 {
		margin-bottom:40px
	}
	.block1 .content dl {
		float:left;
		display:inline;
		width:280px;
		margin:0 15px 20px 0;
		overflow:hidden
	}
	.block1 .content dl.clear,.block1 .content ul li.clear {
		display:block;
		width:auto;
		float:none;
		margin:0
	}
	.block1 .content dl dt {
		float:left;
		width:85px;
		overflow:hidden
	}
	.block1 .content dl dd {
		float:right;
		width:190px;
		overflow:hidden;
		margin:0
	}
	.block1 .content dl .dgt {
		margin-bottom:5px;
		line-height:100%
	}
	.block1 .content dl .dgt .pl2 {
		line-height:16px
	}
	.block1 .content dl span.reason {
		color:#999
	}
	.block1 .content dl .gact {
		margin:0 0 0 10px
	}
	.block1 .content ul li {
		float:left;
		display:inline;
		margin:0 20px 30px 0;
		overflow:hidden;
		padding:0;
		width:275px
	}
	.block1 .content ul li .title {
		display:block;
		font-size:14px
	}
	.block1 .content ul li .actimgs {
		border:1px solid #ddd;
		padding:3px;
		float:left;
		margin:10px 0 0 0
	}
	.block1 .content ul li .evtdesc {
		margin:6px 0 0 65px;
		color:#666
	}
	.block2 .content {
		width:590px
	}
	.block2 {
		overflow:hidden
	}
	#in_tablem .block2 .content ul li,.block2 .content ul li {
		position:relative;
		float:left;
		margin-right:35px;
		_width:128px;
		_overflow:hidden;
		_clear:right
	}
	.block3 .content {
		list-style:none
	}
	.block3 .content li {
		border-bottom:1px solid #EEEEEE;
		margin:0;
		paddng:5px 0;
		list-style:none
	}
	.block3 .content li {
		border-bottom:1px solid #EEEEEE;
		margin:0;
		padding:5px 0
	}
	.block3 .content li .user_img {
		float:left;
		height:48px;
		width:48px
	}
	.block3 .content li .ct {
		margin:0 0 0 58px;
		color:#666
	}
	.block3 .content li .cm {
		margin-right:10px
	}
	.block3 .content li .cpl {
		color:#999;
		margin-right:10px;
		padding-top:5px
	}
	.block3 .content li .time {
		color:#999
	}
	#in_tablem .block1 {
		width:630px
	}
	#in_tablem .block1.content {
		width:650px
	}
	#in_tablem .block1.content ul li {
		width:305px
	}
	#in_table .block1 {
		width:575px
	}
	#in_table .block1 .content {
		width:600px
	}
	#in_table .block1 .content ul li {
		width:275px
	}
	#in_tableb .block1 {
		width:550px
	}
	#in_tableb .block1 .content {
		width:570px
	}
	#in_tableb .block1 .content ul li {
		width:260px
	}
	.onlines_tab {
		padding-bottom:2px;
		margin:0 0 20px 0
	}
	.onlines_tab span {
		color:#aaa;
		font-size:12px
	}
	.onlines_tab .tabs {
		float:right
	}
	.onlines_tab .line {
		color:#bbb;
		float:none
	}
	.onlines .item {
		padding:10px;
		border-bottom:1px solid #eee
	}
	.onlines .enter {
		background:#efefef
	}
	.onlines .item .actions {
		margin:-5px 0 0 10px;
		*margin-top:-15px
	}
	.onlines .item a.lnk-confirm {
		display:none;
		color:#f96360;
		background:#fdd6d5;
		border:1px solid #fa9492
	}
	.onlines .item a.lnk-confirm:hover {
		color:#fff;
		background:#fa8280;
		border:1px solid #e3241b
	}
	.onlines .enter a.lnk-confirm {
		display:block;
		_display:inline-block;
		_height:23px;
		_line-height:23px
	}
	.onlines .item h5 {
		font-size:14px;
		margin-right:80px
	}
	.onlines .item .info {
		color:#aaa
	}
	.onlines .item .actions {
		float:right;
		height:19px;
		color:#aaa;
		zoom:1
	}
	.onlines .item .status .joined {
		display:block;
		_display:inline-block
	}
	.onlines .item .status .quit {
		display:none
	}
	.onlines .item .status.enter .joined {
		display:none
	}
	.onlines .item .status.enter .quit {
		display:block;
		_display:inline-block
	}
	.onlines .item .photos {
		margin:8px
	}
	.onlines .item .photos a {
		float:left;
		margin:4px
	}
	.onlines .item .photos a img {
		max-width:80px;
		_width:80px
	}
	.online_event_index {
		float:none;
		width:100%;
		padding:0;
		margin:0;
		width:630px;
		overflow:hidden
	}
	.online_event_index ul {
		width:650px
	}
	.online_event_index ul li.block {
		padding:0 0 20px 0;
		float:left;
		width:305px;
		margin-right:20px;
		height:auto
	}
	.online_nof {
		border-bottom:1px solid #eee
	}
	.online_nof h2 {
		margin-left:0
	}
	.online_nof .evtlstimg {
		width:80px;
		height:80px
	}
	.online_nof .evtlstimg .actimgs {
		margin-top:0
	}
	.online_event_pic {
		width:590px;
		overflow:hidden
	}
	.online_event_pic div {
		width:100px;
		margin:0 16px 30px 0;
		float:left;
		text-align:left
	}
	.online_event_pic div.clear {
		width:0;
		float:none;
		margin:0
	}
	.online_event_pic div.pic {
		margin:0
	}
	.da1,.da2,.da3,.da4 {
		margin-bottom:20px
	}
	.da1 {
		padding:5px;
		background:#f4f4ec
	}
	.da1 dl {
		margin:0
	}
	.da1 dl dt,.da1 dl dd {
		text-align:left;
		margin:0;
		padding:0
	}
	.da1 dl dt {
		float:left;
		text-align:center;
		width:85px;
		overflow:hidden
	}
	.da1 dl dd {
		margin:0 0 0 95px
	}
	.da1 dl dd a {
		font-size:14px
	}
	.da1 dl dd .ps {
		color:#999;
		line-height:18px;
		margin-top:5px
	}
	.da3 {
		padding:10px 10px 0 10px;
		background:#f4f4ec
	}
	.da3 dl {
		margin:0 0 10px 0
	}
	.da3 dl dt,.da3 dl dd {
		text-align:left;
		margin:0;
		padding:0
	}
	.da3 dl dt {
		font-size:14px
	}
	.da3 dl dd a {
		color:#999
	}
	.da3 dl dd a:hover {
		background:none
	}
	.da2 a:hover {
		background:none
	}
	.da4 dl {
		float:left;
		overflow:hidden;
		width:50%;
		margin:0
	}
	.da4 dl dt,.da4 dl dd {
		text-align:center;
		margin:0;
		padding:0
	}
	.da4 dl dt {
		height:100px;
		overflow:hidden
	}
	.da4 dl dd {
		padding:5px
	}
	.pl_index {
		font-size:12px;
		color:#999
	}
	.citysmr2 {
		margin-bottom:40px
	}
	.citysmr2 li {
		padding:0 0 20px 0
	}
	.citysmr2 li a.img {
		float:left;
		margin:0px 9px 0 0
	}
	.citysmr2 li a.img img {
		border:1px solid #DDDDDD;
		padding:3px
	}
	.citysmr2 li div {
		margin:5px 0 0 70px
	}
	.citysmr2 a.title {
		font-size:14px
	}
	.citysmr2 span.pl {
		padding-top:3px;
		display:block
	}
	.sq_list_right {
		margin-bottom:40px
	}
	.sq_list_right li {
		padding:2px 0
	}
	.con_index {
		width:110px
	}
	#discover {
		background:url(/f/book/2f0c1fc628ab79f4682c6e54e648a64ddfa952f0/pics/discover.gif) no-repeat;
		width:400px;
		height:185px;
		font-size:14px;
		color:#aaa;
		padding:0px 0 0 110px;
		line-height:1.5em;
		margin:0px 0 15px 62px
	}
	#discover p {
		line-height:100%;
		padding:0;
		margin:0 0 16px 0
	}
	#discover p.p1 {
		margin:0px 0 7px 0;
		padding-top:2px
	}
	#discover p.p2 {
		margin-bottom:18px
	}
	#discover_s {
		text-align:center;
		margin:0 0 28px 0;
		padding-right:30px
	}
	#discover_b {
		margin-top:25px;
		font-size:12px;
		color:#37a
	}
	#discover_b .rr {
		margin-top:9px;
		margin-right:45px
	}
	#discover_s .text {
		width:380px;
		padding:3px;
		margin:8px;
		border:1px solid #ccc;
		font-size:14px
	}
	.mbt .mbtr .mbtr_m_img {
		float:left;
		width:48px;
		height:48px
	}
	.mbt .mbtr .mbtr_m_content {
		margin:0 0 0 58px;
		color:#666
	}
	.mbt .mbtr .mbtr_m_content .cm {
		margin-right:10px
	}
	.mbt .mbtr .mbtr_m_content .time {
		color:#999
	}
	.mbt .mbtr .mbtr_m_content .cpl {
		padding-top:5px;
		color:#999;
		margin-right:10px
	}
	.mbt .mbtr .mbtr_m_player {
		clear:both;
		text-align:center
	}
	#mbr_img .mbtr,#mbr_music .mbtr {
		margin:0
	}
	#mbr_img .broadsmr,#mbr_music .broadsmr {
		padding:5px 0
	}
	#mbr_img .quote,#mbr_music .quote {
		margin:0
	}
	#mbr_img .indentrec,#mbr_music .indentrec {
		margin:0
	}
	#mbr_img .recreplylst form,#mbr_music .recreplylst form {
		margin-left:0
	}
	#mbr_img .star,#mbr_music .star {
		margin-left:0
	}
	#mbr_img .recreplylst .simplelst,#mbr_music .recreplylst .simplelst {
		margin-left:0
	}
	#mbr_img,#mbr_music {
		margin-bottom:20px;
		word-break:break-all
	}
	.blocktop_content div {
		padding-right:10px
	}
	fieldset.setquestion label {
		width:40px
	}
	fieldset.setquestion .fsctm {
		margin:0 0 10px 50px;
		color:#333
	}
	fieldset.setquestion .fsctm span {
		font-size:14px
	}
	table.settable {
		margin:0 0 20px 0;
		color:#666
	}
	table.settable th {
		background:#eee
	}
	table.settable td,table.settable th {
		padding:1px 3px;
		text-align:left
	}
	table.settable th {
		color:#333
	}
	table.settable td.add {
		padding:0
	}
	fieldset.setquestion table.settable {
		display:none;
		margin-left:70px
	}
	fieldset.setquestion table.settable th {
		color:#666
	}
	fieldset.setquestion table.settable td {
		padding:5px 10px
	}
	fieldset.eventform {
		padding:20px;
		border:1px solid #ddd
	}
	fieldset.eventform .fsct {
		margin-bottom:10px
	}
	fieldset.floatdiv {
		border:none
	}
	#in_table .block4 {
		width:575px
	}
	#tabler .block4 {
		width:345px
	}
	#tabler .block4 .content {
		width:440px
	}
	#tabler .block4 .content ul li {
		margin-right:100px
	}
	.block4 {
		overflow:hidden
	}
	.block4 h2 {
		margin-top:0px
	}
	.block4 .content {
		text-align:center;
		margin-top:20px
	}
	.block4 .content .headline {
		float:left;
		width:100px
	}
	.block4 .content ul {
		widtih:450px;
		float:right
	}
	.block4 .content ul li {
		float:left;
		display:inline;
		width:180px;
		margin-bottom:16px;
		margin-right:40px
	}
	.block4 .content ul li.line {
		float:none;
		display:block;
		clear:both;
		width:450px;
		margin:0 0 15px 0;
		line-height:0;
		font-size:0;
		border-bottom:1px dashed #ccc
	}
	.block4 .content ul li a img {
		width:50px;
		height:50px;
		float:left;
		margin:0 10px 0 0
	}
	.block4 .content ul li div {
		float:left;
		width:90px;
		text-align:left
	}
	.leftobs {
		float:left;
		width:100%
	}
	.leftobs .obs {
		width:114px
	}
	#tableh {
		float:left;
		margin:0 -480px 0 0;
		width:100%
	}
	#in_tableh {
		margin:0 480px 0 0;
		padding:0 40px 0 0;
		min-height:440px
	}
	#tablerh {
		float:right;
		width:445px;
		overflow:hidden;
		word-break:break-all
	}
	#in_tableh .block5,#tablerh .block5 {
		width:460px;
		overflow:hidden
	}
	#in_tableh .block5 .content,#tablerh .block5 .content {
		width:500px
	}
	#in_tableh .block5 .content dl,#tablerh .block5 .content dl {
		margin-right:30px;
		height:140px
	}
	.block6 {
		margin-bottom:20px
	}
	.block6 .content {
		border:1px solid #eee
	}
	.block6 .content ul li {
		border-bottom:1px dashed #ddd;
		margin:0 5px;
		padding:10px 0;
		height:100px;
		overflow:hidden
	}
	.block6 .content ul li .no {
		width:18px;
		padding-right:5px;
		float:left;
		margin-right:5px;
		padding-left:5px
	}
	.block6 .content ul li .no span {
		line-height:15px;
		text-align:center;
		background:url(/f/book/488c1a1e8562bc1c1baf7cf33074f094a97bb983/pics/chart_top.gif) no-repeat;
		display:block;
		width:15px;
		height:15px;
		overflow:hidden;
		float:right;
		font-size:10px
	}
	.block6 .content ul li .no b {
		color:green;
		font-weight:normal;
		white-space:nowrap
	}
	.block6 .content ul li .toppic {
		float:left;
		margin-right:10px
	}
	.block6 .content ul li .toppic img {
		padding:0
	}
	.block6 .content ul li .topinfo {
		float:left;
		width:280px
	}
	.block6 .content ul li .topinfo .title {
		font-size:14px
	}
	.block6 .content ul li .topinfo .title span {
		font-size:12px
	}
	.block6 .content ul li .topinfo span.info {
		display:block;
		color:#666;
		margin-top:10px
	}
	.block6 .artist ul li .toppic {
		width:100px
	}
	.block6 .artist ul li .topinfo {
		width:260px
	}
	.music_show .content dl dt {
		height:85px
	}
	.cd_show .toppic {
		width:85px
	}
	.artist_show .content dl dt {
		height:85px
	}
	.block5 .content dl.clear {
		margin:0;
		padding:0;
		clear:both;
		float:none;
		width:0
	}
	.block5 .content dl dt {
		overflow:hidden;
		height:99px
	}
	.block5 .content dl dt a {
		width:85px;
		text-align:center
	}
	.block5 .content dl dt a:hover {
		background:none
	}
	.block5 .content dl dd {
		margin:0;
		padding-top:3px
	}
	#friends_sub .content dl dt {
		position:static;
		height:auto
	}
	#friends_sub .content dl dt a {
		position:static;
		height:auto
	}
	#friends_sub .content dl dt a:hover {
		background:#039;
		color:#fff
	}
	#tabler .block5 {
		width:345px;
		overflow:hidden
	}
	#tabler .block5 .content {
		width:400px
	}
	.block5 .content dl {
		float:left;
		_display:inline;
		margin:0 18px 10px 0;
		overflow:hidden;
		text-align:center;
		width:85px
	}
	#in_tablem .block5 {
		width:630px
	}
	#in_tablem .block5 .content {
		width:690px;
		_width:640px
	}
	.subject_show .content dl {
		margin:15px 33px 15px 0
	}
	.copyright {
		color:#999;
		padding-bottom:5px;
		margin-bottom:5px
	}
	.review_bottom {
		border-top:1px dashed #ddd;
		padding-top:5px
	}
	.review_bottom .review_controller .vote {
		width:70px;
		float:right;
		text-align:right
	}
	.review_bottom .review_controller .review_button {
		margin-right:80px
	}
	.other_review ul li {
		list-style:none;
		border-bottom:1px dashed #ddd;
		padding:5px 0;
		color:#666
	}
	.basic_input {
		border:1px solid #ccc;
		padding:2px;
		font-size:12px
	}
	.artist_obu {
		float:left;
		width:100%
	}
	.artist_obu .obu {
		width:90px
	}
	.block_menu {
		position:relative;
		background:#f6f5ee;
		border:1px solid #e4e4e4;
		padding:0px;
		margin:0 10px 20px 0
	}
	.block_menu .ft,.block_menu .fb {
		position:absolute;
		font-size:1px;
		line-height:1px;
		background:url(/f/book/bf482e71d8af89a210e3f67191eba0bad675106c/pics/city_block_menu.gif) no-repeat;
		width:3px;
		height:3px;
		display:block
	}
	.block_menu em.ft {
		left:-1px;
		top:-1px;
		_top:0;
		background-position:left top
	}
	.block_menu b.ft {
		right:-1px;
		_right:10px;
		top:-1px;
		_top:0px;
		background-position:right top
	}
	.block_menu em.fb {
		left:-1px;
		bottom:-1px;
		_bottom:457px;
		background-position:left bottom
	}
	.block_menu b.fb {
		right:-1px;
		_right:10px;
		bottom:-1px;
		_bottom:457px;
		background-position:right bottom
	}
	.block_menu h2 {
		margin-top:0px;
		margin-bottom:3px;
		font-size:14px;
		background:#f6f5ee
	}
	.block_menu ul {
		padding:8px
	}
	.block_menu li {
		padding-left:0
	}
	.block_menu li.on,.blockmenu li#event_home {
		padding:2px 0
	}
	.block_menu li#event_home a {
		background:url(/f/book/31575db6962f9c7994a6105636b8b2f979f90786/pics/event_home_tab.gif) no-repeat left top;
		display:block;
		float:left;
		padding:0 0 0 3px
	}
	.block_menu li#event_home a span {
		background:url(/f/book/31575db6962f9c7994a6105636b8b2f979f90786/pics/event_home_tab.gif) no-repeat right top;
		display:block;
		line-height:12px;
		padding:2px 3px 2px 0;
		color:#fff
	}
	.block_menu li.on a {
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat left top;
		display:block;
		float:left;
		padding:0 0 0 3px
	}
	.block_menu li.on a span {
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat right top;
		display:block;
		line-height:12px;
		padding:2px 3px 2px 0;
		color:#fff
	}
	.block_menu .line {
		background:#f6f5ee;
		width:100%;
		height:0px;
		line-height:0px;
		font-size:0px;
		background:#fff;
		border-top:1px solid #e4e4e4;
		margin:10px 0
	}
	.block_menu .line2 {
		background:#f6f5ee;
		width:100%;
		height:0px;
		line-height:0px;
		font-size:0px;
		background:#fff;
		border-top:1px solid #e4e4e4;
		margin:5px 0
	}
	.block_search {
		padding-right:10px;
		text-align:center
	}
	.block_search .text {
		font-size:12px;
		border:1px solid #ccc;
		padding:2px;
		margin-bottom:4px;
		width:130px
	}
	.block_headerline {
		border-bottom:1px dashed #ddd;
		margin-bottom:10px
	}
	.block_headerline .nof {
		margin-bottom:10px
	}
	.block_headerline .nof h2,.block_headerline .nof .intro {
		margin-left:120px
	}
	.block_headerline .evtlstimg {
		overflow:hidden;
		width:115px;
		text-align:left;
		padding-top:0
	}
	.block_headerline .evtlstimg img {
		width:100px;
		border:1px solid #ddd;
		padding:5px
	}
	.block_spc {
		width:495px;
		overflow:hidden
	}
	.block_spc .content {
		width:515px
	}
	.block_spc .content li {
		float:left;
		width:112px;
		margin:0 15px 20px 0;
		text-align:center
	}
	.block_review {
		width:495px;
		overflow:hidden
	}
	.block_review .content {
		width:515px
	}
	.phs_link {
		display:block;
		height:110px;
		padding-bottom:3px
	}
	.phs_link:hover {
		background:none
	}
	.block_review .content li {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:top;
		width:107px;
		margin:0 20px 20px 0;
		text-align:center
	}
	.block_review .content li .album_s {
		background:url(/f/book/406275aa47a57aa4e41aeec5169f347822e8c96c/pics/albumback_city_s.gif) 1px 1px no-repeat;
		padding:5px 8px 8px 5px;
		width:87px;
		height:87px
	}
	.grid-4-14-6 .block1 .content ul li {
		width:245px;
		padding-bottom:10px;
		margin-bottom:0
	}
	.grid-4-14-6 .block1 .content ul li.clear {
		width:auto;
		margin-bottom:10px;
		padding-bottom:0;
		border-top:1px dashed #ddd
	}
	.block_event_tab {
		border:1px solid #e4e4e4;
		margin-bottom:20px
	}
	.block_event_tab ul.title li {
		float:left;
		border-right:1px solid #e4e4e4
	}
	.block_event_tab ul.title li.last {
		border:none
	}
	.block_event_tab ul.title li.last a {
		width:124px
	}
	.block_event_tab ul.title li.last,.block_event_tab ul.title li.first {
		position:relative
	}
	.block_event_tab ul.title li.first a em,.block_event_tab ul.title li.last a em {
		width:3px;
		height:3px;
		font-size:1px;
		line-height:1px;
		display:block;
		position:absolute
	}
	.block_event_tab ul.title li.first a em {
		left:-1px;
		top:-1px;
		background-position:left bottom
	}
	.block_event_tab ul.title li.first a.on em,.block_event_tab ul.title li.first a:hover em {
		right:-1px;
		top:-1px;
		background-position:left top
	}
	.block_event_tab ul.title li.last a em {
		right:-1px;
		top:-1px;
		background-position:right bottom
	}
	.block_event_tab ul.title li.last a.on em,.block_event_tab ul.title li.last a:hover em {
		right:-1px;
		top:-1px;
		background-position:right top
	}
	.block_event_tab ul.title li a {
		line-height:24px;
		height:24px;
		width:122px;
		display:block;
		text-align:center;
		color:#072;
		border-bottom:1px solid #e4e4e4
	}
	.block_event_tab ul.title li a:hover,.block_event_tab ul.title li a.on {
		background:#fff;
		border-bottom:1px solid #fff;
		color:#333
	}
	.block_event_tab ul.title {
		background:#f6f5ee;
		margin-bottom:10px
	}
	.block_event_tab .block1 {
		width:480px;
		margin-left:10px
	}
	.block_event_tab .block1 .content ul li {
		width:220px;
		margin-bottom:10px
	}
	.block_event_tab .block1 .content ul li.clear {
		margin:0
	}
	#week_tab {
		margin-bottom:20px
	}
	#more_event_tab {
		position:relative;
		float:left
	}
	h2.green_tab a {
		margin:3px 5px 0 5px;
		font-size:12px;
		line-height:12px;
		float:left;
		padding:2px;
		white-space:nowrap
	}
	h2.green_tab a span {
		font-family:Arial,Helvetica,sans-serif
	}
	h2.green_tab a.on,h2.green_tab a.on span,.sort_tabs a.on,.sort_tabs a.on span {
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat;
		color:#fff;
		display:block
	}
	h2.green_tab a.on,.sort_tabs a.on {
		background-position:left top;
		padding:0 0 0 8px;
		line-height:12px
	}
	.sort_tabs a.on {
		background-position:left top;
		padding:0 0 0 8px;
		line-height:12px
	}
	h2.green_tab a.on span,.sort_tabs a.on span {
		background-position:right top;
		padding:2px 8px 2px 0
	}
	#tongcheng_tab {
		padding-right:2px
	}
	#tongcheng_tab span {
		padding:2px 10px 2px 2px;
		background:url(/f/book/479b9d6dcc35cd548d9cd1a2d826f23213f5868c/pics/icon/tongcheng_tab_down.gif) no-repeat 27px 2px
	}
	#tongcheng_tab:hover span {
		background:url(/f/book/479b9d6dcc35cd548d9cd1a2d826f23213f5868c/pics/icon/tongcheng_tab_down.gif) no-repeat 27px -10px
	}
	#tongcheng_tab span.up {
		padding:2px 10px 2px 2px;
		background:url(/f/book/0badd8bb59652acb2f2823388150bdf1c02502f8/pics/icon/tongcheng_tab_up.gif) no-repeat 27px 2px
	}
	#tongcheng_tab:hover span.up {
		background:url(/f/book/0badd8bb59652acb2f2823388150bdf1c02502f8/pics/icon/tongcheng_tab_up.gif) no-repeat 27px -10px
	}
	.block_search1 {
		margin-bottom:20px;
		position:relative;
		border:1px solid #f7ebdd
	}
	.block_search1 .block_top em,.block_search1 .block_top b,.block_search1 .block_bottom em,.block_search1 .block_bottom b {
		position:absolute;
		width:4px;
		height:4px;
		overflow:hidden;
		background:url(/f/book/2d43bceedeeb2810b8fb6f61de0b418b7ac98bee/pics/search_conner.gif) no-repeat;
		display:block
	}
	.block_search1 .block_top em {
		top:-1px;
		left:-1px;
		background-position:0 0
	}
	.block_search1 .block_top b {
		top:-1px;
		right:-1px;
		background-position:-4px 0
	}
	.block_search1 .block_bottom em {
		bottom:-1px;
		left:-1px;
		background-position:0 -12px
	}
	.block_search1 .block_bottom b {
		bottom:-1px;
		right:-1px;
		background-position:-4px -12px
	}
	.block_search1 ul.title {
		background:#fef4eb;
		border-bottom:1px solid #f7ebdd;
		padding:1px 0 0 100px;
		margin-bottom:10px
	}
	.block_search1 ul.title li {
		float:left;
		margin:0 10px 0 0;
		padding:3px 10px 2px 10px
	}
	.block_search1 ul.title li.on {
		background:url(/f/book/79729f7ed4018d6c7545c866789c658aa85314c5/pics/wztab.gif) no-repeat right top;
		display:block;
		padding:0 10px 0 0;
		position:relative;
		bottom:-1px
	}
	.block_search1 ul.title li.on span {
		background:url(/f/book/79729f7ed4018d6c7545c866789c658aa85314c5/pics/wztab.gif) no-repeat left top;
		display:block;
		padding:3px 0 2px 10px
	}
	.block_search1 .ct {
		text-align:center;
		padding:10px 0
	}
	.block_search1 .ct input.input_basic {
		width:350px;
		font-size:14px
	}
	.block_search1 .ct button {
		height:20px
	}
	.block_search1 .ct .introduce {
		padding-top:10px;
		color:#999
	}
	.search_nav {
		color:#666;
		margin-bottom:5px;
		text-align:right
	}
	table.olt thead th {
		background:#eee;
		text-align:left
	}
	.search_no_result {
		font-size:14px;
		text-align:left;
		padding-top:20px
	}
	.search_no_result ul {
		padding:40px 0
	}
	.search_no_result ul li {
		list-style:none;
		color:#999;
		text-align:left;
		padding:2px 0
	}
	.checkbox_basic {
		margin:0 5px 0 0
	}
	.clist2 {
		padding-top:10px
	}
	.clist2 img {
		float:left
	}
	#tablen {
		float:left;
		margin:0 -300px 0 0;
		width:100%
	}
	#in_tablen {
		margin:0 300px 0 0;
		padding:0 40px 0 0
	}
	#tablern {
		float:right;
		overflow:hidden;
		width:300px
	}
	.movie_search {
		text-align:center;
		margin-bottom:20px
	}
	.movie_search .input_basic2 {
		background:#fbfbfb;
		width:350px;
		font-size:12px
	}
	.movie_search button {
		margin-left:5px;
		line-height:14px;
		padding:0px 8px
	}
	.movie_headerline {
		background:#fff;
		border:1px solid #e4e4e4;
		position:relative;
		margin-bottom:30px
	}
	.movie_headerline .left_conner em,.movie_headerline .left_conner b,.movie_headerline .first em,.movie_headerline .last em {
		background:url(/f/book/881629e1f78a0a40fd27ca46e63f76f9edc3ff89/pics/movie_headerline.gif) no-repeat;
		width:3px;
		height:3px;
		position:absolute;
		_background:none
	}
	.movie_headerline .left_conner em {
		left:-1px;
		top:-1px;
		background-position:0 0
	}
	.movie_headerline .left_conner b {
		left:-1px;
		bottom:-1px;
		background-position:0px -3px
	}
	.movie_headerline .first em {
		right:-1px;
		top:-1px;
		background-position:-3px -6px
	}
	.movie_headerline .last em {
		right:-1px;
		bottom:-1px;
		background-position:-3px -9px
	}
	.movie_headerline .first .on em {
		background-position:-3px -12px
	}
	.movie_headerline .last .on em {
		background-position:-3px -15px
	}
	#content_menu1 {
		display:block
	}
	.movie_headerline .content {
		display:none;
		width:392px;
		padding:10px;
		float:left;
		overflow:hidden;
		height:215px
	}
	.movie_headerline .content .title {
		margin-bottom:3px
	}
	.movie_headerline .content .title a {
		float:left;
		font-size:14px;
		margin-right:10px
	}
	.movie_headerline .content .title span {
		float:left
	}
	.movie_headerline .grade {
		color:#ff5138;
		font-size:12px;
		font-weight:bold;
		margin-left:10px
	}
	.movie_headerline ul.menu {
		width:175px;
		float:right;
		border-left:1px solid #e4e4e4;
		height:235px
	}
	.movie_headerline ul.menu li {
		height:58px;
		border-bottom:1px solid #e4e4e4
	}
	.movie_headerline ul.menu li div.clearfix {
		*height:58px
	}
	.movie_headerline ul.menu li.last {
		border:none
	}
	.movie_headerline ul.menu li .on {
		background:#e4e4e4;
		position:relative
	}
	.movie_headerline ul.menu li .arrow {
		display:none
	}
	.movie_headerline ul.menu li .on .arrow {
		display:block;
		position:absolute;
		background:url(/f/book/ff55871398e92d0ccf5eec316b6ce4cb36ba1bfe/pics/movie_headerline_arrow.gif) no-repeat;
		left:-11px;
		top:20px;
		width:10px;
		height:13px;
		overflow:hidden
	}
	.movie_headerline ul.menu li .img {
		float:left;
		display:inline;
		padding:5px;
		width:30px;
		height:48px
	}
	.movie_headerline ul.menu li .intro {
		margin-left:40px;
		padding-top:10px;
		padding-left:5px;
		color:#ff5138;
		font-size:10px
	}
	.movie_headerline ul.menu li .intro a {
		font-size:12px
	}
	.movie_headerline .content .headerline_img {
		float:left;
		display:inline;
		width:105px;
		height:155px;
		overflow:hidden;
		margin-bottom:8px
	}
	.movie_headerline .content .headerline_img img {
		width:105px
	}
	.movie_headerline .content .headerline_content {
		float:right;
		width:275px;
		*width:280px
	}
	.movie_headerline .content .ul {
		clear:both;
		margin:5px 0
	}
	.movie_headerline .content .headerline_review {
		color:#666;
		padding-top:5px
	}
	.movie_headerline .content .headerline_review a {
		margin:0 5px
	}
	.movie_headerline .intro a.title {
		display:block;
		height:19px;
		overflow:hidden
	}
	.movie_new {
		margin-bottom:30px
	}
	.movie_new h2 {
		margin-bottom:15px
	}
	.movie_new ul.content li {
		float:left;
		width:285px;
		padding-right:10px;
		border-bottom:1px dashed #ddd;
		margin-bottom:20px;
		padding-bottom:3px;
		height:130px;
		overflow:hidden
	}
	.movie_new ul.content li .img {
		float:left;
		width:80px;
		height:140px;
		overflow:hidden
	}
	.movie_new ul.content li .intro {
		float:right;
		width:200px;
		color:#000
	}
	.movie_new ul.content li .intro h3 {
		background:none;
		margin:0;
		padding:0;
		font-size:14px;
		line-height:16px;
		height:auto
	}
	.movie_new ul.content li .intro h3 span {
		color:black;
		font-size:14px;
		line-height:16px;
		margin-right:5px
	}
	.movie_new ul.content li .intro .star {
		color:#ff5138;
		font-size:10px
	}
	.movie_review {
		margin-bottom:30px
	}
	.movie_review h2 {
		margin-bottom:0px
	}
	.movie_review .ilst {
		display:none
	}
	.movie_review .nlst {
		margin-left:0
	}
	.movie_review .clst {
		margin-left:3px;
		padding-left:0
	}
	.music_new {
		margin:30px 0
	}
	.music_new {
		margin-bottom:30px
	}
	.music_new h2 {
		margin-bottom:15px
	}
	.music_new ul.content li {
		float:left;
		width:285px;
		padding-right:10px;
		border-bottom:1px dashed #ddd;
		margin-bottom:20px;
		padding-bottom:3px;
		height:105px;
		overflow:hidden
	}
	.music_new ul.content li .img {
		float:left;
		width:85px;
		height:105px;
		overflow:hidden
	}
	.music_new ul.content li .intro {
		float:right;
		width:190px;
		color:#000
	}
	.music_new ul.content li .intro h3 {
		background:none;
		margin:0;
		padding:0;
		font-size:14px;
		line-height:16px;
		height:auto
	}
	.music_new ul.content li .intro h3 span {
		color:black;
		font-size:14px;
		line-height:16px;
		margin-right:5px
	}
	.music_new ul.content li .intro .star {
		color:#ff5138;
		font-size:10px
	}
	.music_review {
		margin-bottom:30px
	}
	.music_review h2 {
		margin-bottom:0px
	}
	.music_review .ilst {
		display:none
	}
	.music_review .nlst {
		margin-left:0
	}
	.music_review .clst {
		margin-left:3px
	}
	.newtags {
		margin-bottom:30px
	}
	.newtags h2 {
		margin-bottom:0
	}
	.newtags ul.content {
		padding:10px 0;
		border-bottom:1px dashed #ddd
	}
	.newtags ul.last {
		border-bottom:none
	}
	.newtags ul.content li {
		width:60px;
		overflow:hidden;
		float:left
	}
	.movie_top {
		margin-bottom:30px
	}
	.movie_top ul li {
		border-bottom:1px dashed #ddd;
		padding:0 0 7px 0;
		margin-bottom:7px;
		line-height:14px
	}
	.movie_top ul li div.no {
		float:left;
		width:20px;
		font-size:9px;
		text-align:center
	}
	.movie_top ul li div.name {
		float:left;
		width:250px;
		overflow:hidden
	}
	.box_chart {
		float:left;
		width:230px;
		word-wrap:break-word;
		overflow:hidden
	}
	.box_chart_num {
		float:right
	}
	.movie_top ul li div.up,.movie_top ul li div.down,.movie_top ul li div.stay {
		color:#999;
		width:20px;
		float:right;
		display:block;
		font-size:9px;
		padding-left:15px;
		background:url(/f/book/fbb389d8a17f5185561ca14e81b6279495abd3a8/pics/movie_top.gif) no-repeat
	}
	.movie_top ul li div.down {
		background-position:0 -12px
	}
	.movie_top ul li div.stay {
		background-position:0 -24px
	}
	.movie_show .content dl dt {
		height:100px
	}
	.movie_show .content dl dd {
		color:#999
	}
	.bigstar50 {
		background-position:0 0
	}
	.bigstar45 {
		background-position:0 -15px
	}
	.bigstar40 {
		background-position:0 -30px
	}
	.bigstar35 {
		background-position:0 -45px
	}
	.bigstar30 {
		background-position:0 -60px
	}
	.bigstar25 {
		background-position:0 -75px
	}
	.bigstar20 {
		background-position:0 -90px
	}
	.bigstar15 {
		background-position:0 -105px
	}
	.bigstar10 {
		background-position:0 -120px
	}
	.bigstar05 {
		background-position:0 -135px
	}
	.bigstar00 {
		background-position:0 -150px
	}
	#tablern .block5 {
		width:300px;
		overflow:hidden
	}
	#tablern .block5 .content {
		width:400px
	}
	#tablern .block5 .content dl {
		margin-right:20px
	}
	#tablerm .block5 .content dl {
		margin:0 5px 10px 0
	}
	.movie_headerline div.content {
		_position:absolute;
		_z-index:-1
	}
	.movie_headerline .content .headerline_content {
		_float:left;
		_margin-left:8px
	}
	.movie_review .clst {
		_overflow:visible
	}
	.fav {
		margin-bottom:20px
	}
	.fav .obs {
		width:89px;
		margin-bottom:15px
	}
	.fav .obs dd {
		height:auto;
		margin-bottom:5px;
		text-align:center
	}
	.page_address .mi {
		width:80px;
		margin-right:3px
	}
	.page_address .address_suggest {
		width:180px
	}
	.page_address .district {
		padding:5px 0 5px 0
	}
	#event_albums {
		overflow:hidden;
		width:100%
	}
	.block5 .content dl dd {
		margin:0;
		padding-top:3px;
		overflow:hidden
	}
	.column4_list {
		margin:10px 0 0 5px
	}
	.column4_list h1 {
		margin:0;
		padding:0
	}
	.column4_list p {
		margin:0;
		_padding:5px 0 0 0
	}
	.column4_list li {
		float:left;
		display:inline;
		width:100px;
		margin:0 50px 30px 0
	}
	.dlist {
		padding-bottom:20px;
		border-bottom:1px dashed #ccc
	}
	.col2_doc_text {
		margin-left:65px
	}
	.block5 .content dl dd.long {
		height:100px
	}
	.doulist-add-btn {
		float:left;
		margin-right:15px
	}
	.fleft {
		float:left
	}
	.fright {
		float:right
	}
	.cleft {
		clear:left
	}
	.clearfix:after {
		content:".";
		display:block;
		height:0;
		clear:both;
		visibility:hidden
	}
	.clearfix {
		zoom:1;
		display:inline-block;
		_height:1px
	}
	* html .clearfix {
		height:1%
	}
	.clearfix {
		display:block
	}
	#interest_sect_level {
		clear:both;
		padding:20px 0 3px
	}
	.ul_subject_menu {
		margin-left:-15px
	}
	.ul_subject_menu li {
		float:left;
		display:inline;
		line-height:14px;
		margin-left:15px
	}
	.ul_subject_menu .rr {
		float:none
	}
	.rating_detail_wrap {
		padding:10px 0 50px
	}
	.rating_detail_wrap .fleft,.rating_detail_wrap .starstop,.rating_detail_wrap .power {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:middle
	}
	.rating_detail_wrap .power {
		height:14px;
		margin:0 3px;
		background:#ffdb88
	}
	.rating_detail_star {
		float:left;
		width:265px;
		line-height:21px
	}
	.rating_detail_chart {
		float:left;
		width:321px
	}
	.rating_detail_chart p {
		margin:0
	}
	.dlist li {
		margin-bottom:13px;
		border-bottom:1px dashed #ddd
	}
	.dlist li p {
		margin:0;
		padding:0 0 10px 0
	}
	.dlist li .dlist_content {
		float:left;
		width:550px
	}
	.rating_list ul {
		padding-bottom:10px
	}
	.rating_list li {
		margin:0 0 3px
	}
	.rating_list li.on {
		padding:2px 0
	}
	.rating_list li.on a {
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat left top;
		display:inline-block;
		padding:0 0 0 3px
	}
	.rating_list li.on a span {
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat right top;
		display:block;
		line-height:12px;
		padding:2px 3px 2px 0;
		color:#fff
	}
	.color_red,.color-red {
		color:red
	}
	.color_gray,.color-gray {
		color:#666
	}
	.color-green {
		color:#072
	}
	.color-orange {
		color:#e77200
	}
	.font_normal {
		font-size:12px
	}
	.starstop {
		margin:0
	}
	p.gact {
		margin:0
	}
	.subjectwrap {
		position:none;
		float:none;
		width:auto
	}
	.input_read_only {
		color:#666;
		background:#eee
	}
	.show {
		display:block
	}
	.hide {
		display:none
	}
	.add_vote {
		padding:2px 0
	}
	.add_vote .add_vote_name {
		width:100px;
		float:left;
		text-align:right;
		color:#666
	}
	.add_vote .add_vote_subject,.add_vote .add_vote_button,.add_vote .line {
		margin-left:110px
	}
	.add_vote .add_vote_subject input,.add_vote .add_vote_subject textarea {
		width:380px
	}
	.add_vote .line {
		border-bottom:1px dashed #ddd;
		height:1px;
		line-height:1px;
		font-size:1px;
		margin-top:3px;
		margin-bottom:6px
	}
	.add_vote .add_vote_button {
		margin-top:20px
	}
	.vote_wrapper {
		margin:10px 0 5px 0
	}
	.vote_wrapper h2,#vote_list_right li h2 {
		color:#000;
		margin:0;
		padding:0;
		font-weight:normal
	}
	.vote_wrapper ul,#vote_list_right li {
		margin:15px 0
	}
	#vote_list .vote_wrapper ul li,#vote_list_right li ul li {
		border:none;
		margin:0
	}
	.vote_wrapper ul li span {
		padding-right:20px
	}
	.vote_wrapper ul li .vote_item {
		float:left;
		width:265px;
		word-wrap:break-word
	}
	.vote_wrapper ul li .vote_item_long {
		float:left;
		word-wrap:break-word
	}
	.vote_wrapper ul li .vote_item input,.vote_wrapper ul li .vote_item_long input {
		float:left;
		width:15px
	}
	.vote_wrapper ul li .vote_item label {
		float:left;
		width:240px
	}
	.vote_wrapper ul li .vote_item_long label {
		float:left;
		width:450px
	}
	.vote_wrapper ul li .vote_line {
		float:left;
		overflow:hidden;
		width:180px
	}
	.vote_wrapper ul li .vote_line em {
		float:left;
		height:8px;
		width:150px;
		font-size:0;
		margin-top:5px;
		background:#e0e78a
	}
	.vote_wrapper ul li .vote_percent {
		float:left;
		width:50px;
		color:#aaa;
		font-size:10px
	}
	.vote_wrapper p,#vote_list_right p {
		color:#666;
		margin:0;
		padding:0
	}
	.vote_wrapper p .voted {
		color:#aaa;
		margin-right:20px
	}
	.vote_wrapper input {
		vertical-align:middle
	}
	#vote_list li {
		margin-bottom:30px;
		border-bottom:1px dashed #ccc
	}
	#vote_list li.last {
		border:none
	}
	#vote_list_right li ul {
		margin:15px 0
	}
	#vote_list_right li {
		padding-bottom:3px;
		margin-bottom:25px;
		border-bottom:1px dashed #ccc
	}
	#vote_list_right p.pt15 {
		padding-top:15px
	}
	.pt6 {
		padding-top:6px
	}
	.pt10 {
		padding-top:10px
	}
	.pt15 {
		padding-top:15px
	}
	.pt20 {
		padding-top:20px
	}
	.pt30 {
		padding-top:30px
	}
	.pt40 {
		padding-top:40px
	}
	.pr5 {
		padding-right:5px
	}
	.pb10 {
		padding-bottom:10px
	}
	.pb15 {
		padding-bottom:15px
	}
	.pl20 {
		padding-left:20px
	}
	.mt10 {
		margin-top:10px
	}
	.mt15 {
		margin-top:15px
	}
	.mt20 {
		margin-top:20px
	}
	.mt30 {
		margin-top:30px
	}
	.mt40 {
		margin-top:40px
	}
	.mt90 {
		margin-top:90px
	}
	.mr3 {
		margin-right:3px
	}
	.mr4 {
		margin-right:4px
	}
	.mr5 {
		margin-right:5px
	}
	.mr6 {
		margin-right:6px
	}
	.mr10 {
		margin-right:10px
	}
	.mr15 {
		margin-right:15px
	}
	.mr30 {
		margin-right:30px
	}
	.mb5 {
		margin-bottom:5px
	}
	.mb8 {
		margin-bottom:8px
	}
	.mb10 {
		margin-bottom:10px
	}
	.mb15 {
		margin-bottom:15px
	}
	.mb20 {
		margin-bottom:20px
	}
	.mb30 {
		margin-bottom:30px
	}
	.mb40 {
		margin-bottom:40px
	}
	.mb50 {
		margin-bottom:50px
	}
	.ml8 {
		margin-left:8px
	}
	.ml10 {
		margin-left:10px
	}
	#common .prev,#common .next {
		float:left;
		margin-top:40px
	}
	#common .prev a {
		display:block;
		width:18px;
		height:18px;
		text-indent:-9999px;
		background:url(/f/book/985dd3a77d7dd1467f5769dcc10c652930039a02/pics/left_right.gif) no-repeat -6px -7px
	}
	#common .prev a:focus {
		outline:none
	}
	#common .prev .dis {
		cursor:default;
		background:url(/f/book/985dd3a77d7dd1467f5769dcc10c652930039a02/pics/left_right.gif) no-repeat -6px -40px
	}
	#common .next a {
		display:block;
		width:18px;
		height:18px;
		text-indent:-9999px;
		background:url(/f/book/985dd3a77d7dd1467f5769dcc10c652930039a02/pics/left_right.gif) no-repeat -34px -7px
	}
	#common .next a:focus {
		outline:none
	}
	#common .next .dis {
		cursor:default;
		background:url(/f/book/985dd3a77d7dd1467f5769dcc10c652930039a02/pics/left_right.gif) no-repeat -34px -40px
	}
	#common div {
		float:left;
		width:525px;
		height:105px;
		overflow:hidden;
		padding-bottom:20px
	}
	#common #win {
		width:21999px
	}
	#rating a:hover,.content dt a:hover,.mbtl a:hover,.img a:hover,.ob dt a:hover,.aob a:hover,a.nbg:hover,a.gtright:hover,.headerline_img a:hover {
		background:none
	}
	.interest_form .tags {
		margin:10px 0
	}
	.interest_form dt {
		float:left;
		width:65px;
		color:#666
	}
	.interest_form dd {
		float:left;
		width:400px;
		margin:0 0 3px;
		line-height:23px
	}
	#mytags {
		margin-top:10px
	}
	.indentpop {
		padding:10px 18px
	}
	.indentpop1 {
		padding:0 18px
	}
	.interest_form .comment-label .num {
		float:right;
		color:#333
	}
	.interest_form .interest-setting,.interest_form .comment,.interest_form .comment-label {
		width:98%
	}
	.interest-form-ft label input,.interest_form label input {
		margin:1px 4px;
		*margin:0;
		vertical-align:text-bottom
	}
	.interest_form .private {
		float:right
	}
	.interest_form .inp-tags {
		padding:3px;
		width:50%;
		border:1px solid #ccc
	}
	.topbar-wrapper {
		margin-bottom:5px
	}
	.interest-status {
		float:left;
		font-size:14px;
		line-height:1
	}
	.interest-rating {
		float:left
	}
	.tags-switch {
		text-align:right
	}
	.interest-form-hd {
		padding:12px 18px;
		width:100%;
		margin:0 -18px 15px;
		clear:both;
		background:#ebf5ea;
		overflow:hidden
	}
	.interest-form-hd h2 {
		margin:0;
		line-height:1.2
	}
	.interest-form-hd .gact a:link,.interest-form-hd .gact a:hover {
		line-height:1.2;
		padding:0 3px
	}
	.interest-form-ft {
		padding:10px 18px;
		width:100%;
		margin:0 -18px;
		clear:both;
		background:#e9eef2;
		border-top:1px solid #d9e2e9;
		overflow:hidden;
		margin-top:15px
	}
	.interest-form-ft label {
		line-height:1.6
	}
	.interest-form-ft .shuo {
		float:left
	}
	.interest-form-ft .bn-flat {
		float:right
	}
	.interest-form-ft .bn-flat input {
		font-size:14px
	}
	#advtags {
		display:inline-block;
		width:100%
	}
	.dialog-shuo .rectitle .m {
		color:#072 !important
	}
	.tagbtn {
		cursor:pointer
	}
	.gract {
		color:#072;
		text-decoration:none;
		font-size:12px;
		text-align:center;
		border-right:1px solid #AAFFAA;
		border-bottom:1px solid #AAFFAA;
		background-color:#f2fbf2;
		padding:3px 3px 2px 3px;
		margin-top:2px;
		cursor:pointer;
		white-space:nowrap
	}
	.gract:hover {
		color:#FFFFFF;
		font-size:12px;
		border-right:1px solid #33FF33;
		border-bottom:1px solid #33FF33;
		background-color:#55FF55;
		padding:3px 3px 2px 3px;
		margin-top:2px
	}
	.gract a:link {
		text-decoration:none;
		color:#072;
		font-size:12px;
		text-align:center;
		padding:3px 3px 2px 3px;
		margin-top:2px
	}
	.gract a:visited {
		text-decoration:none;
		color:#072;
		font-size:12px;
		text-align:center;
		padding:3px 3px 2px 3px;
		margin-top:2px
	}
	.gract a:hover {
		color:#072;
		font-size:12px;
		border-left:1px solid #99FF99;
		border-top:1px solid #99FF99;
		border-right:1px solid #33FF33;
		border-bottom:1px solid #33FF33;
		background-color:#55FF55;
		padding:3px 3px 2px 3px;
		margin-top:2px
	}
	.rdact {
		color:#BBBBBB;
		text-decoration:none;
		font-size:12px;
		text-align:center;
		border-right:1px solid #AAFFAA;
		border-bottom:1px solid #AAFFAA;
		background-color:#f2fbf2;
		padding:3px 3px 2px 3px;
		margin-top:2px;
		cursor:pointer
	}
	.w210 {
		width:210px;
		word-wrap:break-word
	}
	.w240 {
		width:240px;
		word-wrap:break-word
	}
	.w250 {
		width:250px
	}
	.w450 {
		width:450px
	}
	.w490 {
		width:490px;
		word-wrap:break-word;
		overflow:auto
	}
	.w500 {
		width:500px
	}
	.w550 {
		width:550px
	}
	.h65 {
		height:65px
	}
	h2.green_tab a.redbutt {
		float:right;
		margin:0;
		padding:0 7px 0 0
	}
	h2.green_tab .pl a {
		float:none;
		margin:0;
		padding:0
	}
	.simple_list li {
		padding-bottom:10px;
		margin-bottom:12px;
		border-bottom:1px dashed #ddd
	}
	.simple_list h3 {
		font-size:12px;
		margin:0;
		padding:0;
		height:auto;
		background:none
	}
	.simple_list p {
		word-wrap:break-word;
		overflow:hidden;
		margin:0;
		padding:0
	}
	.simple_list .userface {
		float:left;
		width:48px;
		margin-right:12px
	}
	.simple_list .comment {
		float:left;
		width:569px
	}
	.title_line {
		padding:15px 0 14px;
		border-bottom:1px solid #ddd
	}
	.simple_list {
		margin:15px 0 50px
	}
	#all_comment {
		margin:15px 0 0
	}
	#all_comment .comment {
		width:521px
	}
	#event_map,#event-map {
		width:308px;
		height:200px;
		margin-bottom:30px;
		overflow:hidden
	}
	#event_map a:hover,#event-map a:hover {
		background:none
	}
	#event-map .map-confirm a:hover {
		background:#039
	}
	.map-confirm h2 {
		color:#000;
		font-weight:bold;
		width:200px;
		margin-bottom:0
	}
	.map-confirm p {
		line-height:18px;
		margin:6px 0 0;
		padding:0
	}
	.map-confirm p.evt-address {
		margin:0;
		width:214px;
		word-wrap:break-word
	}
	.map-confirm textarea {
		width:206px;
		height:50px;
		margin-bottom:-5px;
		font-size:12px
	}
	.gray-border {
		border:1px solid #ccc
	}
	.pos-comment {
		width:206px;
		word-wrap:break-word
	}
	.align-right {
		text-align:right
	}
	ol.policy li {
		margin:8px 0
	}
	.tags-list {
		margin-bottom:15px;
		line-height:23px
	}
	.tags-list a {
		margin-right:20px;
		display:inline-block
	}
	#tag_list span {
		white-space:nowrap
	}
	.review-panel {
		padding-top:30px
	}
	.review-panel ul {
		padding:15px 0 0
	}
	.review-panel li {
		float:left;
		display:inline;
		height:16px;
		line-height:16px
	}
	.review-panel li.rec {
		float:right
	}
	.review-panel .rec a:hover {
		background:#003399
	}
	a.btn-red,a.btn-green,a.btn-brown {
		display:block;
		height:16px;
		width:30px;
		padding-right:5px;
		line-height:16px;
		*line-height:17px;
		background:url(/f/book/82de3e5d3e4e06ed94337edace0da3d39b069d2b/pics/btn-red.gif) no-repeat right top
	}
	a.btn-green {
		background:url(/f/book/4ccbbe0f627af598b063ed5a15c40efb2ce2113a/pics/btn-green.gif) no-repeat right top
	}
	a.btn-brown {
		background:url(/f/book/8aa06d4ca882c90bb98e15da0fcb7587cd16e6cb/pics/btn-brown.gif) no-repeat right top
	}
	a.btn-red span,a.btn-green span,a.btn-brown span {
		display:block;
		color:#a49099;
		padding-left:5px;
		background:#fff url(/f/book/82de3e5d3e4e06ed94337edace0da3d39b069d2b/pics/btn-red.gif) no-repeat
	}
	a.btn-green span {
		color:#6ca767;
		background:#fff url(/f/book/4ccbbe0f627af598b063ed5a15c40efb2ce2113a/pics/btn-green.gif) no-repeat
	}
	a.btn-brown span {
		color:#977c87;
		background:#fff url(/f/book/8aa06d4ca882c90bb98e15da0fcb7587cd16e6cb/pics/btn-brown.gif) no-repeat
	}
	.review-note {
		float:right
	}
	.review-stat {
		color:#666
	}
	.review-stat em {
		color:#666;
		font-style:normal
	}
	.review-stat .useful {
		margin-right:6px
	}
	.review-stat {
		color:#666
	}
	.review-note {
		margin-top:5px
	}
	.btn-useful,.btn-unuseful {
		display:inline-block;
		*display:inline;
		*zoom:1;
		line-height:22px;
		*line-height:23px;
		vertical-align:middle;
		text-align:center;
		margin:0 2px;
		*margin:0;
		width:42px;
		height:22px;
		overflow:hidden;
		margin-bottom:2px
	}
	a.btn-useful:link,a.btn-useful:visited,a.btn-useful:hover,a.btn-useful:active {
		color:#333;
		background:transparent url(/f/book/fec05340d3645bd632ab8b62eb690a1af1112fc7/pics/bg_rev.png) no-repeat 0 0
	}
	a.btn-useful:hover,a.btn-useful:active {
		background-position:0 -22px
	}
	a.btn-unuseful:link,a.btn-unuseful:visited,a.btn-unuseful:hover,a.btn-unuseful:active {
		color:#333;
		background:transparent url(/f/book/fec05340d3645bd632ab8b62eb690a1af1112fc7/pics/bg_rev.png) no-repeat -42px 0
	}
	a.btn-unuseful:hover,a.btn-unuseful:active {
		background-position:-42px -22px
	}
	.topic-content .user-face,.topic-reply .user-face {
		float:left;
		width:48px;
		height:48px;
		overflow:hidden
	}
	.topic-content .topic-doc {
		float:right;
		width:520px;
		margin-bottom:10px
	}
	.topic-content .topic-doc h3 {
		margin:0;
		padding:5px 0;
		height:auto;
		background:none
	}
	.topic-content .topic-doc p {
		margin:0;
		padding:0;
		word-wrap:break-word;
		overflow:hidden
	}
	.topic-content .topic-opt {
		padding:15px 0 0
	}
	.topic-content .topic-opt .fleft {
		color:#666;
		margin-right:10px
	}
	.topic-reply li {
		margin:0 0 20px 48px;
		position:relative
	}
	.topic-reply li .reply-doc {
		float:right;
		width:473px
	}
	.topic-reply li .reply-doc h4 {
		margin:0 0 15px 4px;
		height:22px;
		line-height:22px
	}
	.topic-reply li .reply-doc p {
		margin:0 0 25px 0;
		word-wrap:break-word;
		overflow:hidden
	}
	.bg-img-green {
		display:block;
		background:#f2fbf2
	}
	.group_banned {
		text-align:right
	}
	.topic-similar-groups {
		margin-top:64px
	}
	.timeline-album {
		float:left;
		margin:8px 12px 8px 0
	}
	.timeline-album-rec {
		float:left;
		margin:8px 14px 0 0
	}
	.bkses {
		padding:15px 0;
		border-top:1px #ddd solid
	}
	.bkimg {
		float:left;
		margin-left:5px;
		margin-top:5px
	}
	.bkdesc {
		margin-left:95px
	}
	.bkcount {
		float:left;
		color:#666;
		margin-right:6px
	}
	.about {
		margin-top:6px
	}
	.bkstar {
		float:left;
		margin-top:3px
	}
	.avgr {
		color:#ff5138;
		font-weight:bold
	}
	.bkbi {
		float:right;
		color:#777
	}
	.bkbuy {
		float:right;
		color:#777;
		width:154px
	}
	.bkbuy div {
		margin-bottom:5px
	}
	.hideif00is0 {
		display:none
	}
	.border-none {
		border:none
	}
	ul.group-request-list {
		margin:16px 0;
		padding-top:7px;
		border-top:1px dashed #ccc
	}
	ul.group-request-list li {
		border-bottom:1px dashed #ccc;
		padding-bottom:7px;
		margin-bottom:8px
	}
	ul.group-request-list li ul li {
		float:left;
		display:inline;
		padding-bottom:0;
		margin-bottom:0;
		border:none
	}
	ul.group-request-list li ul li p {
		margin:0;
		padding:0
	}
	ul.group-request-list li ul li.mr3 {
		height:4em;
		line-height:4em;
		overflow:hidden
	}
	ul.group-request-list li ul li.w500 {
		_width:499px
	}
	ul.group-request-list li ul li .fright {
		margin-bottom:5px
	}
	ul.group-request-list li ul li .fright a {
		margin-left:8px
	}
	.group-request-words {
		width:380px;
		clear:both
	}
	.group-request-userface {
		margin-right:15px
	}
	.group-request-userface img {
		border:1px solid #ddd;
		margin-top:3px
	}
	.indent3 {
		padding-left:50px
	}
	.userface-border,.userinfo-block {
		display:none;
		position:absolute;
		border:1px solid #e0e0e0;
		border-right:1px solid #b5b5b5
	}
	.userface-border {
		border-bottom:1px solid #fff;
		margin:5px 0 0 -7px;
		width:60px;
		height:60px;
		z-index:999
	}
	.userinfo-block {
		padding:5px 6px;
		width:180px;
		margin:66px 0 0 -7px;
		background:#fff
	}
	.userinfo-block ul li {
		float:left;
		width:50%
	}
	#user a:hover .userface-border,#user a:hover .userinfo-block {
		display:block
	}
	.admin-text {
		color:#f92d09
	}
	a.admin-link {
		color:#f92d09;
		background:none
	}
	a.admin-link:hover {
		color:#fff;
		background:#f92d09
	}
	.search-wrap {
		margin:5px 0 25px;
		text-align:center
	}
	.search-wrap .search-btn {
		padding:0 8px
	}
	.book-search {
		width:350px;
		background:#fbfbfb;
		border:1px solid #ccc;
		padding:3px;
		color:#ccc
	}
	.hot-tags {
		padding-bottom:15px
	}
	.hot-tags li {
		padding-bottom:11px;
		margin-bottom:13px;
		border-bottom:1px dashed #ccc
	}
	.hot-tags li ul li {
		float:left;
		display:inline;
		width:180px;
		margin:0 25px 0 0;
		padding:0;
		border:none
	}
	.hot-tags li ul li.last {
		margin-right:0
	}
	.hot-tags-col5 {
		padding-bottom:20px
	}
	.hot-tags-col5 li {
		border-bottom:1px dashed #ddd;
		padding-bottom:10px;
		margin-bottom:10px
	}
	.hot-tags-col5 li ul li {
		float:left;
		display:inline;
		width:62px;
		margin:0;
		padding:0;
		border:none
	}
	.rec-writers {
		border:1px solid #ddd;
		position:relative;
		left:0;
		top:0;
		padding:15px;
		margin-bottom:30px
	}
	.rec-writers p {
		color:#888;
		margin:12px 0 2px 0
	}
	.rec-writers .close {
		margin:0;
		position:absolute;
		top:15px;
		right:15px
	}
	.rec-writers .close .minisubmit {
		padding:0 4px;
		background:transparent;
		font-family:"Comic Sans MS";
		float:none;
		color:#ccc
	}
	.rec-writers .close .minisubmit:hover {
		background:#fff;
		color:#888
	}
	.tag-title {
		margin-bottom:5px
	}
	.tag-title a {
		color:#999
	}
	.tag-title a:hover {
		color:#fff;
		background:#999
	}
	.tag-items {
		font-size:14px
	}
	.tag-items a {
		float:left;
		margin:0 13px 3px 0;
		white-space:nowrap
	}
	.tag-items a.last {
		margin-right:0
	}
	.tabs-wrap {
		clear:both;
		position:relative;
		overflow:hidden;
		height:180px;
		width:590px
	}
	ul.cover-list {
		position:absolute;
		height:158px;
		width:590px;
		overflow:hidden;
		padding:2px 0 20px
	}
	ul.cover-list li {
		float:left;
		margin-right:15px;
		width:106px;
		overflow:hidden
	}
	ul.cover-list li.last {
		margin:0
	}
	ul.cover-list li a:hover {
		background:none
	}
	ul.switch-dot {
		float:right;
		margin-top:6px
	}
	ul.switch-dot li {
		float:left;
		display:inline;
		width:8px;
		height:8px;
		margin-right:4px;
		cursor:pointer;
		background:url(/f/book/5f9e1c1056b7db35dffcaf72e9c06cf70d2a8b84/pics/switch_dot_small.jpg) no-repeat 0 0
	}
	.switch-dot li.current {
		background-position:-12px 0
	}
	.entry-list-col2 li {
		border-bottom:1px dashed #ddd;
		padding-bottom:12px;
		margin-bottom:17px
	}
	.entry-list-col2 h2 {
		background:none
	}
	.entry-list-col2 .cover {
		float:left;
		margin-right:18px
	}
	.entry-list-col2 li ul li {
		float:left;
		display:inline;
		width:260px;
		padding:0 35px 0 0;
		margin:0;
		border:none
	}
	.entry-list-col2-review {
		clear:both;
		padding-top:8px
	}
	.entry-list-col2-review p {
		margin:5px 0 0;
		padding:0
	}
	.entry-star-small {
		margin:0;
		padding:0
	}
	.entry-star-small .star-img {
		margin-bottom:0
	}
	.entry-star-small .font-small,.entry-star-small .ml8 {
		line-height:13px
	}
	.entry-list-col1 {
		padding-bottom:20px
	}
	.entry-list-col1 h2 {
		margin:0 0 6px
	}
	.entry-list-col1 .quote {
		margin:5px 0 0;
		padding:0 0 0 15px;
		width:205px
	}
	.entry-list-col1 .info {
		float:left;
		width:205px
	}
	.entry-list-col1 li {
		border-bottom:1px dashed #ddd;
		padding-bottom:10px;
		margin-bottom:10px;
		overflow:hidden
	}
	.entry-list-col1 li .cover {
		float:left;
		margin-right:18px
	}
	.entry-list-col1 li .cover img {
		max-width:70px
	}
	.entry-list-col1 li .userface {
		float:left;
		margin-right:14px
	}
	.entry-list-col1 li p {
		margin:0;
		padding:0 0 2px
	}
	.entry-list-col2s {
		padding-bottom:20px
	}
	.entry-list-col2s li {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:top;
		width:293px;
		padding:15px 0 10px;
		border-top:1px dashed #ddd
	}
	.entry-list-col2s .noline {
		border-top:none;
		padding-top:0
	}
	.entry-list-col2s li .userface {
		float:left;
		margin-right:14px
	}
	.entry-list-col2s li .comment {
		float:left;
		width:225px
	}
	.entry-list-col2s li p {
		margin:0;
		padding:0 0 2px
	}
	.entry-list-col3 {
		padding-bottom:15px
	}
	.entry-list-col3 li {
		float:left;
		display:inline;
		width:103px;
		padding-top:5px
	}
	.entry-list-col3 li p {
		margin:0;
		padding:0;
		height:100px;
		text-align:center;
		padding-bottom:5px
	}
	.entry-list-col3 li h2 {
		font-size:12px;
		width:100px;
		text-align:center
	}
	.simple-dashed-list {
		padding-bottom:25px
	}
	.simple-dashed-list a {
		margin-right:5px
	}
	.simple-dashed-list p {
		margin:0
	}
	.simple-dashed-list li {
		*width:310px;
		padding-bottom:5px;
		margin-bottom:4px;
		border-bottom:1px dashed #ddd
	}
	.detail-frame {
		display:none
	}
	.arrow-left {
		position:absolute;
		width:6px;
		height:9px;
		top:30px;
		left:0;
		margin-left:-6px;
		background:url(/f/book/0c7aaee283143e4913cd29511dba37ffbca46ddd/pics/arrow_gray.gif) no-repeat
	}
	.arrow-right {
		position:absolute;
		width:6px;
		height:9px;
		top:30px;
		left:326px;
		background:url(/f/book/0c7aaee283143e4913cd29511dba37ffbca46ddd/pics/arrow_gray.gif) no-repeat -6px 0
	}
	.detail-tip {
		position:absolute;
		width:300px;
		background:#fff;
		border:1px solid #ddd;
		padding:13px 13px 10px;
		word-wrap:break-word
	}
	.detail-tip h2 {
		color:#111;
		padding-top:5px
	}
	.detail-tip p {
		margin:0 0 10px
	}
	.detail-tip {
		border-color:#ddd
	}
	.shadow-right {
		-moz-border-radius:3px;
		-webkit-border-radius:3px;
		-moz-box-shadow:2px 2px 2px #999;
		-webkit-box-shadow:2px 2px 2px #999
	}
	.shadow-left {
		-moz-border-radius:3px;
		-webkit-border-radius:3px;
		-moz-box-shadow:-2px 2px 2px #999;
		-webkit-box-shadow:-2px 2px 2px #999
	}
	.font-small {
		font-size:10px
	}
	.font-normal {
		font-size:12px
	}
	.color-red {
		color:red
	}
	.color-lightgray {
		color:#aaa
	}
	.pl20 {
		padding-left:20px
	}
	.mb25 {
		margin-bottom:25px
	}
	.chart-dashed-list {
		clear:both;
		border:1px solid #eee
	}
	.chart-dashed-list li {
		border-bottom:1px dashed #ddd;
		padding:15px 8px 5px;
		*padding-bottom:15px
	}
	.chart-dashed-list li.last {
		border:none;
		padding-bottom:6px
	}
	.chart-dashed-list p {
		float:left;
		margin:0 0 10px;
		padding:0
	}
	.chart-dashed-list p.cover {
		width:125px;
		overflow:hidden
	}
	.chart-dashed-list h2 {
		float:left;
		margin:0;
		padding:3px 0 8px;
		width:445px
	}
	.chart-dashed-list li .font-small,.chart-dashed-list li .ml8 {
		line-height:13px
	}
	.chart-dashed-list li .star-img {
		margin-bottom:0
	}
	.green-num-box {
		font-size:10px;
		color:green;
		width:15px;
		height:15px;
		line-height:15px;
		margin-right:15px;
		text-align:center;
		background:url(/f/book/488c1a1e8562bc1c1baf7cf33074f094a97bb983/pics/chart_top.gif) no-repeat
	}
	.arrow-up,.arrow-stay,.arrow-down {
		width:20px;
		height:15px;
		padding-left:15px;
		color:#999;
		font-size:12px;
		background:url(/f/book/816c0b9c9a74c937c4bb4310994ea65c07696d43/pics/arrow-trend.gif) no-repeat
	}
	.arrow-up {
		background-position:0 3px
	}
	.arrow-down {
		background-position:0 -15px
	}
	.arrow-stay {
		background-position:0 -35px
	}
	.grid-12-12 .article {
		float:left;
		width:470px
	}
	.grid-12-12 .aside {
		float:right;
		width:470px
	}
	.cover-col-4 li {
		float:left;
		margin:0 10px 15px 0;
		height:145px;
		max-width:105px;
		min-width:100px;
		overflow:hidden
	}
	.cover-col-4 li a:hover {
		background:none
	}
	.cover-col-4 li.clear {
		width:0;
		height:0;
		margin:0
	}
	.cover-col-4 li.last {
		margin-right:0
	}
	.l590 {
		left:590px
	}
	.btn-prev a,.btn-prev a:active,.btn-prev a:hover,.btn-next a,.btn-next a:active,.btn-next a:hover {
		display:block;
		width:18px;
		height:18px;
		text-indent:-9999px;
		background:url(/f/book/985dd3a77d7dd1467f5769dcc10c652930039a02/pics/left_right.gif) no-repeat -6px -7px
	}
	.btn-prev a:focus,.btn-next a:focus {
		outline:none
	}
	.btn-prev a.dis,.btn-prev a.dis:link,.btn-prev a.dis:visited,.btn-prev a.dis:hover,.btn-prev a.dis:active,.btn-next a.dis,.btn-next a.dis:link,.btn-next a.dis:visited,.btn-next a.dis:hover,.btn-next a.dis:active {
		cursor:default;
		background:url(/f/book/985dd3a77d7dd1467f5769dcc10c652930039a02/pics/left_right.gif) no-repeat -6px -40px
	}
	.btn-next a,.btn-next a:active,.btn-next a:hover {
		background-position:-34px -7px
	}
	.btn-next a.dis,.btn-next a.dis:link,.btn-next a.dis:visited,.btn-next a.dis:hover,.btn-next a.dis:active {
		background-position:-34px -40px
	}
	.img_link:hover {
		background:none
	}
	.doulist-form {
		padding-top:15px
	}
	.doulist-form li {
		margin-bottom:20px
	}
	.doulist-form .doulist-form-item {
		float:left;
		font-size:14px;
		color:#072;
		text-align:right;
		margin-right:20px;
		width:80px
	}
	.doulist-form .doulist-form-input {
		float:left
	}
	.radio-banner {
		width:600px;
		height:178px;
		margin:15px 0 0
	}
	.radio-banner a {
		display:block;
		position:relative;
		top:92px;
		left:418px;
		text-indent:-9999px;
		width:100px;
		height:33px
	}
	.radio-banner a:focus {
		outline:none
	}
	.radio-banner a:hover {
		background:none
	}
	.cart_pop {
		padding:8px 12px;
		width:188px;
		font-size:14px;
		position:relative
	}
	.gray_bg {
		background:#f4f4f4
	}
	.cadetbule1_bg {
		background:#98F5FF
	}
	.lightyellow_bg {
		background:#FFFADC
	}
	.lightyellow_box {
		padding:8px 10px;
		background:#fffadc;
		border:1px solid #faf3c9
	}
	.lightyellow_box li {
		padding:3px 0;
		border-bottom:1px dashed #ddd
	}
	.lightyellow_box li.last {
		padding:6px 0 0;
		border:none
	}
	.aright {
		text-align:right
	}
	.data_list {
		width:100%;
		padding:0;
		text-align:left;
		margin-bottom:3px
	}
	.data_list th,.data_list td {
		text-align:center;
		border-bottom:1px dashed #ddd;
		padding:10px 0
	}
	.data_list tr.last td {
		border:none
	}
	.ml10 {
		margin-left:10px
	}
	.ml20 {
		margin-left:20px
	}
	.w20 {
		width:20px
	}
	.cart_info {
		max-width:400px
	}
	.sort_tabs {
		width:84px
	}
	.num_th {
		width:40px
	}
	.vinfo {
		color:#777;
		width:600px;
		float:left;
		text-align:left
	}
	.vname {
		color:#111;
		font-weight:bold;
		margin-right:5px
	}
	.data_list .book_title {
		width:102px;
		text-align:left;
		word-break:break-all
	}
	#interest_sect_level .bicelink .rr {
		float:none
	}
	.col2-list {
		width:590px;
		margin:15px 0 15px
	}
	.col2-list li {
		width:250px;
		float:left
	}
	.bold {
		font-weight:bold
	}
	.rela {
		position:relative
	}
	#music-events {
		margin-bottom:25px
	}
	#music-events li {
		margin-bottom:10px;
		padding-bottom:10px;
		border-bottom:1px dashed #ddd
	}
	#music-events .title {
		font-size:14px
	}
	.col2-list {
		width:590px;
		margin:15px 0 15px
	}
	.col2-list li {
		width:250px;
		float:left
	}
	.vs-mod li {
		float:left;
		width:293px;
		border:1px solid #f0f8e8
	}
	.vs-mod h2 {
		text-align:center;
		height:28px;
		line-height:28px;
		padding:0;
		margin:0;
		background:#f0f8e8
	}
	.vs-mod h3 {
		font-size:13px;
		padding:0;
		margin:0 0 3px;
		background:none;
		height:auto
	}
	.vs-mod .vs-good .vs-content {
		padding:10px 15px 15px 15px
	}
	.vs-mod .vs-bad .vs-content {
		padding:10px 10px 15px 20px
	}
	.vs-mod .vs-bad {
		border-left:none
	}
	.vs-detail p {
		margin:3px 0 15px;
		word-wrap:break-word
	}
	.vs-author {
		color:#aaa;
		margin:0 0 8px
	}
	.vs-author .stars {
		margin-left:0
	}
	.vs-author a {
		margin-right:5px
	}
	.vs-useful {
		font-size:12px;
		color:#666;
		float:right
	}
	.vs-more {
		color:#aaa
	}
	.tags-result {
		color:#666
	}
	.tags-result .tip {
		color:#999
	}
	.tags-result .add-tag {
		display:inline-block;
		cursor:pointer;
		color:#37a;
		margin:0 12px 0 0;
		word-spacing:nowrap
	}
	.tags-result .add-tag:hover {
		color:#fff;
		background:#37a
	}
	.tags-result .more {
		margin:0
	}
	.tags-hide {
		display:none
	}
	.tags-result .opt {
		display:inline-block
	}
	.tags-hide input {
		border:1px solid #ccc;
		padding:2px;
		width:120px;
		margin:0 10px 0 0
	}
	.tags-add {
		margin:0 5px 0 10px
	}
	.tags-del {
		display:inline-block;
		position:relative;
		cursor:pointer;
		height:12px;
		width:12px;
		top:-10px;
		_top:-15px;
		left:3px;
		background:url(/f/book/a59f00df704ec3227c8caa50a611267bae4ee8d6/pics/del.png) no-repeat 0 -11px;
		overflow:hidden
	}
	.tags-del:hover,.tags-hover {
		background-position:0 0
	}
	.bn-create,.bn-create span,.bn-post,.bn-post span {
		display:inline-block;
		display:-moz-inline-stack;
		*zoom:1;
		height:22px;
		line-height:0;
		font-size:0;
		padding-left:3px;
		vertical-align:middle;
		overflow:hidden;
		letter-spacing:4px
	}
	.bn-create,.bn-create span,.bn-post,.bn-post span,x:default {
		display:inline-block
	}
	.bn-create span,.bn-post span {
		color:#333;
		padding:0 8px 0 5px;
		background:url(/f/book/2d79ca6cbe2477a2907bd2f1c0610e76e8b8fa5f/pics/post.gif) no-repeat 100% 0;
		line-height:23px;
		font-size:12px;
		cursor:pointer
	}
	a.bn-create,a.bn-post {
		background:url(/f/book/2d79ca6cbe2477a2907bd2f1c0610e76e8b8fa5f/pics/post.gif) no-repeat 0 0;
		color:#9e9e9e;
		padding-left:17px
	}
	.bn-create,.bn-create span {
		letter-spacing:0
	}
	.rec-intro {
		color:#666;
		height:168px
	}
	.tag-fav-cloud {
		padding:15px 10px 10px;
		*padding:15px 10px 0;
		text-align:center;
		line-height:26px;
		border:1px solid #e2f2d7;
		background:#f1f8ec
	}
	.tag-fav-cloud a {
		display:inline-block;
		margin-right:15px
	}
	.tag-fav-cloud .all {
		font-size:14px
	}
	.tag-fav-cloud .current {
		color:#fff;
		background:#92B878;
		padding:0 5px;
		-moz-border-radius:4px;
		-webkit-border-radius:4px;
		border-radius:4px
	}
	.c1 {
		font-size:14px
	}
	.c2 {
		font-size:15px
	}
	.c3 {
		font-size:16px
	}
	.c4 {
		font-size:17px
	}
	.c5 {
		font-size:18px
	}
	.c6 {
		font-size:19px
	}
	.c7 {
		font-size:20px
	}
	.c8 {
		font-size:21px
	}
	.c9 {
		font-size:22px
	}
	.c10 {
		font-size:23px
	}
	.c11 {
		font-size:24px
	}
	.rec-list {
		padding:20px;
		border:1px solid #e2f2d7
	}
	.list-col5 li {
		float:left;
		width:129px;
		margin-right:10px
	}
	.list-col5 del {
		font-size:13px;
		margin-left:5px;
		color:#999;
		cursor:pointer
	}
	.list-col5 del:hover {
		color:#000
	}
	.list-col5 .sep {
		display:block;
		float:none;
		font-size:0;
		clear:both;
		padding:0 0 25px
	}
	.list-col5 .last {
		margin:0
	}
	.list-col5 .cover {
		margin-bottom:5px
	}
	.list-col5 .title {
		display:block;
		font-size:12px
	}
	.list-col5 .info {
		display:block;
		color:#666;
		margin-bottom:3px
	}
	.list-col5 .star-img {
		display:inline-block;
		margin:0
	}
	.list-col5 .count {
		color:#666
	}
	.list-col5 .cover-a {
		min-height:80px
	}
	.list-col5 .cover-a:hover {
		background:none
	}
	.simple-dashed-list .entry {
		float:left;
		width:230px;
		word-wrap:break-word
	}
	.simple-dashed-list .rec-num {
		float:right;
		width:65px;
		color:#666
	}
	.simple-dashed-list .tags {
		clear:both;
		color:#666
	}
	.simple-dashed-list .last {
		border:none
	}
	.simple-dashed-list input {
		float:right;
		color:#aaa;
		cursor:pointer
	}
	.simple-dashed-list input:hover {
		color:#fff
	}
	.not-loading {
		display:block;
		float:right;
		margin:5px 10px 0 0;
		height:14px;
		width:14px
	}
	.loading {
		display:block;
		float:right;
		margin:5px 10px 0 0;
		height:14px;
		width:14px;
		background:url(/f/book/bda8c5b2e6d3b359384cf55bc49ab2654e413046/pics/spinner.gif) no-repeat
	}
	.loading-err {
		display:block;
		float:right;
		margin:5px 10px 0 0;
		height:14px;
		width:14px;
		color:#fee;
		-moz-border-radius:4px 4px 4px 4px;
		background:none repeat scroll 0 0 #ff6666;
		border:1px solid #E2F2D7;
		line-height:15px
	}
	.poster-col4 li {
		float:left;
		display:inline;
		width:136px;
		margin:0 15px 20px 0;
		overflow:hidden
	}
	.poster-col4 .cover {
		overflow:hidden;
		font-size:0;
		padding:0;
		margin:0
	}
	.poster-col4 .last {
		margin:0 0 20px
	}
	.poster-col4 .sep {
		float:none;
		display:block;
		margin:0;
		padding:0;
		clear:both;
		font-size:0
	}
	.poster-col4 .name {
		display:block;
		font-size:12px
	}
	.poster-col4 .prop {
		color:#999;
		line-height:18px
	}
	.opt-bar-line {
		border-bottom:1px dashed #ddd;
		padding:0 0 5px;
		margin:0 0 15px;
		color:#999
	}
	.opt-bar-line .opt-mid {
		position:absolute;
		margin-left:250px
	}
	.opt-bar-line .opt-left {
		position:absolute
	}
	.filter-list {
		background:#f4f4ec;
		padding:13px
	}
	.filter-list li {
		margin:0 0 8px
	}
	.filter-list td.first {
		width:120px
	}
	.filter-list a {
		float:left;
		padding:0 2px;
		line-height:16px
	}
	.filter-list .current a {
		color:#fff;
		padding:0px 0px 0px 8px;
		line-height:18px;
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat 0 0
	}
	.filter-list .current span {
		padding:2px 8px 2px 0px;
		background:url(/f/book/c11786f46f5303e6c9a5c7c73df163e8b7f1c9c8/pics/green_tab.gif) no-repeat 100% 0;
		line-height:12px;
		display:block
	}
	.filter-list ul {
		margin:0 0 10px;
		border-bottom:1px dashed #ddd
	}
	.filter-list ul li {
		text-align:center
	}
	.filter-list ul.last {
		margin:0 0 -8px;
		border:none
	}
	.filter-list .se {
		padding:0 0 0 10px
	}
	.magnifier {
		padding:0 0 0 15px;
		background:url(/f/book/5a47a15f4dc81221ea809b7590854f556625ec2b/pics/magnifier.png) no-repeat left center
	}
	.photo-show {
		margin:0 0 10px;
		text-align:center;
		overflow:hidden
	}
	.opt-bar .update {
		float:left;
		color:#666
	}
	.opt-bar .update .gact {
		margin-left:20px
	}
	.opt-bar .rec {
		float:right;
		color:#666
	}
	.rec-btn,.rec-btn:hover {
		display:inline-block;
		*display:block;
		line-height:10em;
		overflow:hidden;
		margin-left:6px;
		width:69px;
		height:18px;
		background:url(/f/book/8f70c1054607a044c7b4b6e2b37ad0f31a290db9/pics/recommend.gif) no-repeat
	}
	.slidebar {
		margin:0 0 40px
	}
	.slidebar .btn-prev {
		float:left;
		margin:30px 7px 0 0
	}
	.slidebar .btn-next {
		float:right;
		margin:30px 0 0
	}
	.slidebar .slide-wrap {
		float:left;
		position:relative;
		height:82px;
		width:260px;
		overflow:hidden
	}
	.slidebar ul {
		position:absolute;
		*height:82px;
		left:-267px;
		width:9999px;
		overflow:hidden
	}
	.slidebar li {
		float:left;
		margin:0 7px 0 0
	}
	.slidebar .last {
		margin:0
	}
	.slidebar li a {
		_float:left;
		display:block;
		color:#aaa;
		width:70px;
		height:70px;
		padding:4px;
		text-align:center;
		border:2px solid #eee
	}
	.slidebar .current a,.slidebar li a:hover {
		border-color:#91b776;
		background:none
	}
	.slidebar li img {
		height:70px;
		width:70px;
		_margin-bottom:-4px
	}
	.poster-info {
		font-size:12px;
		margin:0 0 30px
	}
	.poster-info .last {
		padding-top:5px
	}
	.poster-search-list li {
		margin:0 0 5px
	}
	.pic-col5 {
		margin:8px 0 0
	}
	.pic-col5 li {
		float:left;
		display:inline;
		font-size:0;
		width:100px;
		overflow:hidden;
		margin-right:15px
	}
	.pic-col5 .last {
		margin:0
	}
	.upload-step li {
		float:left;
		display:inline;
		color:#ddd;
		height:27px;
		line-height:27px;
		font-size:18px;
		padding-left:50px;
		margin-right:35px
	}
	.upload-step .step1 {
		background:url(/f/book/ab51a97f5bde90b74db628c1259cab060d649386/pics/step_num.png) no-repeat
	}
	.upload-step .step1-current {
		color:#111;
		background:url(/f/book/ab51a97f5bde90b74db628c1259cab060d649386/pics/step_num.png) no-repeat 0 -27px
	}
	.upload-step .step2 {
		background:url(/f/book/ab51a97f5bde90b74db628c1259cab060d649386/pics/step_num.png) no-repeat 0 -54px
	}
	.upload-step .step2-current {
		color:#111;
		background:url(/f/book/ab51a97f5bde90b74db628c1259cab060d649386/pics/step_num.png) no-repeat 0 -81px
	}
	.upload-area {
		padding:10px 0 0 100px
	}
	.upload-info .poster {
		float:left;
		margin-right:20px
	}
	.upload-info ul {
		float:left;
		padding:8px 0 0
	}
	.upload-info li {
		width:400px;
		margin:0 0 15px
	}
	.upload-info label {
		float:left;
		width:75px;
		text-align:right;
		margin:0 13px 0 0
	}
	.form-star {
		color:red;
		font-size:13px;
		font-weight:bold
	}
	.kind-still,.kind-wall {
		display:none
	}
	.poster-loader {
		display:inline-block;
		margin:0 0 0 20px;
		width:14px;
		height:14px;
		background:url(/f/book/bda8c5b2e6d3b359384cf55bc49ab2654e413046/pics/spinner.gif) no-repeat
	}
	.l260 {
		left:260px
	}
	#pos-ver {
		width:120px;
		border:1px solid #ddd;
		padding:2px
	}
	#pos-desc {
		width:280px;
		height:60px;
		border:1px solid #ddd;
		padding:2px
	}
	.add-more {
		float:right;
		color:#999;
		font-size:12px;
		*margin-top:-20px
	}
	.title-bar {
		border-bottom:1px solid #ddd;
		margin:0 0 16px;
		padding:0 0 5px
	}
	.users-list li {
		float:left;
		display:inline;
		width:196px;
		margin:0 0 10px;
		padding:0 0 5px;
		border-bottom:1px dashed #ddd
	}
	.users-list span {
		display:block;
		height:18px;
		line-height:18px
	}
	.users-list .face {
		float:left;
		margin:0 10px 0 0
	}
	.users-list .info {
		float:left
	}
	.users-list .rel {
		color:#666
	}
	.users-list .opt a {
		color:#999
	}
	.users-list .opt a:hover {
		color:#fff;
		background:#37a
	}
	.bn-follow,.bn-friend,.bn-mail {
		display:inline-block;
		line-height:11em;
		width:71px;
		height:18px;
		margin:0 2px 0 0;
		overflow:hidden
	}
	.bn-follow,.bn-follow:hover {
		background:url(/f/book/2ac3e6c81f2557c8077874ff446e927e1d37257f/pics/add_contact1.gif) no-repeat
	}
	.bn-mail,.bn-mail:hover {
		background:url(/f/book/d46aab63b60b66a670f71e1aae755258c947894f/pics/send_doumail.gif) no-repeat
	}
	.bn-friend,.bn-friend:hover {
		background:url(/f/book/c66ea3cc81f89f9063cd39553ef0e74196a9d9d9/pics/add_friend1.gif) no-repeat
	}
	.bn-follow:focus,.bn-friend:focus,.bn-mail:focus {
		outline:none
	}
	#follow-dialog {
		width:280px
	}
	#profile .userface {
		float:left;
		margin:1px 10px 8px 0
	}
	#dialog-msg {
		margin:0 0 0 20px;
		color:red
	}
	#captcha-input {
		display:block
	}
	.pop-tips {
		display:block;
		color:#999;
		padding:2px 0 0 19px
	}
	.captcha-form {
		display:none;
		margin:0 0 5px
	}
	.captcha-form input {
		border:1px solid #ddd;
		padding:1px;
		margin:0 6px 0 0
	}
	#captcha-input {
		margin:2px 0
	}
	.top-blank {
		margin:20px 0 0
	}
	.a-lnk {
		overflow:auto;
		display:block;
		margin-bottom:30px;
		line-height:1.5
	}
	.a-lnk img {
		float:left;
		margin-right:10px;
		border:0
	}
	a.a-lnk:hover,a.a-lnk:active {
		color:#37a;
		background-color:transparent
	}
	.icon-play {
		background:url(/f/book/b8d0a75490599fb542136854b874918446ef98c1/pics/playicon.png) no-repeat
	}
	.col5 li {
		padding:10px 0 8px;
		border-bottom:1px solid #ddd
	}
	.col5 .green-num-box {
		float:left;
		margin-right:10px
	}
	.col5 .face {
		float:left;
		width:48px;
		margin:0 18px -3px 0
	}
	.col5 .face:hover {
		background:none
	}
	.col5 .intro {
		float:left;
		width:400px
	}
	.col5 .intro h3 {
		cursor:pointer;
		display:inline-block;
		_display:inline;
		zoom:1;
		padding:0 0 0 20px;
		margin:0 0 2px;
		height:auto;
		background-position:0 -33px
	}
	.col5 .intro p {
		color:#666;
		margin:0
	}
	.col5 .intro p.icon-play {
		cursor:pointer;
		display:inline-block;
		_display:inline;
		zoom:1;
		padding:0 0 0 20px;
		background-position:0 -33px
	}
	.col5 .trend {
		float:right
	}
	.col5 .days {
		float:right;
		color:#999;
		text-align:right;
		width:64px
	}
	.col3 li {
		padding:3px 0;
		border-bottom:1px dashed #ddd
	}
	.col3 .rank {
		float:left;
		width:12px;
		text-align:center;
		padding:0 6px
	}
	.col3 .entry {
		float:left;
		margin:0;
		color:#666;
		width:222px
	}
	.col3 .trend {
		float:right
	}
	.col3 .green-num-box {
		float:left;
		margin-right:10px
	}
	.col3 .face {
		float:left;
		margin-right:10px
	}
	.col3 .intro {
		float:left;
		color:#666
	}
	.col3 .intro h3 {
		margin:0;
		padding:0;
		height:auto;
		background:none
	}
	.col3 .intro p {
		margin:0
	}
	.col3 .days {
		float:right;
		color:#999;
		text-align:right;
		width:64px
	}
	#pop_artist .col3 {
		border-bottom:1px dashed #ddd
	}
	#pop_artist .col3 li {
		padding:10px 0 5px;
		border-bottom:1px dashed #ddd
	}
	.aside .mod {
		margin-bottom:40px;
		word-break:break-all
	}
	.mod:after {
		content:'\0020';
		display:block;
		clear:both
	}
	.a-btn,.a-btn-add,.a-btn-add-light,.a-btn-opt {
		display:inline-block;
		height:20px;
		line-height:20px;
		*line-height:22px;
		line-height:22px\9;
		overflow:hidden;
		*display:inline;
		zoom:1;
		border-radius:3px;
		-webkit-border-radius:3px;
		-moz-border-radius:3px
	}
	.a-btn:link,.a-btn:active,.a-btn:hover,.a-btn:visited,.a-btn-opt:link,.a-btn-opt:active,.a-btn-opt:hover,.a-btn-opt:visited {
		color:#797979;
		background:#fff3e7;
		border:1px solid #e7d7ca;
		padding:0 10px;
		outline:none
	}
	.a-btn-add:link,.a-btn-add:active,.a-btn-add:hover,.a-btn-add:visited {
		color:#584e46;
		border:1px solid #d6b79d;
		padding:0 22px 0 10px;
		background:#ffe6ce url(/f/book/ae0eda49bbe883198606693d0bf38012daeaff86/pics/icon-add.png) no-repeat 63px center
	}
	.a-btn-opt:link,.a-btn-opt:active,.a-btn-opt:hover,.a-btn-opt:visited {
		padding:0 18px 0 10px;
		background:#fff3e7 url(/f/book/c1caf2e50822ff9fe1d3d734a7ba1621c2441649/pics/icon-arrow-down.png) no-repeat 38px center
	}
	.a-btn-add-light:link,.a-btn-add-light:active,.a-btn-add-light:hover,.a-btn-add-light:visited {
		color:#625850;
		padding:0 10px 0 23px;
		background:#fdf9f5 url(/f/book/ae0eda49bbe883198606693d0bf38012daeaff86/pics/icon-add.png) no-repeat 10px center;
		border:1px solid #f1e5dc
	}
	.user-info {
		color:#666
	}
	.user-opt {
		clear:both;
		padding:8px 0
	}
	.user-intro {
		color:#666;
		word-wrap:break-word;
		overflow:hidden
	}
	.user-group {
		display:none;
		color:#666;
		margin:0 0 10px
	}
	.user-group-arrow {
		position:relative;
		top:5px;
		top:7px\9;
		*top:7px;
		_top:6px;
		display:inline-block;
		*display:inline;
		zoom:1;
		cursor:pointer;
		width:17px;
		height:17px;
		border:1px solid #fff;
		margin:0 0 0 -2px;
		*margin:0 0 0 -4px;
		background:url(/f/book/0d8719b551a21d7d9c4defeba5259d83b0f5e801/pics/icon-arrow-down-b.png) no-repeat center center
	}
	.set-group-list {
		display:none;
		position:absolute;
		z-index:999;
		top:17px;
		padding:6px 0 10px;
		width:170px;
		background:#fff;
		border:1px solid #d0dcd6
	}
	.set-group-list li {
		margin:0 0 1px;
		padding:2px 10px;
		*padding:1px 10px 3px;
		-moz-user-select:none;
		-webkit-user-select:none
	}
	.set-group-list li:hover,.set-group-list li.hover {
		color:#fff;
		background:#858585;
		*border:none
	}
	.set-group-list label {
		margin-left:2px;
		vertical-align:middle
	}
	.set-group-list input {
		*margin-right:0
	}
	.set-group-list .last {
		padding:6px 10px 0;
		margin:0
	}
	.set-group-list .last:hover {
		background:#fff;
		color:#333
	}
	.set-group-list .tips {
		display:block;
		color:#fab0b6;
		margin:0 0 0 16px
	}
	.set-group-list .tlimit {
		color:#fab0b6;
		margin:2px 0 0
	}
	.set-group-list .create-new {
		display:block;
		color:#333;
		padding:0 0 0 13px;
		_height:14px;
		background:url(/f/book/ae0eda49bbe883198606693d0bf38012daeaff86/pics/icon-add.png) no-repeat 0 center
	}
	.input-create {
		border:1px solid #d0dcd6;
		padding:4px 3px 3px;
		color:#666;
		width:142px
	}
	.brown-border {
		border-color:#e2d0c1
	}
	.user-opt .set-group-list {
		margin-left:-154px;
		background:#fff;
		border:1px solid #e2d0c1
	}
	.user-opt .user-group-arrow {
		border-color:#fff6ee
	}
	.user-opt .user-group-arrow:hover {
		background-color:#f7e9dc
	}
	.user-opt .arrow-select {
		background-color:#fff6ee;
		border:1px solid #e2d0c1;
		border-bottom:1px solid #fff
	}
	.user-list .arrow-select {
		background-color:#ebebeb;
		border:1px solid #d0dcd6;
		border-bottom:1px solid #fff
	}
	.user-list .user-group-arrow:hover {
		background-color:#e9f4e9
	}
	.user-rs {
		margin:0 0 0 15px;
		*margin:0 3px 0 15px
	}
	.user-cs {
		display:inline-block;
		*display:inline;
		zoom:1;
		padding:0 0 0 15px;
		background:url(/f/book/deb4cac1239eeff89863046cb2d5a257c310ba94/pics/icon-ok.png) no-repeat left
	}
	.sep-line {
		clear:both;
		font-size:0;
		height:0;
		border-bottom:1px solid #f5e9db;
		margin:5px;
		overflow:hidden
	}
	.user-group-list {
		display:none;
		position:absolute;
		margin:-6px 0 0;
		*margin:21px 0px 0px -60px;
		width:120px;
		background:#fff3e7;
		border:1px solid #e2d0c1;
		padding:6px 0
	}
	@media screen and (-webkit-min-device-pixel-ratio:0) {
		.user-group-list {
		margin:-1px 0 0
	}
	}.user-group-list li {
		_height:24px;
		_overflow:hidden
	}
	.user-group-list a:link,.user-group-list a:active,.user-group-list a:visited {
		display:block;
		color:#666;
		padding:2px 8px
	}
	.user-group-list a:hover {
		color:#fff;
		background:#858585
	}
	.more-opt {
		display:inline-block;
		*display:inline;
		zoom:1
	}
	.glist-all {
		margin:-1px 0 0 161px;
		margin:-1px 0 0 161px \9;
		*margin:21px 0 0 -60px
	}
	.fpl {
		float:left
	}
	.fmore-opt {
		float:left;
		margin:-3px 0 0 5px
	}
	.aside .mod {
		margin:0 0 40px
	}
	.user-list li {
		position:relative;
		*position:static;
		*z-index:10;
		padding:10px 0;
		*margin-bottom:-3px;
		border-bottom:1px solid #eee
	}
	.user-list>li:hover .ban {
		display:inline
	}
	.user-list .current {
		background:#fff8f2
	}
	.user-list .face {
		float:left;
		width:48px;
		height:48px;
		margin:0 13px 0 10px
	}
	.user-list .info {
		float:left;
		width:515px
	}
	.user-list .info h3 {
		margin:0 0 2px;
		height:auto;
		font:14px;
		background:none
	}
	.user-list .info p {
		position:relative;
		margin:0;
		color:#999;
		line-height:18px
	}
	.user-list .quote {
		margin:8px 0 0;
		padding:0 24px 0 15px
	}
	.info-box {
		text-align:center;
		background:#fff6ee;
		border:1px solid #faefe4;
		padding:10px 0;
		border-radius:6px;
		-webkit-border-radius:6px;
		-moz-border-radius:6px
	}
	.info-box .input_search {
		width:242px;
		font-size:14px
	}
	.user-list .user-cs {
		float:right;
		display:inline-block;
		*display:inline;
		zoom:1;
		font-size:12px;
		padding:0 0 0 15px;
		background:url(/f/book/deb4cac1239eeff89863046cb2d5a257c310ba94/pics/icon-ok.png) no-repeat left
	}
	.user-list .ban {
		position:absolute;
		right:10px;
		*right:auto;
		bottom:5px;
		*bottom:auto;
		*margin:46px 0 0 -50px;
		_margin:36px 0 0 -50px;
		display:none;
		color:#999;
		cursor:pointer
	}
	.user-list .quote span.inq {
		max-width:400px
	}
	.custom-popwin {
		width:360px
	}
	.pop-narrow {
		width:320px
	}
	.custom-popwin h1 {
		_position:relative;
		font-weight:normal;
		font-size:14px;
		color:#038013;
		width:346px;
		background:#ebf5eb url(/f/book/90a06554de8039edf680e26020cb165143ae00ad/pics/icon-ok-b.png) no-repeat 15px center;
		height:40px;
		line-height:40px;
		padding:0 0 0 40px;
		margin:-17px 0 0 -12px;
		border-top-left-radius:6px;
		border-top-right-radius:6px;
		-webkit-border-top-left:6px;
		-webkit-border-top-right-radius:6px;
		-moz-border-radius-topleft:6px;
		-moz-border-radius-topright:6px
	}
	.pop-narrow h1 {
		_position:relative;
		width:326px;
		background:#ebf5eb;
		padding:0 0 0 20px
	}
	.custom-form {
		padding:26px 10px 12px
	}
	.custom-popwin .arrow-select,.custom-popwin .arrow-select .user-group-arrow,.custom-popwin .arrow-select .user-group-arrow:hover {
		border-color:#e6e6e6;
		background-color:#e6e6e6
	}
	.sel-wrapper {
		float:left;
		padding:0 2px 0 10px;
		margin:0 0 20px;
		background:#f5f6f5;
		cursor:pointer;
		border:1px solid #d4ded9;
		border-radius:3px;
		-webkit-border-radius:3px;
		-moz-border-radius:3px
	}
	.sel-wrapper .user-group {
		margin:-4px 0 0;
		margin:-5px 0 1px \9;
		*margin:-2px 0px 2px
	}
	.sel-wrapper .user-rs {
		margin:0;
		*margin:0 -5px 0 0
	}
	.sel-wrapper .user-group-arrow {
		border-color:#f5f6f5;
		*margin:0;
		*top:3px
	}
	.sel-wrapper .user-group-arrow:hover {
		border-color:#f5f6f5;
		background-color:#f5f6f5
	}
	.sel-wrapper .set-group-list {
		top:87px;
		left:22px
	}
	.user-list .set-group-list {
		margin-left:-154px
	}
	.user-list .set-group-list li {
		*z-index:9999;
		border:none;
		padding:2px 10px;
		*padding:1px 10px 3px;
		*margin:0 0 1px
	}
	.user-list .set-group-list .last {
		padding:6px 10px 0;
		margin:0
	}
	.follow-msg {
		font-size:12px;
		line-height:18px;
		border:1px solid #cbd8d2;
		padding:7px;
		margin:0 0 16px;
		width:325px;
		height:45px
	}
	.lnk-flat,.lnk-confirm,.bn-flat {
		display:-moz-inline-box;
		display:inline-block;
		border-width:1px;
		border-style:solid;
		border-color:#bbb #bbb #999;
		*display:inline;
		*zoom:1;
		color:#444;
		border-radius:3px;
		-moz-border-radius:3px;
		-webkit-border-radius:3px;
		overflow:hidden;
		vertical-align:middle
	}
	.bn-flat:hover,a.lnk-flat:hover {
		border-color:#999 #999 #666;
		color:#333
	}
	.lnk-flat,.lnk-confirm,.bn-flat input {
		border:none;
		height:25px;
		padding:0 14px;
		color:#333;
		background:transparent url(/f/book/05e11739c2d942b85cfa521685bfb9ca028c9e42/pics/site/sp_all_2.png) repeat-x 0 -700px \9;
		font-size:12px;
		*padding:3px 8px 0;
		margin:0 !important;
		cursor:pointer;
		-webkit-appearance:none;
		border-radius:2px;
		-moz-border-radius:2px;
		-webkit-border-radius:2px;
		background-image:-moz-linear-gradient(-90deg,#fcfcfc 0,#e9e9e9 100%);
		background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,#fcfcfc),color-stop(1,#e9e9e9))
	}
	a.lnk-flat:hover,a.lnk-flat:active,.bn-flat input:hover,.bn-flat input:focus,.bn-flat-over input {
		color:#333 !important;
		background-color:transparent !important;
		background-position:1px -706px \9;
		background-image:-moz-linear-gradient(-90deg,#f8f8f8 0,#ddd 100%);
		background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,#f8f8f8),color-stop(1,#ddd))
	}
	a.lnk-flat:active,.bn-flat input:active,.bn-flat-active input {
		background:#ddd !important;
		color:#333 !important;
		border-color:#999 #999 #666 !important
	}
	.lnk-flat,.lnk-confirm {
		border-radius:4px;
		-webkit-border-radius:4px;
		-moz-border-radius:4px
	}
	.lnk-flat,.lnk-confirm {
		height:24px;
		padding:0 8px;
		line-height:24px;
		border:1px solid #d9d9d9
	}
	a.lnk-flat:link,a.lnk-flat:visited {
		color:#333;
		background:transparent url(/f/book/05e11739c2d942b85cfa521685bfb9ca028c9e42/pics/site/sp_all_2.png) repeat-x 0 -641px \9
	}
	a.lnk-flat:hover {
		color:#333;
		background-position:0 -701px \9
	}
	a.lnk-flat:active {
		color:#333;
		background:#ebebeb
	}
	@media all and (-webkit-min-device-pixel-ratio:10000),not all and (-webkit-min-device-pixel-ratio:0) {
		.lnk-flat,.bn-flat input {
		background:transparent url(/f/book/05e11739c2d942b85cfa521685bfb9ca028c9e42/pics/site/sp_all_2.png) repeat-x 0 -700px
	}
	a.lnk-flat:hover,a.lnk-flat:active,.bn-flat input:hover,.bn-flat-over input {
		background-position:1px 706px
	}
	a.lnk-flat:link,a.lnk-flat:visited {
		background:transparent url(/f/book/05e11739c2d942b85cfa521685bfb9ca028c9e42/pics/site/sp_all_2.png) repeat-x 0 -641px
	}
	a.lnk-flat:hover {
		background-position:0 -701px
	}
	}.bn-small {
		background:#ffdddd;
		border:1px solid #ffabab;
		color:#ff7676;
		-moz-border-radius:4px;
		-webkit-border-radius:4px;
		border-radius:4px;
		-webkit-appearance:none;
		cursor:pointer;
		height:14px\9;
		*height:15px;
		padding:0 2px;
		*padding:0
	}
	a.bn-small:link,a.bn-small:visited,a.bn-small:hover,a.bn-small:active {
		background:#ffdddd;
		color:#ff7676;
		padding:0 4px;
		line-height:1.8;
		font-size:12px;
		*line-height:1.3;
		zoom:1;
		*height:13px;
		*overflow:hidden
	}
	.input-btn {
		cursor:pointer;
		padding:3px 12px;
		padding:5px 12px 2px \9;
		*padding:5px 12px 2px;
		border:1px solid #d4ded9;
		border-radius:4px;
		-webkit-border-radius:4px;
		-moz-border-radius:5px;
		background:#f5f7f6;
		background:-webkit-gradient(linear,0 0,0 100%,from(#f8f9f8),to(#f3f5f4));
		background:-moz-linear-gradient(-90deg,#f8f9f8,#f5f7f6);
		background:#f8f9f8;
		*background:#f8f9f8;
		overflow:visible
	}
	.input-btn:active {
		background:#e6e6e6
	}
	.follow-btns {
		text-align:right
	}
	#db-talk-hd h2.green_tab .sep-wide a {
		margin:0 13px 0 0
	}
	#db-talk-hd h2.green_tab .sep-wide a.last {
		margin-right:0
	}
	#db-timeline-hd {
		border-bottom:1px solid #ddd;
		padding-bottom:10px;
		margin-bottom:5px
	}
	#db-timeline-hd .menu-list {
		float:left;
		width:515px;
		padding-top:3px
	}
	#db-timeline-hd .menu-list li {
		float:left;
		display:inline;
		_position:relative;
		_z-index:88;
		margin:0 10px 0 0
	}
	#db-timeline-hd .menu-list li a {
		_float:left;
		zoom:1;
		display:block;
		padding:0 2px;
		white-space:nowrap;
		_overflow:hidden;
		height:16px;
		line-height:16px
	}
	#db-timeline-hd .menu-list .on a {
		color:#fff;
		padding:0 5px;
		background:#83bf73;
		border-radius:3px;
		-webkit-border-radius:3px;
		-moz-border-radius:3px
	}
	#db-timeline-hd .opt-area {
		float:right
	}
	#db-timeline-hd .last {
		margin:0
	}
	#miniblog .menu-list {
		width:auto
	}
	.icon-edit {
		position:relative;
		*top:-3px;
		*left:-1px;
		_top:3px;
		display:inline-block;
		height:9px;
		width:9px;
		background:url(/f/book/0d56e141b25024b230e3361e98a10aec8084f93d/pics/icon-edit.png) no-repeat
	}
	.user-group-opt {
		float:right;
		font-size:12px;
		margin:-2px 0 0;
		*margin:-23px 0px 0px
	}
	.color-lightgray {
		color:#b1b4b5
	}
	.gray-loader {
		position:relative;
		margin:0 2px 0 0;
		*margin:4px 2px 2px 4px;
		vertical-align:middle
	}
	@media screen and (-webkit-min-device-pixel-ratio:0) {
		.gray-loader {
		margin:0 1px 0 0
	}
	}.group-opts-list {
		display:none;
		position:absolute;
		z-index:99;
		_top:16px;
		_left:0;
		padding:5px 0;
		width:80px;
		color:#333;
		border:1px solid #d0dcd6;
		background:#fff
	}
	#db-timeline-hd .group-opts-list li {
		float:none;
		display:block;
		cursor:pointer;
		color:#666;
		margin:0;
		padding:2px 0 2px 8px
	}
	#db-timeline-hd .group-opts-list li:hover,#db-timeline-hd .group-opts-list li.hover {
		border:none;
		color:#fff;
		background:#858585;
		margin:0
	}
	.large-input {
		border:1px solid #d0dcd6;
		padding:6px;
		width:288px
	}
	.custom-form .tips-area {
		display:block;
		color:#aaa;
		padding:3px 0 0
	}
	.custom-form .tlimit {
		color:#fab0b6
	}
	.group-tags {
		width:515px
	}
	.bn-std1,a.bn-std1:hover,.bn-std1 span {
		display:inline-block;
		*display:inline;
		*zoom:1;
		height:20px;
		overflow:hidden;
		background:transparent url(/f/book/e71bc59418cbce13979283ccd3b7ccf62116f2dd/pics/bg_bn_red.png) no-repeat 0 0
	}
	.bn-std1 span {
		background-position:100% 0;
		padding:0 10px;
		overflow:hidden;
		height:20px;
		line-height:20px;
		*line-height:22px;
		color:#524942;
		margin-left:3px
	}
	.tag-list {
		width:220px
	}
	.tag-list li {
		border-bottom:1px dashed #ddd;
		padding:2px 5px
	}
	.tag-list span {
		float:right
	}
	.tag-list .on {
		color:#fff;
		background:#92b878
	}
	.tag-list .on a {
		color:#fff
	}
	#db-usr-profile .info ul .sep {
		margin-left:-8px;
		margin-right:4px;
		color:#eee
	}
	#db-usr-profile img {
		vertical-align:bottom
	}
	.mod .opt .vv {
		margin-right:3px;
		background:url(/f/book/de93f496c38851747139e4008b63bfc680d4bb3e/pics/v.gif) no-repeat 0px 3px
	}
	.bn-add span,.bn-add,.bn-hot span,.bn-hot,.bn-std span,.bn-std {
		display:inline-block;
		display:-moz-inline-stack;
		*zoom:1;
		height:22px;
		line-height:0;
		font-size:0;
		padding-left:3px;
		vertical-align:middle;
		overflow:hidden
	}
	.bn-hot span,.bn-hot {
		height:24px
	}
	.bn-add,.bn-add span,.bn-hot,.bn-hot span,.bn-std span,.bn-std,x:default {
		display:inline-block
	}
	.bn-add span,.bn-hot span,.bn-std span {
		padding:0 8px 0 5px;
		background:url(/f/book/aadb298bc1dce8d8abc12fa968635517c73710b0/pics/core.png) no-repeat 100% 0;
		line-height:23px;
		font-size:12px;
		cursor:pointer
	}
	.bn-hot span {
		background-position:100% -23px;
		line-height:24px
	}
	.bn-add span {
		background-position:100% -71px;
		padding-right:15px
	}
	a.bn-std:link,a.bn-std:visited,a.bn-std:hover,a.bn-std:active {
		background:url(/f/book/aadb298bc1dce8d8abc12fa968635517c73710b0/pics/core.png) no-repeat 0 0;
		color:#000
	}
	a.bn-hot:link,a.bn-hot:visited,a.bn-hot:hover,a.bn-hot:active {
		background:url(/f/book/aadb298bc1dce8d8abc12fa968635517c73710b0/pics/core.png) no-repeat 0 -23px;
		color:#eb928c
	}
	a.bn-add:link,a.bn-add:visited,a.bn-add:hover,a.bn-add:active {
		background:url(/f/book/aadb298bc1dce8d8abc12fa968635517c73710b0/pics/core.png) no-repeat 0 -71px;
		color:#9e9e9e;
		padding-left:25px
	}
	a.bn-hot:hover,a.bn-hot:active {
		background-position:0 -47px
	}
	a.bn-hot:hover span,a.bn-hot:active span {
		background-position:100% -47px;
		color:#f4473b
	}
	#db-usr-profile .info ul .sep {
		margin-left:-8px;
		margin-right:4px;
		color:#eee
	}
	.infobox .ex2,.infobox .ex1 {
		clear:both;
		height:5px;
		line-height:0;
		font-size:0;
		margin-left:5px;
		background:url(/f/book/5361836272f03991e4452c0e4f3b776489eb806c/pics/info_bg.png) no-repeat 100% 0
	}
	.infobox .ex2 span,.infobox .ex1 span {
		position:relative;
		display:block;
		margin-left:-5px;
		width:5px;
		height:5px;
		overflow:hidden;
		background:url(/f/book/5361836272f03991e4452c0e4f3b776489eb806c/pics/info_bg.png) no-repeat 0 0
	}
	.infobox .ex2 {
		background-position:100% -5px
	}
	.infobox .ex2 span {
		background-position:0 -5px
	}
	.infobox .bd {
		word-wrap:break-word;
		padding:4px 9px;
		background:#fff6ed;
		border:1px solid #faefe3;
		border-width:0 1px;
		*display:inline-block
	}
	.infobox .bd:after {
		content:"\0020";
		display:block;
		clear:both
	}
	#miniblog_guide {
		position:relative;
		left:0;
		top:0;
		color:#31323b;
		background:#fff6ed;
		padding:12px;
		margin-bottom:15px;
		zoom:1
	}
	#miniblog_guide a.close {
		color:#31323b;
		padding:0 5px;
		position:absolute;
		right:7px;
		top:12px
	}
	#miniblog_guide a.close:hover {
		color:#31323b;
		background:#fff6ed
	}
	.notification-items ul.old {
		color:#808080
	}
	.notification-items li {
		padding:6px 10px 4px
	}
	.notification-items li.date {
		font-size:14px;
		color:#072;
		padding-left:0
	}
	.notification-items ul.new li {
		background:#ffe
	}
	.notification-items ul.new li.date {
		background:none
	}
	.notification-items a.discard {
		float:right;
		color:#ccc;
		padding:0 6px
	}
	.notification-items a:hover,.notification-items a:active {
		color:#fff;
		background:#ccc
	}
	.notification-items q {
		display:block;
		text-indent:3.3em
	}
	.notification-items .old q em {
		color:#aaa
	}
	.notification-items q em {
		color:#808080
	}
	.input-list {
		width:auto;
		position:absolute;
		padding:3px 0;
		border:1px solid #ddd;
		border-top:1px solid #eee;
		background:#fff
	}
	.input-list li {
		cursor:pointer;
		padding:3px 10px
	}
	.input-list li:hover {
		color:#000;
		background:#eee
	}
	.list-radio li {
		margin:0 0 20px
	}
	.desc-radio {
		float:left;
		margin:5px 5px 0
	}
	.sub-desc,.full-desc {
		float:left;
		margin:0;
		width:400px
	}
	.full-desc {
		display:none
	}
	.cust-desc {
		padding:5px;
		width:400px;
		height:100px
	}
	.warn_info {
		border:1px solid #FAEFE3;
		-moz-border-radius:4px;
		-webkit-border-radius:4px;
		border-radius:4px
	}
	.warn_info {
		background-color:#FFF6ED;
		padding:5px;
		margin-bottom:23px
	}
	.event_warn {
		margin-bottom:20px;
		color:gray
	}
	.donated-success {
		color:#5a7e59;
		background:url(/f/book/0bd7d28f183f77a8487d575aad15289611ef39a0/pics/ic_dz.png) no-repeat 0 50%;
		padding-left:12px
	}
	.donated-fail {
		color:#fab0b6
	}
	.dou-tip {
		width:230px;
		text-align:center
	}
	.btn-fav {
		display:inline-block;
		*display:inline;
		zoom:1;
		padding:0 8px 0 30px;
		vertical-align:middle;
		*vertical-align:baseline;
		height:19px;
		line-height:19px;
		line-height:21px\9;
		overflow:hidden;
		border:1px solid #edceba;
		margin-left:4px;
		-moz-border-radius:3px;
		-webkit-border-radius:3px;
		border-radius:3px
	}
	a.btn-fav:link,a.btn-fav:visited {
		border-color:#f2ece7;
		background-color:#fff6ee;
		color:#99776b
	}
	a.btn-fav:hover,a.btn-fav:active {
		border-color:#edceba;
		background-color:#fff0e2;
		color:#99776b
	}
	.fav-add,.fav-add:link,.fav-add:hover {
		background:url(/f/book/f392cc86b542687ce4011dd495ee9522dfe81d93/pics/ic_like.png) no-repeat 8px 3px
	}
	.fav-cancel,.fav-cancel:link,.fav-cancel:hover {
		background:url(/f/book/f392cc86b542687ce4011dd495ee9522dfe81d93/pics/ic_like.png) no-repeat 8px -17px
	}
	.fav-num {
		display:inline-block;
		*display:inline;
		zoom:1;
		color:#666
	}
	.fav-userlist {
		position:absolute;
		width:210px;
		left:50%;
		padding:0 0 20px 10px;
		background:#fff;
		border:1px solid #999;
		-moz-box-shadow:0 0 4px rgba(0,0,0,0.2);
		-webkit-box-shadow:0 0 4px rgba(0,0,0,0.2);
		box-shadow:0 0 4px rgba(0,0,0,0.2);
		zoom:1
	}
	.fav-userlist .bd {
		width:97%
	}
	.fav-userlist ul {
		margin-top:-2px
	}
	.fav-userlist li {
		margin-top:2px
	}
	.fav-userlist .pic {
		margin-right:8px;
		*display:inline;
		zoom:1
	}
	.fav-userlist .pic img {
		vertical-align:middle
	}
	.fav-userlist .hd {
		position:relative;
		text-align:right;
		padding:5px 10px;
		line-height:1.2;
		zoom:1
	}
	.fav-userlist .arrow {
		position:absolute;
		width:12px;
		height:7px;
		overflow:hidden;
		left:12px;
		top:-6px;
		background:url(/f/book/ae3434cf24244949954c28b02e10612063bd7f65/pics/bg_popup_arr.png) no-repeat 0 0
	}
	.arrow-bottom .arrow {
		top:auto;
		bottom:-6px;
		_bottom:-7px;
		background:url(/f/book/ae3434cf24244949954c28b02e10612063bd7f65/pics/bg_popup_arr.png) no-repeat 0 -11px
	}
	.sns-bar {
		clear:both;
		overflow:hidden;
		margin-bottom:20px;
		padding-top:20px;
		color:#666;
		*display:inline-block
	}
	.sns-bar-fav {
		float:right
	}
	.with-fav {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:middle;
		width:200px;
		text-align:right;
		margin-right:15px;
		padding-right:15px;
		border-right:1px solid #eaeaea
	}
	.with-fav .btn-fav {
		float:right;
		margin:0 0 0 12px
	}
	.sns-bar-donate {
		float:left;
		margin-right:15px
	}
	.sns-bar-rec {
		float:left
	}
	.sns-bar-online {
		float:right
	}
	.sns-bar form,.sns-bar .rec-sec {
		float:none;
		display:inline-block;
		*display:inline;
		zoom:1
	}
	.dou-tip .frm-item {
		position:relative;
		margin-bottom:5px;
		text-align:left;
		color:#666
	}
	.dou-tip .frm-item label {
		position:absolute;
		left:4px;
		top:0;
		top:2px\9;
		line-height:1.6;
		cursor:text;
		color:#999
	}
	.dou-tip .frm-item input {
		padding:2px;
		width:96%;
		border:1px solid #ddd;
		-moz-border-radius:2px;
		-webkit-border-radius:2px;
		border-radius:2px
	}
	.dou-tip .frm-item input:focus {
		border-color:#aaa
	}
	.dou-tip b {
		font-weight:300;
		color:#ff201a
	}
	.dou-tip p {
		color:#666;
		margin:0;
		text-align:left
	}
	.dou-tip .frm-submit .bn-flat {
		margin-right:1em
	}
	.dou-tip .bn-flat input {
		height:22px;
		padding:0 5px
	}
	.source-icon {
		vertical-align:text-top
	}
	.source-icon:hover {
		background:none
	}
	.more_event {
		margin-bottom:20px
	}
	.photo-complete {
		margin-bottom:15px;
		padding:15px 20px 1px;
		background:#f8f8f8
	}
	.photo-item {
		margin-bottom:15px
	}
	.photo-item .cover,.photo-item .intro {
		display:inline-block;
		*display:inline;
		zoom:1
	}
	.photo-item .cover {
		margin-right:10px;
		vertical-align:top
	}
	.photo-item .cover a {
		text-align:center;
		width:100px;
		display:block;
		margin-bottom:-3px
	}
	.photo-item .cover a:hover {
		background:none
	}
	.photo-item .choose-cover {
		text-align:center
	}
	.photo-item .intro p {
		text-align:right;
		margin:0
	}
	.photo-item .intro textarea {
		color:#666;
		width:424px;
		margin-bottom:3px\9;
		padding:5px;
		height:90px;
		border:1px solid #ddd
	}
	.submit-area {
		text-align:center
	}
	a.create-new-album:hover {
		background:none
	}
	.admin-delete-note .opt {
		text-align:right
	}
	.admin-delete-note td {
		height:28px
	}
	.admin-delete-note td label {
		font-size:14px
	}
	.sina_logo,.msn_logo {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:text-bottom;
		overflow:hidden
	}
	.sina_logo {
		width:17px;
		height:16px;
	}
	#book-user {
		margin:0 0 0 8px;
		margin-left:0;
		color:#666666
	}
	#header .booklogo {
		float:left;
		background:url(/f/book/5b831d51c910588b00b3ef6de2a7827eb72b95f7/pics/nav/lg_book_a7.png) no-repeat;
		display:block;
		width:142px;
		height:62px;
		text-indent:-9999px
	}
	a.ln-report {
		position:absolute;
		bottom:0;
		right:40px;
		display:none;
		color:#bbb
	}
	div.comment-item {
		margin-bottom:1em;
		word-break:break-word
	}
	.comment-item .author {
		background:#f2fbf2;
		color:#666;
		padding:2px 4px
	}
	.update-item,.comment-item {
		*zoom:1;
		overflow:hidden;
		margin-bottom:1.6em
	}
	.update-item .pic,.comment-item .pic {
		float:left;
		margin-right:20px
	}
	.update-item .content,.comment-item .content {
		overflow:hidden;
		zoom:1
	}
	.comment-item h3 {
		margin:1.5em 0 1em 0;
		height:1.7em;
		line-height:1.7em;
		padding-left:4px
	}
	.comment-item .title {
		font-size:14px
	}
	.admin-lnks a:link,.admin-lnks a:visited {
		color:#aaa
	}
	.admin-lnks a:hover,.admin-lnks a:active {
		background:#aaa;
		color:#fff
	}
	.comment-item .admin-lnks,.update-item .admin-lnks {
		text-align:right;
		color:#aaa
	}
	.comment-lnk {
		font-size:14px;
		color:#666
	}
	.a_folder .bn-arrow,.a_unfolder .bn-arrow {
		background:url(/f/book/30d6b18445bb4f47709f1c1ae7b5c7496e5a6fb2/pics/review-expand.png) no-repeat 0 0
	}
	.a_unfolder .bn-arrow {
		background-position:0 -12px
	}
	.a_unfolder:hover .bn-arrow {
		background-position:0 -32px
	}
	.a_folder .bn-arrow {
		background-position:0 2px
	}
	.a_folder:hover .bn-arrow {
		background-position:0 -63px
	}
	.bigstar50,.bigstar45,.bigstar40,.bigstar35,.bigstar30,.bigstar25,.bigstar20,.bigstar15,.bigstar10,.bigstar05,.bigstar00 {
		display:inline-block;
		*display:inline;
		zoom:1;
		background:url(/f/shire/680a4bc4c384199245b080c7104da5be8ed717d3/pics/rating_icons/ic_rating_m.png) no-repeat;
		background:-webkit-image-set(url(/f/shire/680a4bc4c384199245b080c7104da5be8ed717d3/pics/rating_icons/ic_rating_m.png) 1x,url(/f/shire/ee7f53d76c3f8ed4991bdbafdb9b2c90c0aedfef/pics/rating_icons/ic_rating_m@2x.png) 2x) no-repeat;
		background:-moz-image-set(url(/f/shire/680a4bc4c384199245b080c7104da5be8ed717d3/pics/rating_icons/ic_rating_m.png) 1x,url(/f/shire/ee7f53d76c3f8ed4991bdbafdb9b2c90c0aedfef/pics/rating_icons/ic_rating_m@2x.png) 2x) no-repeat;
		background:-o-image-set(url(/f/shire/680a4bc4c384199245b080c7104da5be8ed717d3/pics/rating_icons/ic_rating_m.png) 1x,url(/f/shire/ee7f53d76c3f8ed4991bdbafdb9b2c90c0aedfef/pics/rating_icons/ic_rating_m@2x.png) 2x) no-repeat;
		background:-ms-image-set(url(/f/shire/680a4bc4c384199245b080c7104da5be8ed717d3/pics/rating_icons/ic_rating_m.png) 1x,url(/f/shire/ee7f53d76c3f8ed4991bdbafdb9b2c90c0aedfef/pics/rating_icons/ic_rating_m@2x.png) 2x) no-repeat;
		width:75px;
		height:15px;
		margin:1px 0 0 0;
		overflow:hidden
	}
	.bigstar50+span.rating_num,.bigstar45+span.rating_num,.bigstar40+span.rating_num,.bigstar35+span.rating_num,.bigstar30+span.rating_num,.bigstar25+span.rating_num,.bigstar20+span.rating_num,.bigstar15+span.rating_num,.bigstar10+span.rating_num,.bigstar05+span.rating_num,.bigstar00+span.rating_num {
		font-size:16px;
		line-height:1
	}
	.bigstar50 {
		background-position:0 0px
	}
	.bigstar45 {
		background-position:0 -15px
	}
	.bigstar40 {
		background-position:0 -30px
	}
	.bigstar35 {
		background-position:0 -45px
	}
	.bigstar30 {
		background-position:0 -60px
	}
	.bigstar25 {
		background-position:0 -75px
	}
	.bigstar20 {
		background-position:0 -90px
	}
	.bigstar15 {
		background-position:0 -105px
	}
	.bigstar10 {
		background-position:0 -120px
	}
	.bigstar05 {
		background-position:0 -135px
	}
	.bigstar00 {
		background-position:0 -150px
	}
	.allstar50,.allstar45,.allstar40,.allstar35,.allstar30,.allstar25,.allstar20,.allstar15,.allstar10,.allstar05,.allstar00,.rating1-t,.rating15-t,.rating2-t,.rating25-t,.rating3-t,.rating35-t,.rating4-t,.rating45-t,.rating5-t,.rating-t,.starb ~ .stars5,.starb ~ .stars4,.starb ~ .stars3,.starb ~ .stars2,.starb ~ .stars1,.collectors .stars5,.collectors .stars4,.collectors .stars3,.collectors .stars2,.collectors .stars1 {
		display:inline-block;
		*display:inline;
		zoom:1;
		background:url(/f/shire/b8f4c3672ef81106701071831e22422a745d3b74/pics/rating_icons/ic_rating_s.png) no-repeat;
		background:-webkit-image-set(url(/f/shire/b8f4c3672ef81106701071831e22422a745d3b74/pics/rating_icons/ic_rating_s.png) 1x,url(/f/shire/0147ca9efddcac80050854590d26bee587b008df/pics/rating_icons/ic_rating_s@2x.png) 2x) no-repeat;
		background:-moz-image-set(url(/f/shire/b8f4c3672ef81106701071831e22422a745d3b74/pics/rating_icons/ic_rating_s.png) 1x,url(/f/shire/0147ca9efddcac80050854590d26bee587b008df/pics/rating_icons/ic_rating_s@2x.png) 2x) no-repeat;
		background:-o-image-set(url(/f/shire/b8f4c3672ef81106701071831e22422a745d3b74/pics/rating_icons/ic_rating_s.png) 1x,url(/f/shire/0147ca9efddcac80050854590d26bee587b008df/pics/rating_icons/ic_rating_s@2x.png) 2x) no-repeat;
		background:-ms-image-set(url(/f/shire/b8f4c3672ef81106701071831e22422a745d3b74/pics/rating_icons/ic_rating_s.png) 1x,url(/f/shire/0147ca9efddcac80050854590d26bee587b008df/pics/rating_icons/ic_rating_s@2x.png) 2x) no-repeat;
		width:55px;
		height:11px;
		margin:0 3px 0 0;
		overflow:hidden
	}
	.status-item .allstar50,.status-item .allstar45,.status-item .allstar40,.status-item .allstar35,.status-item .allstar30,.status-item .allstar25,.status-item .allstar20,.status-item .allstar15,.status-item .allstar10,.status-item .allstar05,.status-item .allstar00,.status-item .rating1-t,.status-item .rating15-t,.status-item .rating2-t,.status-item .rating25-t,.status-item .rating3-t,.status-item .rating35-t,.status-item .rating4-t,.status-item .rating45-t,.status-item .rating5-t,.status-item .rating-t,.status-item .starb ~ .stars5,.status-item .starb ~ .stars4,.status-item .starb ~ .stars3,.status-item .starb ~ .stars2,.status-item .starb ~ .stars1,.status-item .collectors .stars5,.status-item .collectors .stars4,.status-item .collectors .stars3,.status-item .collectors .stars2,.status-item .collectors .stars1 {
		margin:0 0 0 4px
	}
	.allstar50 {
		background-position:0 0px
	}
	.allstar45 {
		background-position:0 -11px
	}
	.allstar40 {
		background-position:0 -22px
	}
	.allstar35 {
		background-position:0 -33px
	}
	.allstar30 {
		background-position:0 -44px
	}
	.allstar25 {
		background-position:0 -55px
	}
	.allstar20 {
		background-position:0 -66px
	}
	.allstar15 {
		background-position:0 -77px
	}
	.allstar10 {
		background-position:0 -88px
	}
	.allstar05 {
		background-position:0 -99px
	}
	.allstar00 {
		background-position:0 -110px
	}
	.rating5-t,.starb ~ .stars5,.collectors .stars5 {
		background-position:0 0px
	}
	.rating45-t {
		background-position:0 -11px
	}
	.rating4-t,.starb ~ .stars4,.collectors .stars4 {
		background-position:0 -22px
	}
	.rating35-t {
		background-position:0 -33px
	}
	.rating3-t,.starb ~ .stars3,.collectors .stars3 {
		background-position:0 -44px
	}
	.rating25-t {
		background-position:0 -55px
	}
	.rating2-t,.starb ~ .stars2,.collectors .stars2 {
		background-position:0 -66px
	}
	.rating15-t {
		background-position:0 -77px
	}
	.rating1-t,.starb ~ .stars1,.collectors .stars1 {
		background-position:0 -88px
	}
	.rating1-t,.rating15-t,.rating2-t,.rating25-t,.rating3-t,.rating35-t,.rating4-t,.rating45-t,.rating5-t,.rating-t {
		padding-left:5px
	}
	#stars {
		font-size:0;
		vertical-align:text-bottom;
		cursor:pointer
	}
	#stars a img {
		vertical-align:text-bottom
	}
	.starstop,.stars {
		margin-right:5px
	}
	.starstop {
		float:left
	}
	.rating_nums,.rating_num {
		color:#e09015;
		font-size:12px;
		padding:0 3px
	}
	.status-item .rating_num {
		font-size:14px
	}
	.rating_nums {
		padding-left:0
	}
	.star .rating_num {
		color:#e09015;
		padding:0 5px 0 0
	}
	#interest_sect {
		overflow:hidden;
		word-wrap:break-word
	}
	#interest_sectl {
		float:left;
		width:155px;
		margin:2px 0 0 0;
		padding:0 0 0 15px;
		border-left:1px solid #eaeaea;
		color:#9b9b9b
	}
	#interest_sectl .rating_wrap {
		padding-bottom:15px;
		font-size:12px;
		line-height:14px
	}
	#interest_sectl .rating_wrap .rating_logo {
		line-height:1
	}
	#interest_sectl .rating_self {
		padding:0;
		line-height:2
	}
	#interest_sectl .rating_self:before,#interest_sectl .rating_self:after {
		content:'';
		display:block;
		clear:both
	}
	#interest_sectl .rating_self .rating_sum {
		clear:both
	}
	#interest_sectl .rating_num {
		color:#494949;
		padding:0;
		min-width:30%;
		font-size:28px
	}
	#interest_sectl .rating_right {
		float:left;
		padding:10px 0 10px 6px
	}
	#interest_sectl .rating_right.not_showed {
		padding:10px 0
	}
	#interest_sectl .power {
		height:10px;
		float:left;
		margin:1px 4px;
		background:#ffd596 none repeat scroll 0 0
	}
	#interest_sectl .power.color_gray {
		background:#ccc
	}
	#interest_sectl .rating_per {
		font-size:11px
	}
	#interest_sectl .rating_betterthan {
		position:relative;
		padding:15px 0;
		border-top:1px solid #eaeaea;
		color:#9b9b9b;
		margin:0
	}
	.rating_logo_wrap .content {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:top;
		font-size:12px;
		line-height:20px;
		color:#9b9b9b;
		margin-right:4px
	}
	.rating_helper_wrap {
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:top;
		position:relative;
		line-height:18px
	}
	.rating_helper_wrap:hover .rating_helper_icon {
		background-position:0 -12px
	}
	.rating_helper_wrap:hover .rating_helper_content {
		display:block
	}
	.rating_helper_icon {
		background:url(/f/shire/16305b59f6b69b8acde51c880de2a5b6cde0155a/pics/icon/ic_qmark.png) no-repeat;
		background:-webkit-image-set(url(/f/shire/16305b59f6b69b8acde51c880de2a5b6cde0155a/pics/icon/ic_qmark.png) 1x,url(/f/shire/1fb4f85391f82c3286d7318d840577daae1c2eee/pics/icon/ic_qmark@2x.png) 2x) no-repeat;
		background:-moz-image-set(url(/f/shire/16305b59f6b69b8acde51c880de2a5b6cde0155a/pics/icon/ic_qmark.png) 1x,url(/f/shire/1fb4f85391f82c3286d7318d840577daae1c2eee/pics/icon/ic_qmark@2x.png) 2x) no-repeat;
		background:-o-image-set(url(/f/shire/16305b59f6b69b8acde51c880de2a5b6cde0155a/pics/icon/ic_qmark.png) 1x,url(/f/shire/1fb4f85391f82c3286d7318d840577daae1c2eee/pics/icon/ic_qmark@2x.png) 2x) no-repeat;
		background:-ms-image-set(url(/f/shire/16305b59f6b69b8acde51c880de2a5b6cde0155a/pics/icon/ic_qmark.png) 1x,url(/f/shire/1fb4f85391f82c3286d7318d840577daae1c2eee/pics/icon/ic_qmark@2x.png) 2x) no-repeat;
		display:inline-block;
		*display:inline;
		zoom:1;
		vertical-align:middle;
		width:12px;
		height:12px
	}
	.rating_helper_content {
		z-index:10;
		color:#494949;
		display:none;
		position:absolute;
		left:12px;
		bottom:3px;
		width:96px;
		background:#fef6e9;
		border:1px solid #e3d9ca;
		padding:8px 10px;
		border-radius:4px;
		box-shadow:0 2px 5px rgba(0,0,0,0.1)
	}
	.rating_content_wrap {
		width:110%;
		padding-bottom:8px
	}
	.rating_content_wrap .rating_avg {
		float:left;
		font-size:16px;
		line-height:28px;
		color:#494949;
		margin-right:12px
	}
	.rating_content_wrap .friends {
		float:left;
		margin-right:6px
	}
	.rating_content_wrap .avatar {
		float:left;
		margin-top:6px;
		margin-right:2px;
		line-height:0;
		border-radius:50%;
		overflow:hidden;
		cursor:default
	}
	.rating_content_wrap .avatar img {
		width:16px
	}
	.rating_content_wrap .friends_count {
		float:left;
		line-height:14px;
		margin-top:7px
	}
	#screening .subject-rate {
		color:#e09015;
		font-size:12px;
		margin-left:2px
	}
	#screening .rating {
		display:inline-block;
		*display:inline;
		zoom:1;
		margin:4px auto 2px;
		height:19px
	}
	#screening .rating span {
		float:left
	}
	#screening .rating .rating-star {
		margin:3px 3px 0 0;
		width:55px
	}
	span.subject-rate,.rate,.subject-rating {
		color:#e09015
	}
	img.rating {
		vertical-align:text-bottom
	}
	img.rating:nth-child(1) {
		padding-left:10px
	}
	.rec-list .score {
		color:#e09015
	}
	.album-item .star {
		line-height:1;
		margin-top:6px
	}
	.album-item .star .allstar50,.album-item .star .allstar45,.album-item .star .allstar40,.album-item .star .allstar35,.album-item .star .allstar30,.album-item .star .allstar25,.album-item .star .allstar20,.album-item .star .allstar15,.album-item .star .allstar10,.album-item .star .allstar05,.album-item .star .allstar00 {
		float:left
	}
	.album-item .star .score {
		color:#e09015
	}
	.game-ratings strong {
		margin:0 6px;
		color:#e09015
	}
	.link-subject .rate-more span {
		font-size:10px;
		color:#e09015
	}
	.block_search1 {
		margin-bottom:30px
	}
	.block_search1 .input_basic {
		margin-bottom:10px
	}
	.block_search1 .introduce {
		margin-bottom:-10px
	}
	.srh-suggest {
		line-height:2;
		font-size:14px;
		font-weight:800
	}
	.srh-suggest em {
		color:#f03;
		font-style:normal
	}
	#group_search {
		padding-bottom:5px
	}
	.result-list {
		*position:relative;
		margin-bottom:27px;
		overflow:hidden;
		zoom:1;
		padding-right:3px
	}
	.search-result h2 {
		margin:0;
		color:#000
	}
	h2+.result-list {
		margin-top:-8px
	}
	.result {
		position:relative;
		width:100%;
		zoom:1;
		padding-top:20px;
		margin:-1px 0 17px;
		border-top:1px dashed #ccc
	}
	.result:after {
		content:'\0020';
		clear:both;
		display:block
	}
	.result .pic {
		float:right;
		width:62px;
		text-align:right;
		position:relative
	}
	.result .pic img {
		max-width:48px;
		_width:48px
	}
	.result .content {
		overflow:hidden;
		*zoom:1
	}
	.result .content h3 {
		width:85%;
		height:auto;
		margin:-4px 0 6px 0;
		word-wrap:break-word;
		background:transparent
	}
	.result .content .title {
		margin-bottom:3px;
		color:#5d5d5d
	}
	.result .content p {
		margin:0;
		color:#999;
		line-height:1.5
	}
	.result .info img {
		vertical-align:middle;
		margin-left:1em
	}
	.result .subject-cast {
		margin-left:10px
	}
	.result-list-ft {
		background-color:#f8f8f8
	}
	.result-list-ft a {
		display:block;
		line-height:32px;
		text-align:center
	}
	.result-list-ft a:link,.result-list-ft a:visited {
		color:#333
	}
	.result-list-ft a:hover,.result-list-ft a:active {
		background-color:#f4f4f4;
		color:#333
	}
	.result .ic-mark {
		display:inline-block;
		*display:inline;
		zoom:1;
		margin-left:10px;
		padding:2px 4px;
		line-height:1.2;
		background-color:#40D6FF;
		font-size:12px;
		color:#fff;
		border-radius:3px
	}
	.result .ic-book-mark {
		background-color:#ccc
	}
	.result .ic-music-mark {
		background-color:#fa6a2b
	}
	.result-top {
		padding:30px 40px;
		margin-bottom:20px;
		background-color:#feffdb
	}
	.result-top .result .content {
		padding:0;
		border:none
	}
	.result-top .pic {
		float:right;
		padding:0;
		margin-left:40px
	}
	.result-top .pic img {
		_width:80px;
		max-width:80px;
		max-height:200px
	}
	.result-top .result,.result-top .ul {
		border:none;
		margin-bottom:10px;
		padding:0
	}
	.result-top .result .more {
		text-align:right
	}
	.result-top .result {
		margin:0
	}
	.result-top .user-opt {
		margin-top:10px;
		padding:0
	}
	#db-usr-profile {
		width:100%;
		height:58px;
		margin-bottom:2em;
		position:relative;
		left:0;
		top:0;
		zoom:1
	}
	#db-usr-profile .pic {
		float:left;
		margin-right:12px
	}
	#db-usr-profile .info {
		float:left;
		padding-top:2px
	}
	#db-usr-profile a.colbutt {
		position:absolute;
		left:640px;
		top:35px;
		letter-spacing:0
	}
	#db-usr-profile p.att {
		position:absolute;
		left:640px;
		top:38px;
		margin:0;
		background:url(/f/book/3611ec626fed94c0db6f13472c8171d5a76daca3/pics/allright-small.gif) no-repeat left center;
		padding-left:20px
	}
	#db-usr-profile .info ul li {
		display:inline;
		margin-right:1em
	}
	#db-usr-profile .info ul li.last {
		margin:0
	}
	#db-usr-profile h1 {
		padding:0 0 4px 0
	}
	.action-bar {
		overflow:hidden;
		zoom:1;
		padding-bottom:6px;
		border-bottom:1px solid #ddd;
		margin-bottom:24px;
		margin-top:-15px
	}
	.action-bar .check {
		float:right
	}
	.action-bar .check input {
		vertical-align:initial
	}
	.action-bar .check .user-count {
		color:#aaa
	}
	.title_line .followings_collect {
		margin-left:20px
	}
	.user-verify-icon-1-small {
		background-image:url(/f/book/8433dbee4823538cb4f9360132b78b43d587a4cf/pics/icon/verify/sprite.png);
		background-repeat:no-repeat;
		position:absolute;
		bottom:-4px;
		right:-4px;
		width:14px;
		height:14px;
		background-position:-5px -5px
	}
	@media (-webkit-min-device-pixel-ratio:2),(min-resolution:2dppx),(min-resolution:192dpi) {
		.user-verify-icon-1-small {
		background-image:url(/f/book/2d80c34644bcc53c623f915dbea34bf43979c208/pics/icon/verify/sprite@2x.png);
		background-size:52px 28px
	}
	}.user-verify-icon-1-middle {
		background-image:url(/f/book/8433dbee4823538cb4f9360132b78b43d587a4cf/pics/icon/verify/sprite.png);
		background-repeat:no-repeat;
		position:absolute;
		bottom:-4px;
		right:-4px;
		width:18px;
		height:18px;
		background-position:-29px -5px
	}
	@media (-webkit-min-device-pixel-ratio:2),(min-resolution:2dppx),(min-resolution:192dpi) {
		.user-verify-icon-1-middle {
		background-image:url(/f/book/2d80c34644bcc53c623f915dbea34bf43979c208/pics/icon/verify/sprite@2x.png);
		background-size:52px 28px
	}
	}body {
		margin-top:0
	}
	a:visited,a:hover,a:focus {
		background-color:transparent
	}
	a:link,a:visited,a:focus {
		color:#3377aa
	}
	a:hover {
		background-color:#3377aa;
		color:white
	}
	a.colbutt {
		color:#111
	}
	a.colbutt .minisubmit {
		letter-spacing:3px;
		color:inherit
	}
	a.colbutt .minisubmit:hover {
		color:inherit;
		background-color:inherit
	}
	.miniform .minisubmit {
		outline:none;
		vertical-align:inherit
	}
	h2 {
		color:#111
	}
	.m {
		color:#614e3c
	}
	#db-nav-book .nav-secondary li {
		margin-right:25px
	}
	.nav-secondary .nav-with-media {
		_margin-top:-1px
	}
	.nav-secondary .book-cart {
		position:relative;
		padding-left:18px;
		padding-top:2px;
		_padding-top:0;
		background-image:url(/f/book/c80a9a3b4b77d7f4135b535e4a065adff3a985dc/pics/book/cart/icon_myorders.png);
		background-repeat:no-repeat;
		background-position:left center;
		_background-position:left 2px;
		background-size:15px
	}
	.nav-secondary .book-cart.has-arrival {
		margin-right:48px
	}
	.nav-secondary .book-cart-arrival {
		position:absolute;
		width:40px;
		height:10px;
		top:0;
		right:-40px;
		background:url(/f/book/8792d0a92015d9c6c940c94d8cd259b21a2ce900/pics/icon/cart_coupon_status.gif) no-repeat 0 -10px;
		text-indent:-9999px
	}
	#db-timeline-hd .menu-list .on a {
		background-color:#7f9981
	}
	.rating_list li.on a span,.sort_tabs a.on span,.book-sorting-tab-list .on span,.sorting-tab-list .on span {
		background-image:none
	}
	.rating_list li.on a,.sort_tabs a.on,.book-sorting-tab-list .on,.sorting-tab-list .on {
		background-color:#7f9981;
		background-image:none;
		border-radius:3px;
		-moz-border-radius:3px;
		-webkit-border-radius:3px
	}
	.rec-sec a:hover {
		color:#4f946e
	}
	.nlst,.xbar,.xbar div,.zbar,.zbar div,h3,.nlst h3 {
		background-color:#f6f6f1;
		background-image:none
	}
	.vs-mod h2,.infobox .bd,.gray_ad {
		background-color:#f6f6f1
	}
	.vs-mod {
		margin-bottom:15px
	}
	.vs-mod li {
		border-color:#ececdc
	}
	.book-cart-app-notice .infobox .bd {
		background-color:#fff6ed
	}
	.a_unfolder .bn-arrow,.note-unfolder {
		background:url(/f/book/30d6b18445bb4f47709f1c1ae7b5c7496e5a6fb2/pics/review-expand.png) no-repeat 0 -12px
	}
	.a_folder .bn-arrow,.note-folder {
		background:url(/f/book/30d6b18445bb4f47709f1c1ae7b5c7496e5a6fb2/pics/review-expand.png) no-repeat 0 2px
	}
	a.a_unfolder:hover .bn-arrow,.note-unfolder:hover {
		background:url(/f/book/30d6b18445bb4f47709f1c1ae7b5c7496e5a6fb2/pics/review-expand.png) no-repeat 0 -32px
	}
	a.a_folder:hover .bn-arrow,.note-folder:hover {
		background:url(/f/book/30d6b18445bb4f47709f1c1ae7b5c7496e5a6fb2/pics/review-expand.png) no-repeat 0 -63px
	}
	.note-unfolder,.note-folder {
		display:block;
		width:48px;
		height:19px;
		margin-top:3px;
		text-indent:-9999px;
		*line-height:0
	}
	.note-folder {
		display:none
	}
	body #db-pay-tips {
		top:142px
	}
	.book-express-home {
		background-color:white;
		border-radius:8px;
		-moz-border-radius:8px;
		-webkit-border-radius:8px;
		margin-bottom:10px
	}
	.book-express-home .cover-list {
		width:675px;
		height:172px;
		padding:2px 0px 20px
	}
	.book-express-home .tabs-wrap {
		width:675px;
		margin-bottom:10px
	}
	.book-express-home .cover-list li,.book-express-home .cover-list img {
		width:106px;
		height:150px
	}
	.book-express-home .btn-prev a,.book-express-home .btn-prev a:active,.book-express-home .btn-prev a:hover,.book-express-home .btn-next a,.book-express-home .btn-next a:active,.book-express-home .btn-next a:hover {
		display:block;
		width:18px;
		height:18px;
		margin:2px 0;
		text-indent:-9999px;
		background:url(/f/book/d0673ec17ca46b39d1dc8a616b7b91349c39c01b/pics/book/arrow_in_circle.png) no-repeat 0px 0px
	}
	.book-express-home .btn-prev a:focus,.book-express-home .btn-next a:focus {
		outline:none
	}
	.book-express-home .btn-prev a.dis,.book-express-home .btn-prev a.dis:link,.book-express-home .btn-prev a.dis:visited,.book-express-home .btn-prev a.dis:hover,.book-express-home .btn-prev a.dis:active,.book-express-home .btn-next a.dis,.book-express-home .btn-next a.dis:link,.book-express-home .btn-next a.dis:visited,.book-express-home .btn-next a.dis:hover,.book-express-home .btn-next a.dis:active {
		cursor:default;
		background:url(/f/book/d0673ec17ca46b39d1dc8a616b7b91349c39c01b/pics/book/arrow_in_circle.png) no-repeat 0px -18px
	}
	.book-express-home .btn-next a,.book-express-home .btn-next a:active,.book-express-home .btn-next a:hover {
		background-position:-18px -18px
	}
	.book-express-home .btn-next a.dis,.book-express-home .btn-next a.dis:link,.book-express-home .btn-next a.dis:visited,.book-express-home .btn-next a.dis:hover,.book-express-home .btn-next a.dis:active {
		background-position:-18px 0px
	}
	.book-express-home .switch-dot {
		margin-top:9px
	}
	.book-express-home .switch-dot li {
		background-image:url(/f/book/ed6f41f6556d423c28d1ad79c1b269cfebc5300c/pics/book/dots.png);
		background-position:-7px 0;
		width:6px;
		margin-right:6px
	}
	.book-express-home .switch-dot li.current {
		background-image:url(/f/book/ed6f41f6556d423c28d1ad79c1b269cfebc5300c/pics/book/dots.png);
		background-position:0 0
	}
	h2.green_tab a.on,h2.green_tab a.on span,.sort_tabs a.on,.sort_tabs a.on span {
		background:none;
		background-color:#9b9a8f;
		border-radius:3px;
		-moz-border-radius:3px;
		-weibkit-border-radius:3px
	}
	.entry-list-col2 h2,.entry-list-col1 .info h2 {
		font-size:14px
	}
	.bs.more-after {
		margin-bottom:10px
	}
	.review-panel {
		padding-top:10px
	}
	.ilst,.ctsh .ilst {
		width:auto
	}
	.ilst {
		margin:0 30px 0 0
	}
	.ctsh .ilst {
		margin:0 10px 0 0
	}
	.nlst,.ctsh .nlst {
		margin:0;
		padding:0;
		overflow:hidden;
		zoom:1
	}
	.clst,.ctsh .clst {
		padding:0 0 0 4px;
		float:none !important;
		width:auto;
		zoom:1;
		overflow:hidden !important
	}
	.clst .user {
		margin:6px 0;
		color:#666
	}
	.gray_ad {
		padding-bottom:6px
	}
	.gray_ad .ft {
		border-top:1px dashed #ddd;
		padding-top:8px
	}
	.gray_ad .ft.no-border {
		border-top:0 none;
		padding-top:0
	}
	.inline-tabs {
		border-bottom:1px solid #ccc;
		margin:10px 0 15px
	}
	.inline-tabs li {
		display:inline-block;
		*display:inline;
		*zoom:1;
		margin-right:10px;
		padding:4px 0;
		position:relative;
		top:1px
	}
	.inline-tabs li a:link,.inline-tabs li a:visited,.inline-tabs li a:focus {
		color:#666;
		padding:0 1px
	}
	.inline-tabs li a:hover {
		color:#fff;
		background-color:#666
	}
	.inline-tabs li.on {
		border-bottom:2px solid #336699
	}
	.inline-tabs li.on a:link,.inline-tabs li.on a:visited,.inline-tabs li.on a:focus,.inline-tabs li.on a:hover {
		color:#336699;
		background-color:transparent
	}
	.reading-notes .comments li {
		margin:10px 0
	}
	.reading-notes .comments .pic {
		float:left
	}
	.reading-notes .comments .con .reading-note {
		overflow:hidden
	}
	.reading-notes .comments .con .no-comments {
		display:none
	}
	.reading-notes .comments .con .col-rec-con {
		line-height:25px;
		margin-top:20px
	}
	.reading-notes .comments .con .col-time {
		margin:6px 0;
		padding:6px 0;
		border-top:1px dashed #ddd
	}
	.reading-notes .comments .bd h2 {
		margin:0
	}
	.reading-notes .comments .ft p {
		text-align:right
	}
	.reading-notes .comments .rec-sec {
		float:right
	}
	.reading-notes .comments .short .ll {
		padding:0 10px 10px 0
	}
	.code-holder {
		color:#072
	}
	#footer {
		padding-bottom:10px
	}
	@media (-webkit-min-device-pixel-ratio:2),(min-resolution:192dpi) {
		.nav-secondary .book-cart {
		background-image:url(/f/book/67509c2864532f3f092e8174959fd49c69ceb5d6/pics/book/cart/icon_myorders@2x.png)
	}
} */
</style>