<template>
  <div class="container">
    <div class="lby_h1">山海经</div>
    <div class="row">
      <!-- 左边 -->
      <div class="lby_l col-md-8">
        <!-- 左边最上层-->
        <div class="lby_l_zsc">
          <!-- 上层最上面部分-->
          <div class="lby_l_top">
            <!-- 最上面左边部分-->
            <div class="lby_l_topl d-flex">
              <!--l-->
              <div class="lby_l_l mr-3">
                <a href="javascript:;">
                  <img src="../../img/1.jpg" alt style="width: 135px;max-height: 200px;">
                </a>
              </div>
              <!--r-->
              <div class="lby_l_r">
                <span class="lby_pl">出版社:</span> 浙江教育出版社
                <br>
                <span class="lby_pl">副标题:</span> 全译插图典藏版
                <br>
                <span class="lby_pl">译者:
                  <a class href="javascript:;">小岩井</a>
                </span>
                <br>
                <span class="lby_pl">出版年:</span> 2019-1-15
                <br>
                <span class="lby_pl">页数:</span> 488
                <br>
                <span class="lby_pl">定价:</span> 65
                <br>
                <span class="lby_pl">装帧:</span> 线装
                <br>
                <span class="lby_pl">ISBN:</span> 9787553679372
                <br>
              </div>
              <div class="lby_zwf"></div>
              <div class="lby_l_topr">
                <div>
                  <div class="rating_logo">豆瓣评分</div>
                  <span class>
                    <a href>评价人数不足</a>
                  </span>
                </div>
              </div>
            </div>
            <!-- 下一层-->
            <div class="clearfix"></div>
            <div class="lby_x_pl">
              <a href class="lby_x_pl_a">想读</a>
              <a href class="lby_x_pl_a">在读</a>
              <a href class="lby_x_pl_a">读过</a>
              <span>评价:</span>
            </div>
            <div class="lby_x_plx">
              <ul class="list-unstyled d-flex float-left">
                <li class="mr-3">
                  <a href="#" class="lby_x_plx_a">写笔记</a>
                </li>
                <li class="mr-3">
                  <a href="#" class="lby_x_plx_a">写书评</a>
                </li>
                <li class="mr-3">
                  <a href="#" class="lby_x_plx_a">加入购书单</a>
                </li>
                <li class="mr-3">
                  <a href="#" class="lby_x_plx_a">分享到</a>
                </li>
              </ul>
              <span class="float-right lby_x_plx_sp">
                <a href="#">推荐</a>
              </span>
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="lby_h2">内容简介 · · · · · ·</div>
          <div class="lby_jj">
            <div>
              <p
                class="lby_jj_p"
              >《山海经》是一部记述中国古代志怪的奇书。该书作者不详，大体是战国中后期到汉代初中期的楚国或巴蜀人所作。《山海经》是地理方志也是神话故事集，书中涉及地理、动物、植物、矿物、巫术、宗教、医药、民族等方面，并保存了夸父逐日、女娲补天、精卫填海等远古神话和寓言故事，包罗万象，多彩纷呈。《山海经》充满着神奇色彩，又饱含中国古代人文、自然知识，是古今众多名家推崇的国学必读书。</p>
              <p
                class="lby_jj_p"
              >知名青年作家小岩井以清代郝懿行《山海经笺疏》为底本，参考郭璞、袁珂等人的校译版本进行全新译注，翻译通俗易懂，注释规范简洁，并对原文生僻字做了汉音标注。本书图文结合，在参考几百幅古版插画基础上全新绘制异兽图鉴，充分展现东方鬼怪之美，更适合当下年轻人阅读。</p>
              <p
                class="lby_jj_p"
              >★《山海经》是一部充满神奇色彩的中国古代经典著作，既是人文、自然地理的知识宝库，又是中国神话寓言的集大成之作，深受古今众多名家如司马迁、陶渊明、鲁迅、贾平凹等的推崇。鲁迅在回忆童年的《阿长与&lt;山海经&gt;》一文中，把绘图的《山海经》称为“最为心爱的宝书”。</p>
              <p
                class="lby_jj_p"
              >★知名青年作家小岩井译注版本，分为原文、注释、译文、插图四部分，精校原文，精简注释、逐句直译，通俗易懂，更适合年轻人阅读。全彩插图，插画师日月引在参考几百幅古版插画基础上全新绘制，画风传神，复原上古神奇异兽风貌。</p>
              <p class="lby_jj_p">★全彩精美印刷，封面正背印制，背面为神兽狐凰海报，裸书脊线装，附赠神兽明信片，极佳阅读体验</p>
            </div>
          </div>
          <div class="lby_kk">
            <router-link to="/yd" class="lby_kk_a">在线阅读&gt;</router-link>
            <span class="lby_kk_sp">前往豆瓣阅读试读本书</span>
          </div>
          <div class="lby_h2">作者简介 · · · · · ·</div>
          <div class="lby_doctor">
            <p class="lby_jj_p">译者： 小岩井。翻译，作家。平生三好：猫，酒，书。</p>
            <p class="lby_jj_p">插图： 日月引。90后自由插画师，致力于东方鬼怪美学。</p>
          </div>
          <div class="lby_h2">目录 · · · · · ·</div>
          <div class="lby_ml">
            <div class="lby_ml_xs">
              <p class="lby_jj_p">南山经</p>
              <p class="lby_jj_p">西山经</p>
              <p class="lby_jj_p">北山经</p>
              <p class="lby_jj_p">东山经</p>
              <p class="lby_jj_p">中山经</p>
              <p class="lby_jj_p">海外南山经</p>
              <p class="lby_jj_p" v-show="aa" @click="dis" id="lby_jj_p">· · · · · (
                <a href="javascript:;">更多</a>)
              </p>
            </div>
            <div v-show="bb" class="lby_ml_yc" id="lby_ml_yc">
              <span class="lby_jj_p">海外西经</span><br>
              <span class="lby_jj_p">海外北经</span><br>
              <span class="lby_jj_p">海外东经</span><br>
              <span class="lby_jj_p">海内南经</span><br>
              <span class="lby_jj_p">海内西经</span><br>
              <span class="lby_jj_p">海内北经</span><br>
              <span class="lby_jj_p">海内东经</span><br>
              <span class="lby_jj_p">大荒东经</span><br>
              <span class="lby_jj_p">大荒南经</span><br>
              <span class="lby_jj_p">大荒西经</span><br>
              <span class="lby_jj_p">大荒北经</span><br>
              <span class="lby_jj_p">海内经</span><br>
              <p class="lby_jj_p" @click="shouqi">· · · · · (
                <a href="javascript:;">收起</a>)
              </p>
            </div>
          </div>
          <div class="lby_h2">豆瓣成员常用的标签(共10个) · · · · · ·</div>
          <div class="lby_bq">
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">古代</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">奇幻</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">经典</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">神兽</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">山海经</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">图鉴</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">文学</a>
            </span>
            <span class="mr-3">
              <a href="javascript:;" class="lby_bq_a">中国</a>
            </span>
          </div>
          <div class="lby_h2">喜欢读"山海经"的人也喜欢的电子书 · · · · · ·</div>
          <div class="mb-3">支持 Web、iPhone、iPad、Android 阅读器</div>
          <div class="lby_dzs">
            <div class="lby_dzs_s float-left mr-4 mb-4"  v-for="(item,i) of list" :key="i">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img :src="item.img_url">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">{{item.book_name}}</a>
              </div>
              <div class="text-center">￥{{item.price.toFixed(2)}}元</div>
              <div class="btn btn-danger" :data-pid="i" @click="addcart">加入购物车</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="lby_h2">喜欢读"山海经"的人也喜欢 · · · · · ·</div>
          <div class="lby_dzs">
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/12.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">鱼王</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/13.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">梦的化石</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/14.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">神经漫游者</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/2.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">人鼠之间</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/3.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">鱼王</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/7.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">大明</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/8.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">人鼠之间</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/9.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">山海经</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/10.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">人鼠之间</a>
              </div>
            </div>
            <div class="lby_dzs_s float-left mr-4 mb-4">
              <span class="lby_dzs_s_sp">
                <a href="javascript:;">
                  <img src="../../img/11.jpg">
                </a>
              </span>
              <div class="text-center">
                <a href="javascript:;">当下的启蒙</a>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div></div>
          <div class="lby_h2">
            我来说两句短评 · · · · · ·
            <span>(
              <a href="javascript:;">全部5条</a>)
            </span>
            <a href="javascript:;" class="lby_h2_a float-right">
              <span class="lby_h2_sp">我来说两句</span>
            </a>
          </div>
          <div>
            <a href="javascript:;">热门</a>
            <span>/</span>
            <a href="javascript:;">最新</a>
            <span>/</span>
            <a href="javascript:;">好友</a>
          </div>
          <hr>
          <div>
            <div class="lby_dp_pl">
              <a href="javascript:;" class="mr-3">闲云野鹤</a>
              <span>2019-1-21</span>
              <span class="float-right">1
                <a href="javascript:;">有用</a>
              </span>
              <p class="lby_dp_pl_p">书是不错的，扣一分给印刷，味太呛了。</p>
            </div>
            <hr>
            <div class="lby_dp_pl">
              <a href="javascript:;" class="mr-3">TOM</a>
              <span>2019-1-20</span>
              <span class="float-right">1
                <a href="javascript:;">有用</a>
              </span>
              <p class="lby_dp_pl_p">非常喜欢的古代经典，小岩井也是我很喜欢的年轻译者，翻译风格简洁、适合年轻人读。对这本书的插画也非常满意，感觉很酷。设计的也很好</p>
            </div>
            <hr>
            <div class="lby_dp_pl">
              <a href="javascript:;" class="mr-3">GOOD</a>
              <span>2019-1-19</span>
              <span class="float-right">0
                <a href="javascript:;">有用</a>
              </span>
              <p class="lby_dp_pl_p">可以看一下，很多东西都是地球上有的生物，只是名字被神化了</p>
            </div>
            <hr>
            <div class="lby_dp_pl">
              <a href="javascript:;" class="mr-3">LINK</a>
              <span>2019-1-18</span>
              <span class="float-right">0
                <a href="javascript:;">有用</a>
              </span>
              <p class="lby_dp_pl_p">充分展现东方鬼怪之美，更适合当下年轻人阅读。</p>
            </div>
          </div>
          <p>&gt;
            <a href="javascript:;">更多短评 5 条</a>
          </p>
        </div>
        <div class="lby_h2">
          山海经的书评 · · · · · ·
          <span>(
            <a href="javascript:;">全部0条</a>)
          </span>
          <a href="javascript:;" class="lby_h2_a float-right mb-2">
            <span class="lby_h2_sp">我来说两句</span>
          </a>
          <div class="clearfix"></div>
          <a href="javascript:;" class="lby_h2_a float-right">
            <span class="lby_h2_sp">在这本书的评论里发言</span>
          </a>
        </div>
      </div>
      <!--右边-->
      <div class="lby_r col-md-4">
        <div class="lby_r_f">
          <div>
            <div class="lby_h2">电子版有售 · · · · · ·</div>
            <a href="javascript:;" class="mr-5">豆瓣阅读</a>
            <a href="javascript:;">￥24.00元</a>
          </div>
          <div>
            <div class="lby_h2">在哪儿买这本书 · · · · · ·</div>
            <a href="javascript:;" class="mr-5">京东商城</a>
            <a href="javascript:;">￥43.00元</a>
          </div>
          <hr>
          <p>
            <a href="javascript:;">&gt;查看1家网店价格 (46.30 元起)</a>
          </p>
          <p>
            <a href="javascript:;">+ 加入购书单</a>
          </p>
        </div>
        <div class="lby_h2 mb-3">
          以下豆列推荐 · · · · · ·
          <span>(
            <a href="javascript:;">全部</a>)
          </span>
        </div>
        <div class="mb-5">
          <ul class="list-unstyled">
            <li class="lby_tj_bk">
              <a href="javascript:;">我的身体里有一个游荡的未来</a>(诗菡)
            </li>
            <li class="lby_tj_bk">
              <a href="javascript:;">那么开始封面党收集</a> (AOI)
            </li>
            <li class="lby_tj_bk">
              <a href="javascript:;">待购之书3</a>(琬琰斋)
            </li>
            <li class="lby_tj_bk">
              <a href="javascript:;">古人的心意</a> (琥珀千秋)
            </li>
            <li class="lby_tj_bk">
              <a href="javascript:;">眼睛</a> (Apple)
            </li>
          </ul>
        </div>
        <div class="lby_blk d-flex">
          <a href="javascript:;">
            <img src="../../img/18.jpg" class="lby_blk_img">
          </a>
          <div class="ml-3">
            <p class="mt-3">
              <a href="javascript:;" class="lby_blk_a">拥抱青春的气息</a>
            </p>
            <p class="lby_blk_p">豆瓣书店</p>
          </div>
        </div>
        <div class="lby_h2 mb-4">谁读这本书?</div>
        <div class="d-flex lby_xd mb-3">
          <div class="mb-4">
            <a href="javascript:;">
              <img src="../../img/15.jpg">
            </a>
          </div>
          <div class="ml-3">
            <a href="javascript:;">西子 ちゃん</a>
            <br>
            <div class="mt-2">5分钟前 想读</div>
          </div>
        </div>
        <div class="d-flex lby_xd mb-3">
          <div class="mb-4">
            <a href="javascript:;">
              <img src="../../img/16.jpg">
            </a>
          </div>
          <div class="ml-3">
            <a href="javascript:;">Summer</a>
            <br>
            <div class="mt-2">一个小时前 想读</div>
          </div>
        </div>
        <div class="d-flex lby_xd mb-3">
          <div class="mb-4">
            <a href="javascript:;">
              <img src="../../img/17.jpg">
            </a>
          </div>
          <div class="ml-3">
            <a href="javascript:;">电影死宅</a>
            <br>
            <div class="mt-2">一个小时前 想读</div>
          </div>
        </div>
        <div class="d-flex lby_xd mb-3">
          <div class="mb-4">
            <a href="javascript:;">
              <img src="../../img/18.jpg">
            </a>
          </div>
          <div class="ml-3">
            <a href="javascript:;">老曾照相馆</a>
            <br>
            <div class="mt-2">一个小时前 想读</div>
          </div>
        </div>
        <p>&gt;
          <a href="javascript:;">17人想读</a>
        </p>
        <p>&gt;
          <a href="javascript:;">20人读过</a>
        </p>
        <p>&gt;
          <a href="javascript:;">319人想读</a>
        </p>
        <div class="lby_h2 mb-3">二手市场</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
        list:[],
        aa:true,
        bb:false,
    };
  },
  methods: {
      dis(){
          this.aa=false;
          this.bb=true;
      },
      shouqi(){
          this.bb=false;
          this.aa=true;
      },
      getdoubanlist(){ 
      // 1:发送ajax请求给服务器
      // 2：接收服务器返回的结果
      // 3：将结果保存list
      var url="http://127.0.0.1:3000/findProduct";
      this.axios.get(url).then(result=>{
        this.list=result.data.data;
        // console.log(result.data.data);
      })
    }, 
    addcart(e){
      var i=e.target.dataset.pid;
      // console.log(this.list[i].book_name)
      var pid=this.list[i].pid;
      var price=this.list[i].price;
      var uid=1;
      var count=1;
      var book_name=this.list[i].book_name;
      console.log(price,book_name,pid)
      // var count=this.list[i].count;
      // console.log(price)
      // console.log(pid)
      // console.log(list)
      var url=`http://127.0.0.1:3000/addcart?book_name=${book_name}&price=${price}&count=${count}&uid=${uid}&pid=${pid}`;
      this.axios.get(url).then(result=>{
        console.log(result);
        if(result.data.code==1){
          alert("添加成功");
        }else{
          alert("添加失败")
        }
      })
    }
  },
  created() {
    this.getdoubanlist();
    pid:this.$route.query.pid;
    
  }
};
</script>
<style>
body {
  font-size: 13px;
}
.container {
  text-align: left;
}
/*������divɽ����*/
.lby_h1 {
  font-size: 26px;
  font-weight: bold;
  color: #494949;
  margin: 0;
  padding: 0 0 15px 0;
  line-height: 1.1;
}

/*������߿���*/
.lby_l_l {
  float: left;
}
.lby_l_r {
  float: left;
  max-width: 333px;
}
/*span����*/
.lby_pl {
  font: 12px Helvetica, Arial, sans-serif;
  line-height: 1.62;
  color: #111;
}
.lby_zwf {
  width: 200px;
}
/*�����ұ߿���*/
.lby_l_topr {
  display: inline-block;
  width: 155px;
  height: 50px;
  margin: 2px 0 0 0;
  padding: 0 0 0 15px;
  border-left: 1px solid #eaeaea;
  color: #9b9b9b;
}
.lby_x_pl {
  padding-top: 20px;
  padding-bottom: 20px;
}
.lby_x_pl_a {
  color: #777;
  text-decoration: none;
  height: 24px;
  padding: 3px 11px 3px 11px;
  font-size: 13px;
  border: lavenderblush;
  border-radius: 3px;
  background: linen;
  margin-right: 10px;
}
.lby_x_plx_a {
  color: #666699;
}
.lby_x_plx_sp a {
  text-decoration: none;
  border: 1px solid #e3f1ed;
  background-color: #f2f8f2;
  color: #4f946e;
  padding: 1px 5px 2px 5px;
}
.lby_x_plx_sp a:hover {
  border-color: palegreen;
}
.lby_h2 {
  font-size: 16px;
  color: #007722;
  margin-top: 26px;
  margin-bottom: 6px;
}

.lby_jj_p {
  text-indent: 2em;
  margin-bottom: 2px;
  margin-top: 2px;
}
.lby_kk_a {
  border-radius: 4px;
  background-color: #83be73;
  display: inline-block;
  margin-right: 10px;
  padding: 3px 5px 3px 27px;
  color: #fff;
}
.lby_kk_a:hover {
  text-decoration: none;
  color: #fff;
}
.lby_kk_sp {
  color: #999;
  font-size: 12px;
}
.lby_bq_a {
  width: auto;
  word-break: keep-all;
  white-space: nowrap;
  background-color: #f5f5f5;
  color: #37a;
  font-size: 13px;
  padding: 2px 11px 0;
  display: inline-block;
  margin: 0 3px 5px 0;
  line-height: 20px;
}
.lby_dzs_s_sp img {
  width: 115px;
  height: 172px;
}
.lby_h2_a {
  color: #c65e24;
  background: rgba(198, 94, 36, 0.15);
  padding: 7px 12px;
  line-height: 13px;
  border-radius: 2px;
  height: auto;
  margin-right: 40px;
}
.lby_h2_a:hover {
  text-decoration: none;
  color: #c65e24;
}
.lby_h2_sp {
  color: inherit;
  font-size: 13px;
}
.lby_dp_pl_p {
  color: #666;
  font-size: 13px;
  margin-top: 5px;
  margin-bottom: 15px;
}
.lby_r_f {
  padding: 30px 20px 25px 20px;
  background: #f6f6f1;
}
.lby_tj_bk {
  border-bottom: 1px dashed #ddd;
  margin: 0;
  padding: 4px 0;
}
.lby_blk {
  padding: 10px;
  background-color: #f9f9f9;
}
.lby_blk_img {
  width: 96px;
  height: 80px;
}
.lby_blk_a {
  color: #37a;
}
.lby_blk_a:hover {
  text-decoration: none;
}
.lby_blk_p {
  font-size: 12px;
  line-height: 1;
  color: #999;
}
.lby_xd {
  border-bottom: 1px dashed #c6c8ca;
}
.lby_ml_yc{
   margin-left: 32px;
}
</style>