<template>
    <div class="lby_div container">
        <div class="lby_1 d-flex mt-5">
            <input type="checkbox" class="mr-2" @click="selAll" :checked="allcb">
            <span>全选</span>
            <span class="lby_sp">商品信息</span>
            <span class="lby_sp">数量</span>
            <span class="lby_sp">金额</span>
            <span class="lby_sp">操作</span>
        </div>
        <div class="lby_2 d-flex mt-5">
            <ul>
                <li class="d-flex lby_li mb-4" v-for="(item,i) of list" :key="item.id" >
                <input type="checkbox" class="mr-5" :checked="item.cb" :data-i="i" @click="selone" >
                <span class="lby_sp1">{{item.book_name}}</span>
                <div class="amount_box lby_sp2">
                    <a href="javascript:;" class="reduce reSty"  @click="goodSub" :data-i="i">－</a>
                    <input type="text" v-model=item.count  class="sum ml-2 mr-2" >
                    <a href="javascript:;" class="plus"  @click="goodAdd" :data-count="item.count" :data-i="i">＋</a>
                </div>
                <span class="lby_sp3">￥{{item.count*item.price}}</span>
                <span class="lby_sp4 btn btn-info"  @click="delitem" :data-id="item.id" :data-idx="i">删除</span>
                </li>
            </ul>
        </div>
        <div class="lby_del mb-5">
            <b class="btn btn-info" @click="removeItem">删除选中的商品</b>
        </div>
          
        <div class="bar-wrapper">
            <div class="bar-right">
                <div class="totalMoney">共计: <strong class="total_text">￥{{allprice}}</strong></div>
                <div class="calBtn"><a href="javascript:;">结算</a></div>
            </div>
        </div>
    </div>
   
</template>
<script>
export default {
  data() {
    return {
        list:[],
        ids:[],
        cb:false,
        allcb:false,
        allprice:0,
    };
  },
    methods: {
        loadmore(){
            var url="http://127.0.0.1:3000/cartlist";
            this.axios.get(url).then(result=>{
                var row=result.data.data;                   
                for (var item of row){
                    item.cb=false;
                    this.allprice+=item.price*item.count
                }
                this.list=row;
            })
        },
        selAll(e){
           var cb=e.target.checked;
           this.allcb=cb;
           for (var item of this.list){
               item.cb=cb;
           }
        //    console.log(cb)
        },
        selone(e){ 
            var idx = e.target.dataset.i;
            var checked = e.target.checked;
            this.list[idx].cb = checked;
            var count=0;
            for (var item of this.list){
                if(item.cb){
                    count++
                  
                }
            }
            if(count==this.list.length){
                this.allcb = true;
            }else{
                this.allcb = false;
            }
        },
        delitem(e){
            var id=e.target.dataset.id;
            var i=e.target.dataset.idx;
            var url="http://127.0.0.1:3000/delCratItem?id="+id;
            this.axios.get(url).then(res=>{
                alert(res.data.msg);
                this.list.splice(i,1);
            })
        },
        removeItem(){
            var html="";
            for(var item of this.list){
                if(item.cb){
                    html+=item.id+",";
                }
            }
            html = html.substring(0,html.length-1);
            // console.log(html)
            var url = "http://127.0.0.1:3000/";
            url+="delsItem?ids="+html;
            this.axios.get(url).then(result=>{
            if(result.data.code == 1){
              alert("删除成功");
              this.loadmore();
            } 
            });
        } , 
        goodAdd(e){
            var i=e.target.dataset.i;
            this.list[i].count++;
            this.allprice+=this.list[i].price
        },
        goodSub(e){
            var i=e.target.dataset.i;
            if(this.list[i].count > 1){
                this.list[i].count--; 
                this.allprice-=this.list[i].price
            }
        },
    },
    created() {
        this.loadmore();
    }
};
</script>
<style>
*{margin: 0;padding: 0;}
.lby_sp{
    margin-left: 11%;
}
.lby_sp1{
    margin-left: 9%;
    width:110px;
    text-align: left
}
.lby_sp2{
    margin-left: 10px;
    width:150px;
    text-align: center
}
.lby_sp3{
    width:140px;
    text-align: center
}
.lby_sp4{
    width:150px;
    text-align: center
}
.lby_del{
    margin-left: 60px;
}
.lby_li{
    width:1100px;
}
.lby_1{
    text-align: center;
    margin-left:8%;
}
.lby_2{
    margin-left:5%;
    margin-bottom: 2%;
    width:75%;
    border:1px solid #ddd;
    padding: 3% 3% 0 3%;

}

.plus{
    padding: 4px;
    border: 1px solid #dddddd;
}
.reduce{
    padding: 4px;
    border: 1px solid #dddddd;
}
.sum{
    width:35px;
    text-align: center
}
.bar-wrapper{
    margin-left: 5%;
    width: 800px;
    height: 50px;
    /* position: fixed; */
    bottom: -1px;
    z-index: 99;
    background: #e5e5e5;
}
.bar-wrapper .bar-right{
    float: right;
    color: #3c3c3c;
}
.bar-wrapper .bar-right strong{
    color: #f40;
}

.bar-wrapper .bar-right .piece{
    float: left;
    min-width: 110px;
    margin-right: 20px;
    height: 50px;
    line-height: 50px;
}
.bar-wrapper .bar-right .piece .piece_num{
    display: inline-block;
    padding: 0 10px;
    font-weight: 700;
    font-size: 18px;
    font-family: tohoma,arial;
}
.bar-wrapper .bar-right .totalMoney{
    float: left;
    min-width: 100px;
    height: 50px;
    line-height: 50px;
}
.bar-wrapper .bar-right .totalMoney .total_text{
    float: right;
    font-weight: 400;
    font-size: 20px;
    font-family: Arial;
    vertical-align: middle;
    margin-right: 10px;
    margin-left: 15px;
}
.bar-wrapper .bar-right .calBtn{
    float: left;
}
.bar-wrapper .bar-right .calBtn a{
    display: block;
    width: 120px;
    height: 50px;
    color: #fff;
    background: #B0B0B0;
    font-size: 22px;
    letter-spacing: 5px;
    text-decoration: none;
    line-height: 50px;
    text-align: center;
    border-radius: 2px;
}
.bar-wrapper .bar-right .calBtn a.btn_sty{
    background: #f40;
    /* cursor: pointer; */
}
</style>