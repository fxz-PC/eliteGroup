<template>
  <div class="container-fluid">
    <div class="mt-2 ml-2 float-left">
      <ul class="list-unstyled lby_width">
        <li class="iconfont icon-yuedujilu lby_xhx" title="阅读"></li>
        <li class="iconfont icon-pinglun lby_xhx" title="评论"></li>
        <li class="iconfont icon-zhushi lby_xhx" title="批注"></li>
        <li class="iconfont icon-search lby_xhx" title="搜索"></li>
        <li title="指南">
          <a href="javascript:;" class="lby_zn">指南</a>
        </li>
      </ul>
    </div>

    <div class="lby_right float-left">
      <!-- 第一页-->
      <div class="lby_zw" v-show="aa">
        <h1 class="mt-5">山海经</h1>
        <h5 class="mb-5">全译插图典藏版</h5>
        <div class="mb-5">
          <div class="lby_font">作者：小岩井 译注</div>
          <div class="lby_font">出版方：浙江教育出版社</div>
        </div>
        <div class="lby_font1">本作品由 磨铁数盟 授权豆瓣阅读全球范围内电子版制作与发行。
          <br>© 版权所有，侵权必究。
        </div>
      </div>
      <div class="lby_zw" v-show="bb">
        <div class="lby_zw_top d-flex">
          <p class="lby_zw_topl">南山经</p>
          <p class="lby_zw_topll">全本定价 ￥24.00元</p>
          <div class="lby_btn">购买</div>
        </div>
        <hr>
        <h3 class="mb-5">南山经</h3>
        <h5 class="mb-5 lby_zw_bt">南山经</h5>
        <div class="mb-3">䧿山与招摇山</div>
        <div class="mb-1">【原文】</div>
        <div class="lby_yw mb-1">南山之首曰䧿山。其首曰招摇之山，临于西海之上，多桂，多金玉。有草焉，其状如韭而青华{①}，其名曰祝馀，食之不饥。有木焉，其状如榖而黑理，其华四照，其名曰迷榖{②}，佩之不迷。有兽焉，其状如禺{③}而白耳，伏行人走，其名曰狌狌{④}，食之善走。丽𪊨{⑤}之水出焉，而西流注于海，其中多育沛，佩之无瘕疾{⑥}。</div>
        <div class="mb-1">【注释】</div>
        <div class="lby_yw mb-1">①青华：“华”通“花”，青色的花。</div>
        <div class="lby_yw mb-1">②榖（gǔ）：构树，落叶乔木，花绿果红，树皮是中国古代造纸原料。也称楮（chǔ）。这里的迷榖是树名。</div>
        <div class="lby_yw mb-1">③禺（yù）：古代传说中的一种猴。形似猕猴，有红色的眼睛、长长的尾巴。</div>
        <div class="lby_yw mb-1">④狌狌（xīng xīng）：即猩 […]</div>
        <div>
          <br>
        </div>
      </div>
      <!-- 目录-->
    </div>
    <div class="ml-3 float-left mt-2">
      <ul class="list-unstyled lby_width">
        <li class="iconfont icon-shejimulu" title="目录"></li>
        <li class="iconfont icon-shuqianbookmarks" title="我的书签"></li>
        <li class="iconfont icon-yuedu mb-3" title="批注和划线"></li>
        <li class="iconfont icon-sanjiaoleft lby_jt" @click="up"></li>
        <li class="iconfont icon-youjiantou lby_jt" @click="down"></li>
      </ul>
    </div>
    <div style="clear:both"></div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      aa: true,
      bb: false
    };
  },
  methods: {
    up() {
      this.aa = true;
      this.bb = false;
    },
    down() {
      this.aa = false;
      this.bb = true;
    }
  },
  created() {}
};
</script>
<style>
body {
  background: #e5e4db;
  font-size: 16px;
}
.lby_width {
  width: 30px;
  display: inline-block;
  text-align: center;
}
.lby_xhx {
  border-bottom: 1px solid #c6c8ca;
  padding: 5px;
  text-align: center;
}
.lby_zn {
  width: 22px;
  font-size: 12px;
  line-height: 1.4;
  padding: 7px 0 5px;
  background: #cecdc5;
  color: #eeede5;
  margin-left: 2px;
  margin-top: 5px;
  display: block;
}
.lby_zn:hover {
  color: #eeede5;
  text-decoration: none;
}

.lby_right {
  margin-left: 30%;
  height: 850px;
}
.lby_zw {
  background: #f6f4ec;
  height: 860px;
  width: 600px;
  padding: 80px 75px 40px 75px;
  margin: 0;
  cursor: default;
}
.lby_font {
  font-size: 14px;
}
.lby_font1 {
  font-size: 12px;
}
.lby_width .icon-shejimulu {
  font-size: 14px;
}
.lby_width > .icon-shuqianbookmarks {
  color: #b2b4b4;
  font-size: 23px;
}
.lby_width > .icon-yuedu {
  color: #b2b4b4;
  font-size: 22px;
}
.lby_width > .icon-sanjiaoleft {
  color: #e2e6ea;
}
.lby_width > .icon-youjiantou {
  color: #e2e6ea;
}
.lby_jt {
  width: 1.5625em;
  height: 5.4375em;
  cursor: pointer;
  line-height: 5.4375em;
  margin-bottom: 0.125em;
  text-align: center;
  background: #cecdc5;
}
.lby_jt:hover {
  color: #d5e4db;
  background: #d5d4cc;
}
.lby_zw_topl {
  color: #855b5b;
  text-align: left;
  font-size: 15px;
}
.lby_zw_topll {
  margin-left: 40%;
}
.lby_btn {
  display: inline-block;
  margin-left: 10px;
  background: #77a4b3;
  color: #fff;
  font-size: 13px;
  height: 32px;
  line-height: 32px;
  padding: 0 16px;
  border: none;
  border-radius: 2px;
}
.lby_zw_bt {
  text-align: left;
}
.lby_yw{
    text-align: left
}
</style>