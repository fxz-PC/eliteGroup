<template>
  <div class="content">
    <div class="lby_login">
      <div class="lby_zl" v-show="lbys">
        <div class="lby_top mb-5">          
          <a href="javascript:;" class="login" @click="up">
            <span class="lby_gs">注册</span>
          </a>
          <a href="javascript:;"  class="login" @click="down">
            <span class="lby_gs">登录</span>
          </a>
        </div>
        <div class="lby_middle mb-4">
          <span>登录注册表示同意</span>
          <a href="javascript:;" class="lby_m">
            <span>豆瓣使用协议、隐式政策</span>
          </a>
        </div>
        <div class="lby_zl_1 mb-5">
        	<input type="text" name="uname"  v-model="uname" @blur="checkName"  placeholder="请输入用户名" >
          <p id="lbyp1"></p>
          <br>
        	<input type="password"  v-model="upwd"  placeholder="请输入密码" name="upwd">
          <p  id="lbyp2"></p>
        </div>
        <div class="lby_ljzc">
            <a href="javascript:;" class="lby_a"  > 
              <span>立即注册</span> 
            </a>
        </div>
      </div>
      <div class="lby_lr" v-show="lbyc">
        <div class="lby_top mb-5">          
          <a href="javascript:;"  class="login" @click="down">
            <span class="lby_gs">登录</span>
          </a>
        </div>
        <div class="lby_dl">
          <input type="text" name="uname"  placeholder="请输入用户名" >
          <p></p><br>
          <input type="password" placeholder="输入密码" name="uname">
          <p></p><br>
        </div>
        <div class="lby_ljzc1">
            <a href="javascript:;" class="lby_a"  @click.prevent="Login">
              <span class="lby_gs">立即登录</span> 
            </a>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
   data() {
    return {
      lbys: true,
      lbyc: false,
      uname:"",
      upwd:"",
      isSubmit:false,
    };
  },
  methods: {
    up() {
      this.lbys = true;
      this.lbyc = false;
  
    },
    down() {
      this.lbys = false;
      this.lbyc = true;
    },
    // 注册
    checkName(){
      var n=this.uname;
      var url="http://127.0.0.1:3000/existsName?uname="+n;
      this.axios.get(url).then(result=>{
        if(result.data.code>0){
          document.getElementById("lbyp1").innerHTML="用户名可用"; 
          this.isSubmit=true;
        }else{
          document.getElementById("lbyp1").innerHTML="用户名已存在";
          this.isSubmit=false;
        }
      })
    },
    Register(){
      var n=this.uane;
      var p=this.upwd;
      var regname=/^[\u4e00-\u9fa5\w]{1,6}$/;
      var regpwd = /^[a-z0-9]{6,12}$/i
      //验证用户名
      if(!regname.test(n)){
        document.getElementById("lbyp1").innerHTML="用户名格式不正确";
          return;
      }
       //验证密码
      if(!regpwd.test(p)){
          document.getElementById("lbyp2").innerHTML="密码格式不正确";
          return;
      }
      var url="http://127.0.0.1:3000/register?uname="+n+"&upwd="+p;
      this.axios.get(url).then(result=>{
        alert(result.data.msg);
      })
    }
  },
  created(){
  }
}
</script>

<style>
  .content{width:340px;height:450px;
    border:1px solid #D8D8D8;
    margin:150px auto;
  }
  .lby_login{text-align:center}

  .lby_top{margin-top:50px;
    width:290px;height:40px;
    border-bottom:1px solid #D8D8D8;
    margin-left:25px;
    margin-bottom:10px;
  }
  .lby_gs{
    font-weight:bold;
    font-size:18px;
    padding-right:15px;
    color:black
  } 
  .login:hover{
    text-decoration:none;
    background: #fff;
  }
  .login1:hover{
    text-decoration:none;
    background: #fff;
  }
  .login1 span{font-size:18px;color:#D8D8D8}

  .lby_middle span{font-size:11px;}
  .lby_m span{color:#41AC52}
  .lby_m:hover{
    text-decoration:none;
    background: #fff;
  }

  .lby_zl input{
    width:270px;
    height:40px; 
   
  }

  .lby_ljzc{
    display:block;
    width:290px;height:35px;
    background-color:#A0DEAA;
    line-height:35px;
    margin-top:20px;
    margin-left:25px;     
  }
  .lby_a span{color:white;}
  .lby_a:hover{
    text-decoration:none;
    background:#A0DEAA;
  }
  .lby_lby_lr{
    width: 200px;
    height: 200px;
    background: #ff0;
  }

  
  .lby_zddl{font-size:15px;margin-bottom:20px}
  .lby_zddl span{
    position: relative;
    left:-47px;
    }
  .lby_dl>input{width:270px;height:40px}
  .lby_ljzc1{
    display:block;
    width:290px;height:35px;
    background-color:#A0DEAA;
    line-height:35px;
    margin-top:20px;
    margin-left:25px;     
  }
</style>  