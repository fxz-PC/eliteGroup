import Vue from 'vue'
import Router from 'vue-router'
import shj from "./components/lby/shj.vue"
import yd from "./components/lby/yd.vue"
import gwc from "./components/lby/gwc.vue"
import login from "./components/lby/login.vue"
import home from "./components/hrx/home.vue"
Vue.use(Router)

export default new Router({
  routes: [
    // {path:'/',component:Home},
    {path:'/',redirect:'/home'},//自动跳转
    {path:'/home',component:home},
    {path:'/yd',component:yd},
    {path:'/shj',component:shj},
    {path:'/gwc',component:gwc},
    {path:'/login',component:login},
  ]
})
